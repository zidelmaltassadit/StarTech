from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor

# --- CONFIGURATION DU STYLE "APPLE" (Sobre & Chic) ---
# Couleurs
WHITE = RGBColor(255, 255, 255)
BLACK = RGBColor(0, 0, 0)
DARK_GRAY = RGBColor(29, 29, 31)
APPLE_BLUE = RGBColor(0, 113, 227)

def set_font(run, size, is_bold=False, color=DARK_GRAY):
    run.font.name = 'Arial' # Proche de la font Apple par défaut sur Windows
    run.font.size = Pt(size)
    run.font.bold = is_bold
    run.font.color.rgb = color

def create_slide(prs, title_text, content_text_list):
    slide_layout = prs.slide_layouts[1] # Layout Titre + Contenu
    slide = prs.slides.add_slide(slide_layout)
    
    # Titre
    title = slide.shapes.title
    title.text = title_text
    # Style du titre
    for paragraph in title.text_frame.paragraphs:
        paragraph.alignment = PP_ALIGN.LEFT
        for run in paragraph.runs:
            set_font(run, 40, True, APPLE_BLUE)

    # Contenu (Liste à puces)
    body_shape = slide.placeholders[1]
    tf = body_shape.text_frame
    tf.clear() # Effacer le contenu par défaut

    for item in content_text_list:
        p = tf.add_paragraph()
        p.text = item
        p.level = 0
        set_font(p.runs[0], 24, False, DARK_GRAY)
        p.space_after = Pt(14)

    return slide

# --- CRÉATION DE LA PRÉSENTATION ---
prs = Presentation()

# 1. SLIDE DE TITRE
slide_layout = prs.slide_layouts[0] 
slide = prs.slides.add_slide(slide_layout)
title = slide.shapes.title
subtitle = slide.placeholders[1]

title.text = "StarTech"
subtitle.text = "Projet SI - L3 MIASHS\n\nMouad DEHICHI & Tassadit ZIDELMAL\nSuperviseur : M. Anis CHERGUI"

# Style Titre Principal
for run in title.text_frame.paragraphs[0].runs:
    set_font(run, 60, True, BLACK)

# 2. L'IDÉE (LE CONCEPT)
create_slide(prs, "1. Le Concept StarTech", [
    "Objectif : Créer une plateforme E-commerce Premium.",
    "Cible : Professionnels et passionnés de Tech.",
    "Innovation : Configurateur de PC sur-mesure (RAM, SSD).",
    "Architecture : Site dynamique relié à une Base de Données."
])

# 3. GESTION DE PROJET (LES LIVRABLES ANALYSE)
create_slide(prs, "2. Pilotage & Analyse (Gestion)", [
    "Démarche structurée en 4 semaines (Méthode Agile/Cycle en V).",
    "Livrable 1 : Étude de Faisabilité & Analyse SWOT (Risques).",
    "Livrable 2 : Cahier des Charges Fonctionnel (Besoins).",
    "Planification : Diagramme de Gantt détaillé."
])

# 4. CONCEPTION TECHNIQUE (LES LIVRABLES INFO)
create_slide(prs, "3. Conception Technique (Info)", [
    "Modélisation UML : Diagramme de Cas d'Utilisation & Classes.",
    "Base de Données : Modèle Logique (MLD) sous MySQL.",
    "Spécifications : SFG et SFD (Règles de gestion strictes).",
    "Dossier Technique : Guide d'installation et architecture AMPPS."
])

# 5. RÉALISATION (LE SITE)
create_slide(prs, "4. Réalisation & Démo", [
    "Stack Technique : HTML5 / CSS3 (Style Apple) / JS / PHP / MySQL.",
    "Fonctionnalités développées :",
    "   - Front-Office : Catalogue & Configurateur temps réel.",
    "   - Back-Office : Gestion des commandes Admin.",
    "   - B2B : Portail Fournisseur avec alertes stock."
])

# 6. CONCLUSION
create_slide(prs, "Conclusion & Bilan", [
    "Projet 100% Fonctionnel et Documenté.",
    "Compétences acquises :",
    "   - Double compétence Gestion (Pilotage) / Info (Dév).",
    "   - Rigueur du livrable et qualité du code.",
    "Merci de votre écoute."
])

# Sauvegarde
prs.save('Presentation_StarTech.pptx')
print("Présentation générée avec succès : Presentation_StarTech.pptx")