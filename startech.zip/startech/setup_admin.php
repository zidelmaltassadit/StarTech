<?php
// setup_admin.php
// Ce script sert à créer le premier administrateur de manière sécurisée.

// On inclut la configuration de la base de données
// (Adaptez le chemin si votre fichier n'est pas à la racine)
require_once 'includes/db_config.php';

// ==================================================================
// 1. CONFIGURATION DU NOUVEL ADMIN (CHANGEZ CES VALEURS !)
// ==================================================================
$nom = "Super Administrateur";
$email = "admin@startech.com";       // <-- Mettez l'email souhaité
$mot_de_passe_en_clair = "AdminStarTech2025!"; // <-- Mettez le mot de passe souhaité
$role = "admin"; // Le rôle suprême
// ==================================================================


echo "<h1>Création du compte Administrateur</h1>";

try {
    // 2. Vérifier si cet email existe déjà
    $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ?");
    $stmt_check->execute([$email]);

    if ($stmt_check->fetchColumn() > 0) {
        die("<p style='color:red;'>Erreur : Un utilisateur avec l'email '$email' existe déjà.</p>");
    }

    // 3. Hachage (cryptage) sécurisé du mot de passe
    // C'est l'étape cruciale pour que la connexion fonctionne.
    $password_hash = password_hash($mot_de_passe_en_clair, PASSWORD_DEFAULT);

    // 4. Insertion dans la base de données
    $sql = "INSERT INTO utilisateurs (nom, email, password_hash, user_role) 
            VALUES (:nom, :email, :hash, :role)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nom' => $nom,
        ':email' => $email,
        ':hash' => $password_hash,
        ':role' => $role
    ]);

    echo "<p style='color:green; font-weight:bold;'>Succès ! L'administrateur '$email' a été créé.</p>";
    echo "<p>Vous pouvez maintenant aller sur la page de connexion et utiliser ces identifiants.</p>";
    echo "<a href='public/login.php'>Aller à la connexion</a>";

} catch (PDOException $e) {
    die("Erreur SQL lors de la création : " . $e->getMessage());
}
?>