-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : dim. 23 nov. 2025 à 17:54
-- Version du serveur : 8.0.44
-- Version de PHP : 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `startech_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

CREATE TABLE `admins` (
  `id` int UNSIGNED NOT NULL,
  `prenom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `nom` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `nom`) VALUES
(1, 'Mac'),
(2, 'iPad'),
(3, 'iPhone'),
(4, 'Audio'),
(5, 'Accessoires');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id` int NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `prenom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `adresse_livraison` text COLLATE utf8mb4_general_ci,
  `adresse_facturation` text COLLATE utf8mb4_general_ci,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `statut` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'client',
  `telephone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `adresse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ville` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code_postal` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `entreprise` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'client',
  `fournisseur_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `nom`, `prenom`, `email`, `adresse_livraison`, `adresse_facturation`, `password_hash`, `statut`, `telephone`, `adresse`, `ville`, `code_postal`, `date_creation`, `entreprise`, `user_role`, `fournisseur_id`) VALUES
(5, 'Mouad DEHICHI', NULL, 'dehmouad@gmail.com', '2 avenue charles de gaulle, Paris, 75000', '2 avenue charles de gaulle, Paris, 75000', '$2y$10$kXkVVIrDPV/jpNvIGusNj.Ptjnl8DFMveT21o5jdGZ.5PHelnoMTa', 'client', NULL, NULL, NULL, NULL, '2025-11-22 17:10:31', NULL, 'client', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `commandes`
--

CREATE TABLE `commandes` (
  `id` int NOT NULL,
  `utilisateur_id` int DEFAULT NULL,
  `date_commande` datetime DEFAULT CURRENT_TIMESTAMP,
  `statut` varchar(20) NOT NULL DEFAULT 'en_attente',
  `date_mise_a_jour` datetime DEFAULT NULL,
  `montant_total` decimal(10,2) NOT NULL,
  `frais_livraison` decimal(10,2) DEFAULT '0.00',
  `adresse_livraison` text,
  `adresse_facturation` text NOT NULL,
  `moyen_paiement` varchar(100) NOT NULL,
  `points_utilises` int DEFAULT '0',
  `statut_facturation` enum('non_facture','facture_generee') DEFAULT 'non_facture',
  `total_ttc` decimal(10,2) NOT NULL DEFAULT '0.00',
  `client_id` int DEFAULT NULL,
  `total_ht` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_tva` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `commandes`
--

INSERT INTO `commandes` (`id`, `utilisateur_id`, `date_commande`, `statut`, `date_mise_a_jour`, `montant_total`, `frais_livraison`, `adresse_livraison`, `adresse_facturation`, `moyen_paiement`, `points_utilises`, `statut_facturation`, `total_ttc`, `client_id`, `total_ht`, `total_tva`) VALUES
(14, NULL, '2025-11-22 17:11:40', 'expediee', NULL, 199.00, 0.00, '2 avenue charles de gaulle, Paris, 75000', '2 avenue charles de gaulle, Paris, 75000', 'Carte Bancaire (Simulé)', 0, 'non_facture', 0.00, 5, 165.83, 33.17),
(15, NULL, '2025-11-23 14:20:22', 'expediee', NULL, 1599.00, 0.00, '2 avenue charles de gaulle, Paris, 75000', '2 avenue charles de gaulle, Paris, 75000', 'Carte Bancaire (Simulé)', 0, 'non_facture', 0.00, 5, 1332.50, 266.50),
(16, NULL, '2025-11-23 14:30:26', 'en_attente', NULL, 579.00, 0.00, '2 avenue charles de gaulle, Paris, 75000', '2 avenue charles de gaulle, Paris, 75000', 'Carte Bancaire (Simulé)', 0, 'non_facture', 0.00, 5, 482.50, 96.50);

-- --------------------------------------------------------

--
-- Structure de la table `commandes_achat`
--

CREATE TABLE `commandes_achat` (
  `id` int NOT NULL,
  `fournisseur_id` int NOT NULL,
  `date_commande` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_reception_prevue` date DEFAULT NULL,
  `statut` varchar(20) NOT NULL DEFAULT 'en_cours',
  `date_mise_a_jour` datetime DEFAULT NULL,
  `montant_total` decimal(10,2) DEFAULT '0.00',
  `date_livraison_prevue` date DEFAULT NULL,
  `total_ht` decimal(10,2) NOT NULL DEFAULT '0.00',
  `date_reception_reelle` datetime DEFAULT NULL,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `commandes_achat`
--

INSERT INTO `commandes_achat` (`id`, `fournisseur_id`, `date_commande`, `date_reception_prevue`, `statut`, `date_mise_a_jour`, `montant_total`, `date_livraison_prevue`, `total_ht`, `date_reception_reelle`, `date_creation`) VALUES
(6, 11, '2025-11-22 17:33:23', NULL, 'expediee', NULL, 90.00, NULL, 0.00, NULL, '2025-11-22 17:33:23');

-- --------------------------------------------------------

--
-- Structure de la table `commandes_fournisseur`
--

CREATE TABLE `commandes_fournisseur` (
  `id` int NOT NULL,
  `fournisseur_id` int NOT NULL,
  `date_commande` date NOT NULL,
  `date_livraison_prevue` date DEFAULT NULL,
  `total_ht` decimal(10,2) NOT NULL,
  `total_ttc` decimal(10,2) NOT NULL,
  `statut` enum('en_cours','expediee','partiellement_recue','recue_complete','annulee') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'en_cours',
  `statut_paiement` enum('non_payee','partiellement_payee','payee') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'non_payee'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commande_details`
--

CREATE TABLE `commande_details` (
  `id` int NOT NULL,
  `commande_id` int NOT NULL,
  `produit_id` int NOT NULL,
  `quantite` int NOT NULL,
  `prix_unitaire_ht` decimal(10,2) NOT NULL,
  `total_ligne_ht` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commande_fournisseur_details`
--

CREATE TABLE `commande_fournisseur_details` (
  `id` int NOT NULL,
  `commande_fournisseur_id` int NOT NULL,
  `produit_id` int NOT NULL,
  `quantite` int NOT NULL,
  `quantite_recue` int NOT NULL DEFAULT '0',
  `prix_unitaire_ht` decimal(10,2) NOT NULL,
  `total_ligne_ht` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `details_commande`
--

CREATE TABLE `details_commande` (
  `id` int NOT NULL,
  `commande_id` int DEFAULT NULL,
  `produit_id` int DEFAULT NULL,
  `quantite` int NOT NULL,
  `prix_unitaire_ht` decimal(10,2) NOT NULL,
  `prix_total_ht` decimal(10,2) NOT NULL,
  `prix_total_ttc` decimal(10,2) NOT NULL,
  `options` text,
  `remise_appliquee` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `details_commande`
--

INSERT INTO `details_commande` (`id`, `commande_id`, `produit_id`, `quantite`, `prix_unitaire_ht`, `prix_total_ht`, `prix_total_ttc`, `options`, `remise_appliquee`) VALUES
(1, 14, 10, 1, 165.83, 165.83, 199.00, NULL, 0.00),
(2, 15, 1, 1, 1332.50, 1332.50, 1599.00, NULL, 0.00),
(3, 16, 9, 1, 482.50, 482.50, 579.00, NULL, 0.00);

-- --------------------------------------------------------

--
-- Structure de la table `details_commande_achat`
--

CREATE TABLE `details_commande_achat` (
  `id` int NOT NULL,
  `commande_achat_id` int DEFAULT NULL,
  `produit_id` int DEFAULT NULL,
  `quantite_commandee` int NOT NULL,
  `prix_achat_unitaire` decimal(10,2) NOT NULL,
  `quantite_recue` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `details_commande_achat`
--

INSERT INTO `details_commande_achat` (`id`, `commande_achat_id`, `produit_id`, `quantite_commandee`, `prix_achat_unitaire`, `quantite_recue`) VALUES
(2, 6, 11, 6, 15.00, 0);

-- --------------------------------------------------------

--
-- Structure de la table `devis`
--

CREATE TABLE `devis` (
  `id` int NOT NULL,
  `client_id` int NOT NULL,
  `date_devis` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_validite` date DEFAULT NULL,
  `total_ht` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_ttc` decimal(10,2) NOT NULL DEFAULT '0.00',
  `statut` enum('brouillon','envoye','accepte','refuse','converti') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'brouillon'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `devis_details`
--

CREATE TABLE `devis_details` (
  `id` int NOT NULL,
  `devis_id` int NOT NULL,
  `produit_id` int NOT NULL,
  `quantite` int NOT NULL,
  `prix_unitaire_ht` decimal(10,2) NOT NULL,
  `total_ligne_ht` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `factures`
--

CREATE TABLE `factures` (
  `id` int NOT NULL,
  `commande_id` int NOT NULL,
  `client_id` int NOT NULL,
  `numero_facture` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_facture` date NOT NULL,
  `date_paiement_prevue` date DEFAULT NULL,
  `total_ht` decimal(10,2) NOT NULL,
  `total_tva` decimal(10,2) NOT NULL,
  `total_ttc` decimal(10,2) NOT NULL,
  `montant_paye` decimal(10,2) NOT NULL DEFAULT '0.00',
  `statut_paiement` enum('Impayee','Partielle','Payee') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Impayee'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `factures_fournisseur`
--

CREATE TABLE `factures_fournisseur` (
  `id` int NOT NULL,
  `commande_achat_id` int DEFAULT NULL,
  `fournisseur_id` int NOT NULL,
  `reference_facture` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_facture` date NOT NULL,
  `date_echeance` date DEFAULT NULL,
  `total_ht` decimal(10,2) NOT NULL,
  `total_ttc` decimal(10,2) NOT NULL,
  `montant_paye` decimal(10,2) NOT NULL DEFAULT '0.00',
  `statut_paiement` enum('en_attente','partiellement_payee','payee','en_retard') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'en_attente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `facture_details`
--

CREATE TABLE `facture_details` (
  `id` int NOT NULL,
  `facture_id` int NOT NULL,
  `produit_id` int NOT NULL,
  `quantite` int NOT NULL,
  `prix_unitaire_ht` decimal(10,2) NOT NULL,
  `total_ligne_ht` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `fidelite_transactions`
--

CREATE TABLE `fidelite_transactions` (
  `id` int NOT NULL,
  `utilisateur_id` int NOT NULL,
  `commande_id` int DEFAULT NULL,
  `type_transaction` enum('gain','utilisation','ajustement') NOT NULL,
  `points_ajoutes_retires` int NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date_transaction` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `fournisseurs`
--

CREATE TABLE `fournisseurs` (
  `id` int NOT NULL,
  `nom_societe` varchar(255) NOT NULL,
  `contact_nom` varchar(100) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `nom` varchar(255) NOT NULL,
  `code_acces` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `lignes_commande_achat`
--

CREATE TABLE `lignes_commande_achat` (
  `id` int NOT NULL,
  `commande_achat_id` int NOT NULL,
  `produit_id` int NOT NULL,
  `quantite` int NOT NULL,
  `prix_unitaire_ht` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `mouvements_stock`
--

CREATE TABLE `mouvements_stock` (
  `id` int NOT NULL,
  `produit_id` int NOT NULL,
  `type_mouvement` enum('entree','sortie','ajustement','production') NOT NULL,
  `quantite` int NOT NULL,
  `reference_externe` varchar(100) DEFAULT NULL,
  `date_mouvement` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `id` int NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text,
  `prix_vente` decimal(10,2) NOT NULL,
  `prix_achat` decimal(10,2) DEFAULT '0.00',
  `quantite_stock` int DEFAULT '0',
  `seuil_alerte` int DEFAULT '10',
  `image` varchar(255) DEFAULT NULL,
  `categorie_id` int DEFAULT NULL,
  `fournisseur_id` int DEFAULT NULL,
  `statut` varchar(50) DEFAULT 'actif',
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`id`, `nom`, `description`, `prix_vente`, `prix_achat`, `quantite_stock`, `seuil_alerte`, `image`, `categorie_id`, `fournisseur_id`, `statut`, `date_creation`) VALUES
(1, 'MacBook Air 15\"', 'Puce M2. Une immensité de talent. Écran Liquid Retina spectaculaire.', 1599.00, 1300.00, 49, 5, 'macbook-air.jpg', 1, 11, 'actif', '2025-11-22 01:08:40'),
(2, 'MacBook Pro 14\"', 'Puce M3 Pro. L\'ordinateur portable pro ultime. Autonomie d\'une journée.', 2499.00, 900.00, 30, 5, 'macbook-pro.jpg', 1, 11, 'actif', '2025-11-22 01:08:40'),
(3, 'iMac 24\"', 'Dites bonjour au nouvel iMac. Design ultra-fin, puce M3.', 1699.00, 0.00, 13, 10, 'imac.jpg', 1, NULL, 'actif', '2025-11-22 01:08:40'),
(4, 'iPad Air', 'Léger. Puissant. Coloré. Puce M1 et écran Liquid Retina 10,9 pouces.', 789.00, 0.00, 40, 10, 'ipad-air.jpg', 2, NULL, 'actif', '2025-11-22 01:08:40'),
(5, 'iPad Pro 12.9\"', 'L\'expérience iPad ultime. Puce M2, écran XDR et connectivité 5G.', 1469.00, 0.00, 20, 10, 'ipad-pro.jpg', 2, NULL, 'actif', '2025-11-22 01:08:40'),
(6, 'iPhone 15 Pro', 'Titane. Puce A17 Pro. Le plus puissant des iPhone.', 1229.00, 0.00, 100, 10, 'iphone-15-pro.jpg', 3, NULL, 'actif', '2025-11-22 01:08:40'),
(7, 'iPhone 15', 'Nouveau design. Dynamic Island. Appareil photo 48 Mpx.', 969.00, 0.00, 150, 10, 'iphone-15.jpg', 3, NULL, 'actif', '2025-11-22 01:08:40'),
(8, 'AirPods Pro (2e gén)', 'Réduction active du bruit jusqu\'à 2x plus performante.', 279.00, 150.00, 200, 5, 'airpods-pro.jpg', 4, 11, 'actif', '2025-11-22 01:08:40'),
(9, 'AirPods Max', 'Le casque réinventé. Audio haute fidélité. Design circum-auriculaire.', 579.00, 300.00, 23, 5, 'airpods-max.jpg', 4, 11, 'actif', '2025-11-22 01:08:40'),
(10, 'AirPods (3e gén)', 'Audio spatial personnalisé avec suivi dynamique des mouvements de la tête.', 199.00, 100.00, 78, 5, 'airpods-3.jpg', 4, 11, 'actif', '2025-11-22 01:08:40'),
(11, 'Adaptateur secteur 20W', 'Charge rapide pour iPhone et iPad.', 25.00, 15.00, 4, 5, 'chargeur-20w.jpg', 5, 11, 'actif', '2025-11-22 01:08:40'),
(12, 'Câble USB-C vers Lightning', 'Connectez votre iPhone à votre Mac.', 25.00, 0.00, 300, 10, 'cable-usbc.jpg', 5, NULL, 'actif', '2025-11-22 01:08:40'),
(13, 'Coque MagSafe Silicone', 'Conçue pour iPhone 15 Pro.', 59.00, 0.00, 120, 10, 'coque-silicone.jpg', 5, 12, 'actif', '2025-11-22 01:08:40');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL,
  `role` enum('admin','client') NOT NULL DEFAULT 'client',
  `points_fidelite` int DEFAULT '0',
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_role` varchar(20) NOT NULL DEFAULT 'client'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `email`, `password_hash`, `mot_de_passe`, `role`, `points_fidelite`, `date_creation`, `user_role`) VALUES
(11, 'Apple Inc', 'contact@apple.com', '$2y$10$c.UaQ9NvvuZcp2s5WluQ4uB3zh.b68namPXMqVSqpdD4Ma05swhU2', NULL, 'client', 0, '2025-11-22 16:38:54', 'fournisseur'),
(12, 'Appledigital Solutions', 'support@appledigital.com', '$2y$10$nDQD/5obvwVZ8nNfTsFPpO0NNTzCFqwdML8wZT2VQqkXAnQFQGBmO', NULL, 'client', 0, '2025-11-22 16:39:16', 'fournisseur'),
(15, 'Super Administrateur', 'admin@startech.com', '$2y$10$Mbrj684F/tR7rb2ML0y9e.pDB8QH6vbe7mFQM.fn2orVUTGiQZuYi', NULL, 'client', 0, '2025-11-22 17:25:07', 'admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `commandes`
--
ALTER TABLE `commandes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `utilisateur_id` (`utilisateur_id`),
  ADD KEY `fk_commande_client` (`client_id`);

--
-- Index pour la table `commandes_achat`
--
ALTER TABLE `commandes_achat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fournisseur_id` (`fournisseur_id`);

--
-- Index pour la table `commandes_fournisseur`
--
ALTER TABLE `commandes_fournisseur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fournisseur_id` (`fournisseur_id`);

--
-- Index pour la table `commande_details`
--
ALTER TABLE `commande_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_id` (`commande_id`);

--
-- Index pour la table `commande_fournisseur_details`
--
ALTER TABLE `commande_fournisseur_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_fournisseur_id` (`commande_fournisseur_id`),
  ADD KEY `produit_id` (`produit_id`);

--
-- Index pour la table `details_commande`
--
ALTER TABLE `details_commande`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_id` (`commande_id`),
  ADD KEY `produit_id` (`produit_id`);

--
-- Index pour la table `details_commande_achat`
--
ALTER TABLE `details_commande_achat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_achat_id` (`commande_achat_id`),
  ADD KEY `produit_id` (`produit_id`);

--
-- Index pour la table `devis`
--
ALTER TABLE `devis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`);

--
-- Index pour la table `devis_details`
--
ALTER TABLE `devis_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devis_id` (`devis_id`),
  ADD KEY `produit_id` (`produit_id`);

--
-- Index pour la table `factures`
--
ALTER TABLE `factures`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `numero_facture` (`numero_facture`),
  ADD KEY `commande_id` (`commande_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Index pour la table `factures_fournisseur`
--
ALTER TABLE `factures_fournisseur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_achat_id` (`commande_achat_id`),
  ADD KEY `fournisseur_id` (`fournisseur_id`);

--
-- Index pour la table `facture_details`
--
ALTER TABLE `facture_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `facture_id` (`facture_id`);

--
-- Index pour la table `fidelite_transactions`
--
ALTER TABLE `fidelite_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `utilisateur_id` (`utilisateur_id`),
  ADD KEY `commande_id` (`commande_id`);

--
-- Index pour la table `fournisseurs`
--
ALTER TABLE `fournisseurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nom_societe` (`nom_societe`),
  ADD UNIQUE KEY `contact_email` (`contact_email`),
  ADD UNIQUE KEY `code_acces` (`code_acces`);

--
-- Index pour la table `lignes_commande_achat`
--
ALTER TABLE `lignes_commande_achat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `commande_achat_id` (`commande_achat_id`),
  ADD KEY `produit_id` (`produit_id`);

--
-- Index pour la table `mouvements_stock`
--
ALTER TABLE `mouvements_stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `produit_id` (`produit_id`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_categorie` (`categorie_id`),
  ADD KEY `fk_produit_fournisseur` (`fournisseur_id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `commandes`
--
ALTER TABLE `commandes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `commandes_achat`
--
ALTER TABLE `commandes_achat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `commandes_fournisseur`
--
ALTER TABLE `commandes_fournisseur`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `commande_details`
--
ALTER TABLE `commande_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `commande_fournisseur_details`
--
ALTER TABLE `commande_fournisseur_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `details_commande`
--
ALTER TABLE `details_commande`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `details_commande_achat`
--
ALTER TABLE `details_commande_achat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `devis`
--
ALTER TABLE `devis`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `devis_details`
--
ALTER TABLE `devis_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `factures`
--
ALTER TABLE `factures`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `factures_fournisseur`
--
ALTER TABLE `factures_fournisseur`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `facture_details`
--
ALTER TABLE `facture_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `fidelite_transactions`
--
ALTER TABLE `fidelite_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `fournisseurs`
--
ALTER TABLE `fournisseurs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `lignes_commande_achat`
--
ALTER TABLE `lignes_commande_achat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `mouvements_stock`
--
ALTER TABLE `mouvements_stock`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commandes`
--
ALTER TABLE `commandes`
  ADD CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_commande_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE RESTRICT;

--
-- Contraintes pour la table `commandes_achat`
--
ALTER TABLE `commandes_achat`
  ADD CONSTRAINT `fk_commande_achat_fournisseur` FOREIGN KEY (`fournisseur_id`) REFERENCES `utilisateurs` (`id`);

--
-- Contraintes pour la table `commandes_fournisseur`
--
ALTER TABLE `commandes_fournisseur`
  ADD CONSTRAINT `commandes_fournisseur_ibfk_1` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`);

--
-- Contraintes pour la table `commande_details`
--
ALTER TABLE `commande_details`
  ADD CONSTRAINT `commande_details_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `commande_fournisseur_details`
--
ALTER TABLE `commande_fournisseur_details`
  ADD CONSTRAINT `commande_fournisseur_details_ibfk_1` FOREIGN KEY (`commande_fournisseur_id`) REFERENCES `commandes_fournisseur` (`id`),
  ADD CONSTRAINT `commande_fournisseur_details_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`);

--
-- Contraintes pour la table `details_commande`
--
ALTER TABLE `details_commande`
  ADD CONSTRAINT `details_commande_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `details_commande_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE RESTRICT;

--
-- Contraintes pour la table `details_commande_achat`
--
ALTER TABLE `details_commande_achat`
  ADD CONSTRAINT `details_commande_achat_ibfk_1` FOREIGN KEY (`commande_achat_id`) REFERENCES `commandes_achat` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `details_commande_achat_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE RESTRICT;

--
-- Contraintes pour la table `devis`
--
ALTER TABLE `devis`
  ADD CONSTRAINT `devis_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`);

--
-- Contraintes pour la table `devis_details`
--
ALTER TABLE `devis_details`
  ADD CONSTRAINT `devis_details_ibfk_1` FOREIGN KEY (`devis_id`) REFERENCES `devis` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `devis_details_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`);

--
-- Contraintes pour la table `factures`
--
ALTER TABLE `factures`
  ADD CONSTRAINT `factures_ibfk_1` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `factures_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE RESTRICT;

--
-- Contraintes pour la table `factures_fournisseur`
--
ALTER TABLE `factures_fournisseur`
  ADD CONSTRAINT `factures_fournisseur_ibfk_1` FOREIGN KEY (`commande_achat_id`) REFERENCES `commandes_achat` (`id`),
  ADD CONSTRAINT `factures_fournisseur_ibfk_2` FOREIGN KEY (`fournisseur_id`) REFERENCES `fournisseurs` (`id`);

--
-- Contraintes pour la table `facture_details`
--
ALTER TABLE `facture_details`
  ADD CONSTRAINT `facture_details_ibfk_1` FOREIGN KEY (`facture_id`) REFERENCES `factures` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `fidelite_transactions`
--
ALTER TABLE `fidelite_transactions`
  ADD CONSTRAINT `fidelite_transactions_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fidelite_transactions_ibfk_2` FOREIGN KEY (`commande_id`) REFERENCES `commandes` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `lignes_commande_achat`
--
ALTER TABLE `lignes_commande_achat`
  ADD CONSTRAINT `lignes_commande_achat_ibfk_1` FOREIGN KEY (`commande_achat_id`) REFERENCES `commandes_achat` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lignes_commande_achat_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE RESTRICT;

--
-- Contraintes pour la table `mouvements_stock`
--
ALTER TABLE `mouvements_stock`
  ADD CONSTRAINT `mouvements_stock_ibfk_1` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE RESTRICT;

--
-- Contraintes pour la table `produits`
--
ALTER TABLE `produits`
  ADD CONSTRAINT `fk_categorie` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_produit_fournisseur` FOREIGN KEY (`fournisseur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
