<?php
// contact.php (à la racine du projet)
session_start();
// Pas besoin de connexion BDD pour cette page, sauf si vous stockez les messages.
// require_once 'includes/db_config.php'; 

$message = '';
$nom = $_POST['nom'] ?? '';
$email = $_POST['email'] ?? '';
$sujet = $_POST['sujet'] ?? '';
$contenu = $_POST['contenu'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($nom) || empty($email) || empty($sujet) || empty($contenu)) {
        $message = "<div class='alert-danger'>Veuillez remplir tous les champs du formulaire.</div>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "<div class='alert-danger'>Adresse e-mail invalide.</div>";
    } else {
        // --- LOGIQUE D'ENVOI D'EMAIL ---
        
        // NOTE IMPORTANTE: L'envoi réel nécessite une configuration PHP/Serveur (SMTP).
        // Si vous utilisez la fonction mail(), elle pourrait ne pas fonctionner en local.
        
        /*
        $destinataire = "votre@email-entreprise.com";
        $headers = "From: " . $email . "\r\n";
        $headers .= "Reply-To: " . $email . "\r\n";
        $mail_body = "Nom: " . $nom . "\nEmail: " . $email . "\n\nContenu:\n" . $contenu;

        if (mail($destinataire, "[CONTACT STARTECH] " . $sujet, $mail_body, $headers)) {
            $message = "<div class='alert-success'>✅ Votre message a été envoyé avec succès ! Nous vous répondrons bientôt.</div>";
            // Réinitialiser les champs
            $nom = $email = $sujet = $contenu = ''; 
        } else {
            $message = "<div class='alert-warning'>Une erreur est survenue lors de l'envoi de l'email. Veuillez réessayer.</div>";
        }
        */
        
        // SIMULATION de succès pour le développement local
        $message = "<div class='alert-success'>✅ Votre message a été reçu ! (L'envoi réel d'email est désactivé en mode local).</div>";
        $nom = $email = $sujet = $contenu = ''; 
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Contactez-nous</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech</h1>
            <nav>
                <a href="public/catalogue.php">Catalogue</a>
                <a href="contact.php">Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="public/client_dashboard.php">Bienvenue, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Client') ?></a>
                    <a href="logout.php">Déconnexion</a>
                <?php else: ?>
                    <a href="public/login.php">Connexion Client</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <div class="container public-content form-container">
        <h2>Nous Contacter</h2>
        <p>Utilisez le formulaire ci-dessous pour toute question ou demande d'information.</p>
        
        <?= $message; ?>

        <form action="contact.php" method="POST" class="form-standard">
            <div class="form-group">
                <label for="nom">Votre Nom :</label>
                <input type="text" id="nom" name="nom" value="<?= htmlspecialchars($nom) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="email">Votre Email :</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="sujet">Sujet :</label>
                <input type="text" id="sujet" name="sujet" value="<?= htmlspecialchars($sujet) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="contenu">Message :</label>
                <textarea id="contenu" name="contenu" rows="6" required><?= htmlspecialchars($contenu) ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary">Envoyer le Message</button>
        </form>
    </div>
</body>
</html>