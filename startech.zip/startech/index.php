<?php
// 1. Démarrage de la session pour gérer le menu connecté/déconnecté
if (session_status() === PHP_SESSION_NONE) { session_start(); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StarTech - Le futur, aujourd'hui.</title>
    
    <link rel="stylesheet" href="/startech/assets/css/style.css"> 
    <link rel="stylesheet" href="/startech/assets/css/index_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* CSS DU MENU DÉROULANT PREMIUM (Copie conforme du header) */
        .user-dropdown-container { position: relative; height: 100%; display: flex; align-items: center; cursor: pointer; z-index: 100000; }
        .user-dropdown-container::after { content: ''; position: absolute; top: 100%; left: -20px; right: -20px; height: 20px; }
        
        .dropdown-menu {
            display: none; position: absolute; top: 100%; right: -10px; width: 240px;
            background-color: #fff; box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            border-radius: 18px; padding: 10px; border: 1px solid rgba(0,0,0,0.05); margin-top: 10px;
            z-index: 100001; opacity: 0; transform: translateY(-10px); transition: all 0.2s ease;
        }
        .user-dropdown-container:hover .dropdown-menu { display: block !important; opacity: 1; transform: translateY(0); }
        
        .dropdown-menu a {
            display: block; padding: 10px 15px; color: #1d1d1f; text-decoration: none;
            font-size: 13px; border-radius: 10px; transition: background 0.1s;
        }
        .dropdown-menu a:hover { background-color: #F5F5F7; color: #0071E3; }
        
        .menu-header {
            padding: 10px 15px; font-size: 11px; color: #86868b;
            font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .dropdown-divider { height: 1px; background-color: #e5e5e5; margin: 5px 10px; }
        
        /* LOGO GRAS */
        .nav-logo { font-weight: 700 !important; font-size: 1.2rem; }
    </style>
</head>
<body>

<nav class="apple-nav">
    <div class="nav-content">
        <a href="/startech/index.php" class="nav-logo">StarTech</a>
        
        <ul class="nav-links">
            <li><a href="/startech/public/catalogue.php?cat=mac">Mac</a></li>
            <li><a href="/startech/public/catalogue.php?cat=ipad">iPad</a></li>
            <li><a href="/startech/public/catalogue.php?cat=iphone">iPhone</a></li>
            <li><a href="/startech/public/catalogue.php?cat=audio">Audio</a></li>
            <li><a href="/startech/public/catalogue.php?cat=accessoires">Accessoires</a></li>
            <li><a href="/startech/public/support.php">Support</a></li>
        </ul>

        <div class="nav-icons">
            <a href="/startech/public/catalogue.php"><i class="fa-solid fa-magnifying-glass"></i></a>
            <a href="/startech/public/panier.php"><i class="fa-solid fa-bag-shopping"></i></a>
            
            <div class="user-dropdown-container">
                <a href="#" class="user-icon"><i class="fa-regular fa-user"></i></a>
                
                <div class="dropdown-menu">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <div class="menu-header">
                            <?= htmlspecialchars($_SESSION['user_prenom'] ?? 'Mon Compte') ?>
                        </div>
                        
                        <?php if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'client'): ?>
                             <a href="/startech/public/client_dashboard.php">Espace Client</a>
                        <?php elseif(isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'fournisseur')): ?>
                             <a href="/startech/admin/dashboard.php">Interface Pro</a>
                        <?php endif; ?>
                        
                        <div class="dropdown-divider"></div>
                        <a href="/startech/public/logout.php" style="color: #FF3B30;">Se déconnecter</a>
                    
                    <?php else: ?>
                        <div class="menu-header">Compte</div>
                        <a href="/startech/public/login.php?role=client">Se connecter</a>
                        <a href="/startech/public/register.php">Créer un compte</a>
                        <div class="dropdown-divider"></div>
                        <a href="/startech/public/login.php?role=fournisseur">Accès Fournisseur</a>
                        <a href="/startech/public/login.php?role=admin">Accès Admin</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</nav>

    <section class="hero-banner">
        <div class="hero-content">
            <h1 id="animTitle" class="hero-title-hidden">StarTech Pro</h1>
            <div id="animSub" class="hero-fade-hidden">
                <h2>La puissance à l'état pur.</h2>
                <div class="cta-links" style="margin-top: 20px;">
                    <a href="/startech/public/catalogue.php" class="btn-buy">Acheter</a>
                </div>
            </div>
        </div>
        <div id="animImage" class="hero-image-container hero-image-hidden">
            <img src="/startech/assets/images/startech-logo.png" alt="StarTech" class="hero-img">
        </div>
    </section>

    <section class="product-showcase container">
        
        <div class="grid-row-2">
            <div class="tile tile-large light-bg">
                <div class="tile-content">
                    <h3>MacBook Air 15"</h3>
                    <p>Impressionnant de finesse.</p>
                    <a href="/startech/public/detail_produit.php?id=1" class="link-blue">Acheter ></a>
                </div>
                <img src="/startech/assets/images/macbook-air.jpg" alt="MacBook Air">
            </div>
            <div class="tile tile-large dark-bg">
                <div class="tile-content text-white">
                    <h3>MacBook Pro 14"</h3>
                    <p>Il a tout pour lui.</p>
                    <a href="/startech/public/detail_produit.php?id=2" class="link-blue">Acheter ></a>
                </div>
                <img src="/startech/assets/images/macbook-pro.jpg" alt="MacBook Pro">
            </div>
        </div>

        <h3 class="section-title">Le son StarTech.</h3>
        <div class="grid-row-3">
            <div class="tile tile-medium">
                <h4>AirPods 3e gen</h4>
                <img src="/startech/assets/images/airpods-3.jpg" alt="AirPods">
            </div>
            <div class="tile tile-medium">
                <h4>AirPods Pro</h4>
                <p class="promo-text">Nouveauté</p>
                <img src="/startech/assets/images/airpods-pro.jpg" alt="AirPods Pro">
            </div>
            <div class="tile tile-medium">
                <h4>AirPods Max</h4>
                <img src="/startech/assets/images/airpods-max.jpg" alt="Casque">
            </div>
        </div>

        <h3 class="section-title">Accessoires essentiels.</h3>
        <div class="grid-row-4">
            <div class="tile tile-small">
                <img src="/startech/assets/images/chargeur-20w.jpg" alt="Chargeur">
                <p>Adaptateur 20W</p>
            </div>
            <div class="tile tile-small">
                <img src="/startech/assets/images/cable-usbc.jpg" alt="Cable">
                <p>Câble Tressé</p>
            </div>
            <div class="tile tile-small">
                <img src="/startech/assets/images/magsafe.jpg" alt="Magsafe">
                <p>MagSafe</p>
            </div>
            <div class="tile tile-small">
                <img src="/startech/assets/images/coque-silicone.jpg" alt="Coque">
                <p>Coque Silicone</p>
            </div>
        </div>

    </section>

 <footer>
    <div class="container footer-content">
        <p>Copyright © 2025 StarTech Inc. Tous droits réservés.</p>
        <div class="footer-links">
            <a href="/startech/public/confidentialite.php">Confidentialité</a> | 
            <a href="/startech/public/a_propos.php">À propos de nous</a> | 
            <a href="/startech/public/support.php">Support</a>
        </div>
    </div>
</footer>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const title = document.getElementById('animTitle');
    const sub = document.getElementById('animSub');
    const image = document.getElementById('animImage');

    setTimeout(() => {
        if(title) title.classList.add('is-visible');
        if(sub) sub.classList.add('is-visible');
        if(image) image.classList.add('is-visible');
    }, 100); 
});
</script>

</body>
</html>