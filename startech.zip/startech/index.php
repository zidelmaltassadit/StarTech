<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Solution ERP Complète</title>
    <link rel="stylesheet" href="assets/css/style.css"> 
    <link rel="stylesheet" href="assets/css/index_style.css"> 
</head>
<body>

    <div class="header-container">
        <header class="text-center pt-5 pb-3">
            <h1 class="logo-title">⭐ StarTech</h1>
            <p class="subtitle">Votre solution ERP complète pour une gestion optimisée de votre entreprise</p>
        </header>
    </div>

    <div class="container mt-5">
        <div class="role-selection-grid">
            
            <div class="role-card client-card">
                <span class="icon icon-blue">🛒</span>
                <h2>Espace Client</h2>
                <p>Accédez au catalogue, gérez votre panier et suivez vos commandes.</p>
                <a href="public/login.php" class="btn btn-primary btn-full">Se connecter</a>
            </div>
            
            <div class="role-card fournisseur-card">
                <span class="icon icon-green">🚚</span>
                <h2>Espace Fournisseur</h2>
                <p>Gérez vos produits et surveillez les niveaux de stock.</p>
                <a href="public/login.php" class="btn btn-success btn-full">Se connecter</a>
            </div>
            
            <div class="role-card admin-card">
                <span class="icon icon-purple">⚙️</span>
                <h2>Espace Administrateur</h2>
                <p>Tableau de bord complet pour la gestion de l'entreprise.</p>
                <a href="public/login.php" class="btn btn-purple btn-full">Se connecter</a>
            </div>

        </div>
    </div>
</body>
</html>