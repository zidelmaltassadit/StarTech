<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StarTech - Le futur, aujourd'hui.</title>
    
    <link rel="stylesheet" href="assets/css/style.css"> 
    <link rel="stylesheet" href="assets/css/index_style.css"> 
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

   <nav class="apple-nav">
    <div class="nav-content">
        <a href="index.php" class="nav-logo">StarTech</a>
        <ul class="nav-links">
            <li><a href="public/catalogue.php?cat=mac">Mac</a></li>
            <li><a href="public/catalogue.php?cat=ipad">iPad</a></li>
            <li><a href="public/catalogue.php?cat=iphone">iPhone</a></li>
            <li><a href="public/catalogue.php?cat=audio">Audio</a></li>
            <li><a href="public/catalogue.php?cat=accessoires">Accessoires</a></li>
        </ul>
        <div class="nav-icons">
            <a href="#"><i class="fa-solid fa-magnifying-glass"></i></a>
            <a href="public/panier.php"><i class="fa-solid fa-bag-shopping"></i></a>
            
            <div class="user-dropdown-container">
                <a href="#" class="user-icon"><i class="fa-regular fa-user"></i></a>
                <div class="dropdown-menu">
                    <a href="public/login.php?role=client">Espace Client</a>
                    <a href="public/login.php?role=fournisseur">Portail Fournisseur</a>
                    <div class="divider"></div>
                    <a href="public/login.php?role=admin">Administration</a>
                </div>
            </div>
        </div>
    </div>
</nav>

    <section class="hero-banner">
        <div class="hero-content">
            <h1 class="fade-in">StarBook Pro</h1>
            <h2 class="fade-in-delay">La puissance à l'état pur.</h2>
            <div class="cta-links fade-in-delay-2">
                <a href="public/detail_produit.php?id=1" class="link-blue">En savoir plus ></a>
                <a href="public/catalogue.php" class="btn-buy">Acheter</a>
            </div>
        </div>
        <div class="hero-image-container">
            <img src="assets/images/macbook-hero.jpg" alt="StarBook Pro" class="hero-img">
        </div>
    </section>

    <section class="product-showcase container">
        
        <div class="grid-row-2">
            <div class="tile tile-large light-bg">
                <div class="tile-content">
                    <h3>MacBook Air 15"</h3>
                    <p>Impressionnant de finesse.</p>
                    <a href="#" class="link-blue">Acheter ></a>
                </div>
                <img src="assets/images/macbook-air.jpg" alt="MacBook Air">
            </div>
            <div class="tile tile-large dark-bg">
                <div class="tile-content text-white">
                    <h3>MacBook Pro 14"</h3>
                    <p>Il a tout pour lui.</p>
                    <a href="#" class="link-blue">Acheter ></a>
                </div>
                <img src="assets/images/macbook-pro.jpg" alt="MacBook Pro">
            </div>
        </div>

        <h3 class="section-title">Le son StarTech.</h3>
        <div class="grid-row-3">
            <div class="tile tile-medium">
                <h4>AirPods 3e gen</h4>
                <img src="assets/images/airpods-3.jpg" alt="AirPods">
            </div>
            <div class="tile tile-medium">
                <h4>AirPods Pro</h4>
                <p class="promo-text">Nouveauté</p>
                <img src="assets/images/airpods-pro.jpg" alt="AirPods Pro">
            </div>
            <div class="tile tile-medium">
                <h4>AirPods Max</h4>
                <img src="assets/images/airpods-max.jpg" alt="Casque">
            </div>
        </div>

        <h3 class="section-title">Accessoires essentiels.</h3>
        <div class="grid-row-4">
            <div class="tile tile-small">
                <img src="assets/images/chargeur-20w.jpg" alt="Chargeur">
                <p>Adaptateur 20W</p>
            </div>
            <div class="tile tile-small">
                <img src="assets/images/cable-usbc.jpg" alt="Cable">
                <p>Câble Tressé</p>
            </div>
            <div class="tile tile-small">
                <img src="assets/images/magsafe.jpg" alt="Magsafe">
                <p>MagSafe</p>
            </div>
            <div class="tile tile-small">
                <img src="assets/images/coque-silicone.jpg" alt="Coque">
                <p>Coque Silicone</p>
            </div>
        </div>

    </section>

    <footer>
        <div class="container footer-content">
            <p>Copyright © 2025 StarTech Inc. Tous droits réservés.</p>
            <div class="footer-links">
                <a href="#">Confidentialité</a> | 
                <a href="#">Ventes</a> | 
                <a href="public/login.php">Connexion</a>
            </div>
        </div>
    </footer>

</body>
</html>