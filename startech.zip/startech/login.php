<?php
// ==========================================================
// FICHIER : login.php
// CORRECTION CLÉ : Ajout de session_start()
// ==========================================================
session_start(); 

// Inclure les fonctions de DB et d'authentification
// Les chemins sont relatifs à login.php (qui est à la racine de startech/)
require_once 'includes/db_config.php';
require_once 'includes/auth_functions.php';

// Si l'utilisateur est déjà connecté, le rediriger
if (is_logged_in()) {
    if (is_admin()) {
        // Redirection PGI pour les rôles 'admin'
        header('Location: admin/dashboard.php');
    } else {
        // Redirection standard pour les autres utilisateurs (clients, etc.)
        header('Location: index.php'); 
    }
    exit;
}

$error_message = '';

// Traitement du formulaire de connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Utilisation de 'user_name' comme clé de session pour correspondre à admin_header.php
    $session_name_key = 'user_name'; 

    if (empty($email) || empty($password)) {
        $error_message = "Veuillez remplir tous les champs.";
    } else {
        try {
            // 1. Préparer la requête SQL pour récupérer l'utilisateur
            $sql = "SELECT id, nom, mot_de_passe, role FROM utilisateurs WHERE email = :email";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            // 2. Récupérer l'utilisateur
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // 3. Vérifier si l'utilisateur existe et si le mot de passe correspond au hash
            if ($user && password_verify($password, $user['mot_de_passe'])) {
                
                // Connexion réussie : enregistrer les variables de session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION[$session_name_key] = $user['nom'];
                $_SESSION['user_role'] = $user['role'];

                // 4. Redirection sécurisée selon le rôle
                if (in_array($user['role'], ['admin', 'logistique', 'production', 'rh'])) {
                    header('Location: admin/dashboard.php');
                } else {
                    // Rôle client par défaut
                    header('Location: index.php');
                }
                exit;

            } else {
                $error_message = "Email ou mot de passe incorrect.";
            }
        } catch (PDOException $e) {
            $error_message = "Erreur base de données : Problème lors de la connexion. (Veuillez vérifier db_config.)";
        } catch (Exception $e) {
             $error_message = "Une erreur inattendue est survenue.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - StarTech PGI & E-commerce</title>
    <link rel="stylesheet" href="assets/css/style.css"> 
    <style>
        /* Styles en ligne pour éviter le 404 sur les CSS externes si elles ne sont pas chargées */
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); width: 350px; }
        h1, h2 { text-align: center; color: #333; }
        form div { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="email"], input[type="password"] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #0056b3; }
        .error { color: red; border: 1px solid red; padding: 10px; margin-bottom: 15px; border-radius: 4px;}
        .alert-warning, .alert-danger { 
            padding: 10px; 
            margin-bottom: 15px;
            border-radius: 4px;
            color: #856404; 
            background-color: #fff3cd; 
            border: 1px solid #ffeeba;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>StarTech</h1>
        <h2>Connexion au Portail</h2>

        <?php 
        // Affichage des messages flash de redirection
        if (isset($_SESSION['flash_message'])) {
            echo $_SESSION['flash_message'];
            unset($_SESSION['flash_message']); // Supprimer le message après l'affichage
        }

        // Affichage des messages d'erreur de connexion
        if ($error_message) {
            echo "<p class='error'>$error_message</p>";
        } 
        ?>

        <form action="login.php" method="POST">
            <div>
                <label for="email">Email :</label>
                <input type="email" id="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div>
                <label for="password">Mot de passe :</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Se connecter</button>
        </form>

        <p style="text-align: center; margin-top: 20px;">
            <a href="register.php">S'inscrire (Client)</a>
        </p>
    </div>
</body>
</html>