<?php
// Inclure la configuration de la base de données et les fonctions d'authentification
require_once 'includes/db_config.php';
require_once 'includes/auth_functions.php';

// Si l'utilisateur est déjà connecté, le rediriger vers l'accueil
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$message = '';
$email_value = ''; // Pour conserver l'email en cas d'erreur

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $email_value = htmlspecialchars($email);

    if (empty($nom) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = "<div class='alert alert-danger'>Veuillez remplir tous les champs.</div>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "<div class='alert alert-danger'>Le format de l'adresse email est invalide.</div>";
    } elseif ($password !== $confirm_password) {
        $message = "<div class='alert alert-danger'>Les mots de passe ne correspondent pas.</div>";
    } elseif (strlen($password) < 6) {
        $message = "<div class='alert alert-danger'>Le mot de passe doit contenir au moins 6 caractères.</div>";
    } else {
        try {
            // Hachage du mot de passe
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Tentative d'insertion
            $sql = "INSERT INTO utilisateurs (nom, email, mot_de_passe, role) VALUES (:nom, :email, :mdp, 'client')";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nom' => $nom,
                ':email' => $email,
                ':mdp' => $hashed_password
            ]);

            $message = "<div class='alert alert-success'>Inscription réussie ! Vous pouvez maintenant vous connecter.</div>";
            // Réinitialiser la valeur de l'email après succès
            $email_value = '';

        } catch (PDOException $e) {
            if ($e->getCode() == '23000') {
                $message = "<div class='alert alert-danger'>Cette adresse email est déjà utilisée.</div>";
            } else {
                $message = "<div class='alert alert-danger'>Erreur base de données : " . $e->getMessage() . "</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription Client - StarTech</title>
    <link rel="stylesheet" href="assets/css/style.css"> 
    <link rel="stylesheet" href="assets/css/admin_style.css"> </head>
<body>
    <header>
        <div class="logo"><a href="index.php"><h2>StarTech</h2></a></div>
        <nav><a href="login.php">Connexion</a></nav>
    </header>

    <div class="container" style="max-width: 500px; margin-top: 50px;">
        <div class="card">
            <h2>Inscription Client</h2>
            
            <?php echo $message; ?>

            <form action="register.php" method="POST">
                <div class="form-group">
                    <label for="nom">Nom Complet :</label>
                    <input type="text" id="nom" name="nom" required value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" required value="<?= $email_value ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Mot de passe (min 6 caractères) :</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirmer Mot de passe :</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>

                <button type="submit" class="btn btn-success">S'inscrire</button>
            </form>
            
            <p style="margin-top: 20px; text-align: center;">Déjà un compte ? <a href="login.php">Connectez-vous ici</a></p>
        </div>
    </div>
</body>
</html>