<?php
/**
 * Fichier : includes/auth_functions.php
 * Fonctions utilitaires pour la gestion de l'authentification et des sessions.
 */

/**
 * Vérifie si un utilisateur est actuellement connecté.
 * @return bool
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// --- RÔLES ---

/**
 * Vérifie si l'utilisateur est connecté et a le rôle 'admin'.
 * @return bool
 */
function is_admin() {
    return is_logged_in() && ($_SESSION['user_role'] ?? '') === 'admin';
}

/**
 * Vérifie si l'utilisateur est connecté et a le rôle 'fournisseur'.
 * @return bool
 */
function is_fournisseur() {
    return is_logged_in() && ($_SESSION['user_role'] ?? '') === 'fournisseur';
}

/**
 * Vérifie si l'utilisateur est connecté et a le rôle 'client'.
 * (Utile pour certaines vues publiques)
 * @return bool
 */
function is_client() {
    // Si l'utilisateur est connecté mais n'est ni admin ni fournisseur, il est client par défaut
    return is_logged_in() && ($_SESSION['user_role'] ?? '') === 'client';
}

// --- EXIGENCES DE SÉCURITÉ (Require) ---

/**
 * Exige la connexion et redirige l'utilisateur vers la page de connexion s'il n'est pas connecté.
 */
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['flash_message'] = "<div class='alert-warning'>Veuillez vous connecter pour accéder à cette page.</div>";
        // Redirection vers le login public (chemin: ../public/login.php)
        header('Location: ../public/login.php'); 
        exit;
    }
}

/**
 * Exige que l'utilisateur soit Administrateur.
 * Détruit la session en cas d'accès refusé pour briser la boucle de redirection.
 */
function require_admin() {
    if (!is_admin()) {
        // Détruire la session existante pour forcer l'utilisateur à se reconnecter
        $_SESSION = array(); // Vider le tableau de session
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy(); // Détruire la session

        $_SESSION['flash_message'] = "<div class='alert-danger'>Accès Administrateur refusé. Veuillez vous reconnecter.</div>";
        
        // Redirection vers le login public (le point d'entrée unique)
        header('Location: ../public/login.php'); 
        exit;
    }
}

/**
 * Exige que l'utilisateur soit Fournisseur.
 * Détruit la session en cas d'accès refusé.
 */
function require_fournisseur() {
    if (!is_fournisseur()) {
        // Détruire la session
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();

        $_SESSION['flash_message'] = "<div class='alert-danger'>Accès Fournisseur refusé. Veuillez vous reconnecter.</div>";
        header('Location: ../public/login.php'); 
        exit;
    }
}