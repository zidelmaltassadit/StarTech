<?php
// includes/stock_functions.php

/**
 * Enregistre un mouvement de stock et met à jour la quantité totale du produit.
 * * @param PDO $pdo
 * @param int $produit_id
 * @param string $type_mouvement 'entree' ou 'sortie'
 * @param int $quantite
 * @param string $reference_doc Référence du document (ex: Commande #10)
 * @throws Exception Si la quantité en stock est insuffisante pour une sortie.
 */
function enregistrer_mouvement_stock(PDO $pdo, int $produit_id, string $type_mouvement, int $quantite, string $reference_doc)
{
    if ($quantite <= 0) {
        throw new Exception("La quantité pour le mouvement doit être positive.");
    }

    $pdo->beginTransaction();
    try {
        // 1. Lire le stock actuel
        $sql_select = "SELECT stock FROM produits WHERE id = ?";
        $stmt_select = $pdo->prepare($sql_select);
        $stmt_select->execute([$produit_id]);
        $produit = $stmt_select->fetch(PDO::FETCH_ASSOC);

        if (!$produit) {
            throw new Exception("Produit #{$produit_id} non trouvé.");
        }

        $nouveau_stock = $produit['stock'];

        // 2. Calculer le nouveau stock
        if ($type_mouvement === 'sortie') {
            if ($produit['stock'] < $quantite) {
                // IMPORTANT : Dans un vrai PGI, cela pourrait être une erreur bloquante.
                throw new Exception("Stock insuffisant pour le produit #{$produit_id}. Requis: {$quantite}, Disponible: {$produit['stock']}.");
            }
            $nouveau_stock -= $quantite;
        } elseif ($type_mouvement === 'entree' || $type_mouvement === 'ajustement') {
            $nouveau_stock += $quantite;
        } else {
            throw new Exception("Type de mouvement de stock inconnu.");
        }
        
        // 3. Mettre à jour la quantité de stock dans la table produits
        $sql_update_stock = "UPDATE produits SET stock = ? WHERE id = ?";
        $pdo->prepare($sql_update_stock)->execute([$nouveau_stock, $produit_id]);
        
        // 4. Enregistrer le mouvement de stock dans la table mouvements_stock
        $sql_insert_mouv = "
            INSERT INTO mouvements_stock (produit_id, type_mouvement, quantite, reference_doc)
            VALUES (?, ?, ?, ?)
        ";
        $pdo->prepare($sql_insert_mouv)->execute([
            $produit_id,
            $type_mouvement,
            $quantite,
            $reference_doc
        ]);

        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Traite la sortie de stock complète d'une commande client.
 * Elle est généralement appelée lorsque la commande passe au statut 'livre' ou 'expediee'.
 * * @param PDO $pdo
 * @param int $commande_id
 * @throws Exception Si la commande est introuvable ou si le stock est insuffisant.
 */
function enregistrer_sortie_stock_commande(PDO $pdo, int $commande_id)
{
    // On pourrait ici vérifier le statut de la commande pour éviter les sorties multiples.
    $reference = "Commande #{$commande_id}";

    // 1. Récupérer les détails de la commande
    $sql_details = "SELECT produit_id, quantite FROM commande_details WHERE commande_id = ?";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([$commande_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

    if (empty($details)) {
        throw new Exception("La commande #{$commande_id} n'a pas de détails de produits.");
    }
    
    // 2. Traiter chaque ligne (chaque ligne sera une transaction de mouvement)
    foreach ($details as $detail) {
        $produit_id = $detail['produit_id'];
        $quantite = $detail['quantite'];
        
        // La fonction enregistrer_mouvement_stock gère sa propre transaction et la mise à jour du stock
        // Nous allons l'appeler pour chaque ligne pour garantir l'atomicité de chaque sortie produit.
        enregistrer_mouvement_stock($pdo, $produit_id, 'sortie', $quantite, $reference);
    }
    
    // Après toutes les sorties de stock réussies, vous devriez idéalement mettre à jour 
    // un champ de la table `commandes` pour indiquer que le stock a été traité.
    // Par exemple: `statut_stock ENUM('en_attente', 'sorti')`
}