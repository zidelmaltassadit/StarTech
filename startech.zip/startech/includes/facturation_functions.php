<?php
// startech/includes/facturation_functions.php

/**
 * Génère une facture complète à partir d'une commande de vente existante.
 * @param PDO $pdo
 * @param int $commande_id
 * @return int L'ID de la nouvelle facture.
 * @throws Exception Si la commande n'est pas prête à être facturée.
 */
function generer_facture_depuis_commande(PDO $pdo, int $commande_id): int
{
    $pdo->beginTransaction();
    try {
        // 1. Récupérer les données de la commande
        $sql_cmd = "SELECT * FROM commandes WHERE id = :id AND statut IN ('livre', 'expediee') AND statut_facturation = 'non_facture'";
        $stmt_cmd = $pdo->prepare($sql_cmd);
        $stmt_cmd->execute([':id' => $commande_id]);
        $commande = $stmt_cmd->fetch(PDO::FETCH_ASSOC);

        if (!$commande) {
            throw new Exception("La commande #{$commande_id} n'est pas prête à être facturée ou n'existe pas.");
        }

        // 2. Insérer l'en-tête de la facture
        $sql_facture = "
            INSERT INTO factures 
            (commande_id, date_facture, total_ht, total_tva, total_ttc) 
            VALUES (:commande_id, NOW(), :total_ht, :total_tva, :total_ttc)
        ";
        $stmt_facture = $pdo->prepare($sql_facture);
        $stmt_facture->execute([
            ':commande_id' => $commande_id,
            ':total_ht' => $commande['total_ht'],
            ':total_tva' => $commande['total_ttc'] - $commande['total_ht'], // Calcul rapide de la TVA
            ':total_ttc' => $commande['total_ttc']
        ]);
        $facture_id = $pdo->lastInsertId();

        // 3. Récupérer les détails de la commande
        $sql_details = "SELECT produit_id, quantite, prix_unitaire_ht, total_ligne_ht FROM commande_details WHERE commande_id = :id";
        $stmt_details = $pdo->prepare($sql_details);
        $stmt_details->execute([':id' => $commande_id]);
        $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);
        
        // 4. Insérer les détails de la facture
        $sql_insert_detail = "
            INSERT INTO facture_details 
            (facture_id, produit_id, quantite, prix_unitaire_ht, total_ligne_ht) 
            VALUES (:facture_id, :produit_id, :quantite, :prix_unitaire_ht, :total_ligne_ht)
        ";
        $stmt_insert_detail = $pdo->prepare($sql_insert_detail);
        
        foreach ($details as $detail) {
            $stmt_insert_detail->execute([
                ':facture_id' => $facture_id,
                ':produit_id' => $detail['produit_id'],
                ':quantite' => $detail['quantite'],
                ':prix_unitaire_ht' => $detail['prix_unitaire_ht'],
                ':total_ligne_ht' => $detail['total_ligne_ht']
            ]);
        }

        // 5. Mettre à jour le statut de la commande
        $sql_update_cmd = "UPDATE commandes SET statut_facturation = 'facture_generee' WHERE id = :id";
        $stmt_update_cmd = $pdo->prepare($sql_update_cmd);
        $stmt_update_cmd->execute([':id' => $commande_id]);

        $pdo->commit();
        return $facture_id;

    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Enregistre un paiement pour une facture.
 * @param PDO $pdo
 * @param int $facture_id
 * @param float $montant_paye
 * @param string $mode_paiement (non utilisé dans la BD actuelle, juste pour info)
 * @throws Exception Si la facture n'est pas trouvée.
 */
function enregistrer_paiement_facture(PDO $pdo, int $facture_id, float $montant_paye, string $mode_paiement)
{
    $pdo->beginTransaction();
    try {
        // 1. Récupérer la facture
        $sql_facture = "SELECT total_ttc, montant_paye FROM factures WHERE id = :id FOR UPDATE"; // Verrouillage
        $stmt_facture = $pdo->prepare($sql_facture);
        $stmt_facture->execute([':id' => $facture_id]);
        $facture = $stmt_facture->fetch(PDO::FETCH_ASSOC);

        if (!$facture) {
            throw new Exception("Facture non trouvée.");
        }

        $nouveau_montant_paye = $facture['montant_paye'] + $montant_paye;
        $total_ttc = $facture['total_ttc'];
        
        if ($nouveau_montant_paye > $total_ttc) {
             // Empêche le surpaiement
             $montant_paye = $total_ttc - $facture['montant_paye'];
             $nouveau_montant_paye = $total_ttc;
        }

        // Déterminer le statut
        if ($nouveau_montant_paye >= $total_ttc) {
            $statut = 'Payee';
        } elseif ($nouveau_montant_paye > 0) {
            $statut = 'Partielle';
        } else {
            $statut = 'Impayee';
        }

        // 2. Mettre à jour la facture
        $sql_update = "UPDATE factures SET montant_paye = :montant_paye, statut_paiement = :statut WHERE id = :id";
        $stmt_update = $pdo->prepare($sql_update);
        $stmt_update->execute([
            ':montant_paye' => $nouveau_montant_paye,
            ':statut' => $statut,
            ':id' => $facture_id
        ]);

        // Optionnel : Enregistrer le détail du paiement dans une nouvelle table 'journal_paiements' si nécessaire

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}