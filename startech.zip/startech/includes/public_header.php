<?php
// includes/public_header.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Vérification de l'existence du fichier avant inclusion
if (file_exists(__DIR__ . '/auth_functions.php')) {
    require_once __DIR__ . '/auth_functions.php';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StarTech</title>
    
    <link rel="stylesheet" href="/startech/assets/css/style.css"> 
    <link rel="stylesheet" href="/startech/assets/css/index_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        /* ==========================================================
           HEADER STYLE APPLE PREMIUM (Transparence & Flou)
           ========================================================== */
        
        .apple-nav {
            position: sticky;
            top: 0;
            /* Priorité absolue pour passer au-dessus du catalogue */
            z-index: 99999; 
            
            /* LE STYLE PREMIUM : Fond semi-transparent + Flou */
            background-color: rgba(255, 255, 255, 0.8); 
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            
            border-bottom: 1px solid rgba(0,0,0,0.08); /* Bordure très subtile */
            height: 48px; /* Hauteur fine style Apple */
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            
            /* CRUCIAL : Autoriser le menu à dépasser */
            overflow: visible !important;
        }

        .nav-content {
            max-width: 1000px; /* Largeur contenue Apple standard */
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100%;
            padding: 0 20px;
            overflow: visible !important;
        }

        /* LOGO MODIFIÉ : PLUS GRAS */
        .nav-logo {
            font-weight: 700; /* Passé en gras (Bold) */
            font-size: 1.2rem; /* Légèrement plus grand */
            color: #1d1d1f;
            text-decoration: none;
            letter-spacing: -0.5px; /* Approche serrée style Apple */
        }
        
        .nav-links {
            list-style: none;
            display: flex;
            gap: 30px;
            margin: 0;
            padding: 0;
        }

        .nav-links li a {
            color: #1d1d1f;
            font-size: 12px; /* Police petite et élégante */
            text-decoration: none;
            opacity: 0.8;
            transition: opacity 0.2s;
            font-weight: 400;
        }

        .nav-links li a:hover { opacity: 1; }

        .nav-icons {
            display: flex;
            align-items: center;
            gap: 25px;
            height: 100%;
        }

        .nav-icon-link {
            color: #1d1d1f;
            font-size: 0.9rem; /* Icônes fines */
            cursor: pointer;
            opacity: 0.8;
            transition: opacity 0.2s;
        }
        .nav-icon-link:hover { opacity: 1; }

        /* ==========================================================
           MENU DÉROULANT (Style Carte Flottante)
           ========================================================== */
        
        .user-dropdown-container {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
            z-index: 100000;
        }

        /* Zone tampon invisible pour ne pas perdre le hover */
        .user-dropdown-container::after {
            content: '';
            position: absolute;
            top: 100%;
            left: -20px;
            right: -20px;
            height: 20px; /* Pont invisible vers le menu */
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: -10px; /* Léger décalage pour aligner */
            width: 240px;
            
            /* STYLE CARTE FLOTTANTE */
            background-color: #fff;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15); /* Ombre douce et diffuse */
            border-radius: 18px; /* Arrondi Apple */
            padding: 10px;
            border: 1px solid rgba(0,0,0,0.05);
            margin-top: 10px; /* Détaché du header */
            
            z-index: 100001;
            opacity: 0;
            transform: translateY(-10px);
            transition: all 0.2s ease;
        }

        /* Animation d'apparition */
        .user-dropdown-container:hover .dropdown-menu {
            display: block !important;
            opacity: 1;
            transform: translateY(0);
        }

        /* Liens du menu */
        .dropdown-menu a {
            display: block;
            padding: 10px 15px;
            color: #1d1d1f;
            text-decoration: none;
            font-size: 13px;
            border-radius: 10px; /* Hover arrondi */
            transition: background 0.1s;
        }

        .dropdown-menu a:hover {
            background-color: #F5F5F7; /* Gris très clair Apple */
            color: #0071E3; /* Bleu Apple */
        }

        .menu-header {
            padding: 10px 15px;
            font-size: 11px;
            color: #86868b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .dropdown-divider {
            height: 1px;
            background-color: #e5e5e5;
            margin: 5px 10px;
        }

        /* ==========================================================
           BARRE DE RECHERCHE (Isolée et Fixed)
           ========================================================== */
        .search-overlay-fixed {
            position: fixed;
            top: 49px; /* Juste sous le header de 48px */
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0,0,0,0.1);
            padding: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            display: none;
            z-index: 90000;
        }
        .search-overlay-fixed.show { display: block; }
        
        .search-form-wrapper { max-width: 600px; margin: 0 auto; display: flex; position: relative; }
        .search-input-field { 
            width: 100%; 
            padding: 10px 10px 10px 40px; 
            font-size: 1.1rem; 
            border: none; 
            background: transparent;
            outline: none;
            font-weight: 300;
        }
        .search-icon-deco { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: #86868b; }
        .search-close-btn { background: none; border: none; font-size: 1.2rem; cursor: pointer; color: #86868b; }
        .search-close-btn:hover { color: #1d1d1f; }

    </style>
</head>
<body>

<nav class="apple-nav">
    <div class="nav-content">
        <a href="/startech/index.php" class="nav-logo">StarTech</a>
        
        <ul class="nav-links">
            <li><a href="/startech/public/catalogue.php?cat=mac">Mac</a></li>
            <li><a href="/startech/public/catalogue.php?cat=ipad">iPad</a></li>
            <li><a href="/startech/public/catalogue.php?cat=iphone">iPhone</a></li>
            <li><a href="/startech/public/catalogue.php?cat=audio">Audio</a></li>
            <li><a href="/startech/public/catalogue.php?cat=accessoires">Accessoires</a></li>
            <li><a href="/startech/public/support.php">Support</a></li>
        </ul>

        <div class="nav-icons">
            <div class="nav-icon-link" id="toggleSearchBtn"><i class="fa-solid fa-magnifying-glass"></i></div>
            <a href="/startech/public/panier.php" class="nav-icon-link"><i class="fa-solid fa-bag-shopping"></i></a>
            
            <div class="user-dropdown-container">
                <a href="#" class="nav-icon-link" style="padding: 10px 0;"><i class="fa-regular fa-user"></i></a>
                
                <div class="dropdown-menu">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <div class="menu-header">
                            <?= htmlspecialchars($_SESSION['user_prenom'] ?? 'Mon Compte') ?>
                        </div>
                        
                        <?php if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'client'): ?>
                             <a href="/startech/public/client_dashboard.php">Espace Client</a>
                        <?php elseif(isset($_SESSION['user_role']) && ($_SESSION['user_role'] == 'admin' || $_SESSION['user_role'] == 'fournisseur')): ?>
                             <a href="/startech/admin/dashboard.php">Interface Pro</a>
                        <?php endif; ?>
                        
                        <div class="dropdown-divider"></div>
                        <a href="/startech/public/logout.php" style="color: #FF3B30;">Se déconnecter</a>
                    <?php else: ?>
                        <div class="menu-header">Compte</div>
                        <a href="/startech/public/login.php?role=client">Se connecter</a>
                        <a href="/startech/public/register.php">Créer un compte</a>
                        <div class="dropdown-divider"></div>
                        <a href="/startech/public/login.php?role=fournisseur">Accès Fournisseur</a>
                        <a href="/startech/public/login.php?role=admin">Accès Admin</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="search-overlay-fixed" id="searchBar">
    <form action="/startech/public/catalogue.php" method="GET" class="search-form-wrapper">
        <i class="fa-solid fa-magnifying-glass search-icon-deco"></i>
        <input type="text" name="q" placeholder="Rechercher sur StarTech..." class="search-input-field" id="searchInputField" autocomplete="off">
        <button type="button" class="search-close-btn" id="closeSearchBtn">✕</button>
    </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const toggleBtn = document.getElementById('toggleSearchBtn');
    const searchBar = document.getElementById('searchBar');
    const closeBtn = document.getElementById('closeSearchBtn');
    
    if(toggleBtn && searchBar) {
        toggleBtn.addEventListener('click', () => {
            searchBar.classList.add('show');
            setTimeout(() => document.getElementById('searchInputField').focus(), 100);
        });
        closeBtn.addEventListener('click', () => {
            searchBar.classList.remove('show');
        });
        // Fermer avec Echap
        document.addEventListener('keydown', (e) => {
            if (e.key === "Escape" && searchBar.classList.contains('show')) {
                searchBar.classList.remove('show');
            }
        });
    }
});
</script>
</body>
</html>