</main> <footer>
    <div class="container footer-content">
        <p>Copyright © 2025 StarTech Inc. Tous droits réservés.</p>
        <div class="footer-links">
            <a href="confidentialite.php">Confidentialité</a> | 
            <a href="#">Ventes</a> | 
            <a href="login.php">Connexion</a>
        </div>
    </div>
</footer>

</body>
</html>