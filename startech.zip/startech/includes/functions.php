<?php
// includes/functions.php

/**
 * Formate un montant en ajoutant la devise et les séparateurs de milliers/décimaux.
 * @param float $montant Le montant à formater.
 * @return string Le montant formaté.
 */
function format_montant($montant) {
    // Note: Dans le front-office, nous calculons souvent le TTC directement.
    return number_format((float)$montant, 2, ',', ' ') . ' €';
}

/**
 * Fonction d'aide pour le catalogue client qui calcule le TTC.
 * @param float $montant_ht Le montant Hors Taxes.
 * @param float $taux_tva Le taux de TVA (ex: 0.20 pour 20%).
 * @return string Le montant formaté en TTC.
 */
function format_montant_ttc($montant_ht, $taux_tva = 0.20) {
    $montant_ttc = $montant_ht * (1 + $taux_tva);
    return number_format((float)$montant_ttc, 2, ',', ' ') . ' € TTC';
}

/**
 * Calcule les totaux (HT et TTC) du panier.
 * Nécessite que chaque article du panier contienne 'prix_ht', 'prix_ttc' et 'quantite'.
 *
 * @param array $panier Le tableau du panier ($_SESSION['panier']).
 * @return array Un tableau associatif contenant 'total_ht' et 'total_ttc'.
 */
function calculer_total_panier($panier) {
    $total_ht = 0.0;
    $total_ttc = 0.0;
    
    // Si le panier est vide ou null, retourner 0.0
    if (empty($panier)) {
        return ['total_ht' => 0.0, 'total_ttc' => 0.0];
    }

    foreach ($panier as $item) {
        // Assurez-vous que les clés nécessaires existent avant d'accéder
        $quantite = (float)($item['quantite'] ?? 0);
        $prix_ht = (float)($item['prix_ht'] ?? 0);
        $prix_ttc = (float)($item['prix_ttc'] ?? 0);

        // Cette logique suppose que les prix HT et TTC sont stockés dans la session (panier).
        $total_ht += $prix_ht * $quantite;
        $total_ttc += $prix_ttc * $quantite;
    }

    // Arrondir à deux décimales pour la précision monétaire
    return [
        'total_ht' => round($total_ht, 2),
        'total_ttc' => round($total_ttc, 2)
    ];
}

/**
 * Formate le statut pour l'affichage (ex: 'en_attente' devient 'En attente').
 * @param string $statut Le statut de la commande.
 * @return string Le statut formaté.
 */
function format_statut($statut) {
    return ucfirst(str_replace('_', ' ', $statut));
}
?>