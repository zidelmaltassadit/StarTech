<?php
// public/detail_commande.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 

// --- Préparation et Sécurité ---

// 1. Exiger la connexion client
if (!is_logged_in()) {
    header('Location: login.php');
    exit();
}

$client_id = $_SESSION['user_id'] ?? null;
$commande_id = (int)($_GET['id'] ?? 0);
$commande = null;
$lignes_commande = [];
$message = '';

if ($commande_id === 0 || !$client_id) {
    header('Location: client_dashboard.php'); // Rediriger si ID manquant
    exit();
}

// Fonction utilitaire de formatage (si non incluse dans functions.php)
function format_montant($montant) {
    return number_format((float)$montant, 2, ',', ' ') . ' €';
}

function format_statut($statut) {
    $statuts = [
        'en_attente_paiement' => '🟡 Attente Paiement',
        'en_cours_traitement' => '🟠 Traitement en cours',
        'expediee' => '🔵 Expédiée',
        'livree' => '🟢 Livrée',
        'annulee' => '🔴 Annulée'
    ];
    return $statuts[$statut] ?? $statut;
}

try {
    // 2. Récupérer la commande (avec vérification du propriétaire : WHERE client_id = :client_id)
    $sql_commande = "SELECT id, date_commande, statut, total_ht, total_ht * 1.20 AS total_ttc 
                     FROM commandes 
                     WHERE id = :id AND client_id = :client_id";
    $stmt_commande = $pdo->prepare($sql_commande);
    $stmt_commande->execute([':id' => $commande_id, ':client_id' => $client_id]);
    $commande = $stmt_commande->fetch(PDO::FETCH_ASSOC);

    if (!$commande) {
        $message = "<div class='alert-danger'>Commande non trouvée ou vous n'avez pas l'autorisation d'y accéder.</div>";
    } else {
        // 3. Récupérer les lignes de commande
        $sql_lignes = "SELECT lc.quantite, lc.prix_unitaire_ht, p.nom 
                       FROM lignes_commande lc
                       JOIN produits p ON lc.produit_id = p.id
                       WHERE lc.commande_id = :commande_id";
        $stmt_lignes = $pdo->prepare($sql_lignes);
        $stmt_lignes->execute([':commande_id' => $commande_id]);
        $lignes_commande = $stmt_lignes->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (PDOException $e) {
    $message = "<div class='alert-danger'>Erreur de base de données : Impossible de charger les détails.</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détail Commande #<?= $commande_id ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Détail Commande</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (<?= count($_SESSION['panier'] ?? []) ?>)</a>
                <a href="client_dashboard.php">Mon Compte</a>
            </nav>
        </div>
    </header>

    <div class="container public-content">
        <h2>Détail Commande #<?= $commande_id ?></h2>
        
        <p><a href="client_dashboard.php">&larr; Retour à l'historique</a></p>
        
        <?= $message; ?>

        <?php if ($commande): ?>
            <div class="commande-summary-details">
                <p><strong>Date de commande :</strong> <?= (new DateTime($commande['date_commande']))->format('d/m/Y à H:i') ?></p>
                <p><strong>Statut actuel :</strong> <?= format_statut($commande['statut']) ?></p>
            </div>
            
            <hr>
            
            <h3>Articles Commandés</h3>
            <?php if (!empty($lignes_commande)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Produit</th>
                            <th class="text-center">Quantité</th>
                            <th class="text-right">Prix Unitaire HT</th>
                            <th class="text-right">Sous-Total HT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lignes_commande as $ligne): 
                            $sous_total_ht = $ligne['prix_unitaire_ht'] * $ligne['quantite'];
                        ?>
                            <tr>
                                <td><?= htmlspecialchars($ligne['nom']) ?></td>
                                <td class="text-center"><?= htmlspecialchars($ligne['quantite']) ?></td>
                                <td class="text-right"><?= format_montant($ligne['prix_unitaire_ht']) ?></td>
                                <td class="text-right"><strong><?= format_montant($sous_total_ht) ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="total-box-right">
                    <p>Total HT : <strong><?= format_montant($commande['total_ht']) ?></strong></p>
                    <p>TVA (20%) : <?= format_montant($commande['total_ttc'] - $commande['total_ht']) ?></p>
                    <p class="final-total">TOTAL TTC : 
                        <strong style="font-size: 1.2em;"><?= format_montant($commande['total_ttc']) ?></strong>
                    </p>
                </div>
            <?php else: ?>
                <p class="alert alert-warning">Aucun article trouvé pour cette commande.</p>
            <?php endif; ?>

            <?php if ($commande['statut'] === 'en_attente_paiement'): ?>
                <div class="action-zone">
                    <a href="#" class="btn btn-success">Procéder au Paiement</a>
                </div>
            <?php endif; ?>
            
        <?php endif; ?>
        
    </div>
</body>
</html>