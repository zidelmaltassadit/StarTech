<?php
// public/catalogue.php (VERSION CORRIGÉE ET FONCTIONNELLE)

// 1. AFFICHER LES ERREURS (Utile pour le dev, à désactiver en prod)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrage session si nécessaire
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// 2. INCLUSIONS
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 
require_once '../includes/functions.php';

// 3. SÉCURITÉ (Redirection des rôles internes)
if (is_logged_in()) {
    $pgi_roles = ['admin', 'administrateur', 'logistique', 'production', 'rh', 'commercial', 'comptabilite'];
    $current_role = strtolower(trim($_SESSION['user_role'] ?? ''));
    if (in_array($current_role, $pgi_roles)) {
        header('Location: ../admin/dashboard.php'); exit;
    } elseif ($current_role === 'fournisseur') {
        header('Location: ../admin/fournisseur_dashboard.php'); exit;
    }
}

// 4. RÉCUPÉRATION DES PARAMÈTRES (C'EST ICI QUE C'ÉTAIT CASSÉ)
$cat_filter = isset($_GET['cat']) ? trim($_GET['cat']) : '';

// --- CORRECTIF : On définit $search_query AVANT de l'utiliser ---
$search_query = isset($_GET['q']) ? trim($_GET['q']) : ''; 
// -----------------------------------------------------------------

$page_title = "Tous nos produits";
$produits = [];
$message = '';

try {
    if (!empty($cat_filter)) {
        // --- CAS 1 : FILTRE PAR CATÉGORIE ---
        $sql = "SELECT p.*, c.nom as nom_categorie
                FROM produits p
                JOIN categories c ON p.categorie_id = c.id
                WHERE p.quantite_stock > 0 AND p.statut = 'actif' AND c.nom LIKE :cat_nom
                ORDER BY p.nom ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':cat_nom' => $cat_filter . '%']);
        $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $page_title = ucfirst($cat_filter);
        
    } elseif (!empty($search_query)) {
        // --- CAS 2 : RECHERCHE TEXTUELLE ---
        // Maintenant cette condition va fonctionner sans erreur
        $sql = "SELECT * FROM produits 
                WHERE quantite_stock > 0 
                AND statut = 'actif'
                AND (nom LIKE :search OR description LIKE :search)
                ORDER BY nom ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':search' => '%' . $search_query . '%']);
        $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $page_title = "Recherche : \"" . htmlspecialchars($search_query) . "\"";
        if (empty($produits)) {
             $message = "<div class='alert alert-info' style='text-align:center;'>Aucun résultat pour votre recherche.</div>";
        }

    } else {
        // --- CAS 3 : TOUT AFFICHER (Par défaut) ---
        $sql = "SELECT * FROM produits WHERE quantite_stock > 0 AND statut = 'actif' ORDER BY nom ASC";
        $stmt = $pdo->query($sql);
        $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur SQL : " . $e->getMessage() . "</div>";
}

// ==============================================================================
// 5. INCLUSION DU HEADER (L'AFFICHAGE COMMENCE ICI)
// ==============================================================================
require_once '../includes/public_header.php';
?>

<style>
    /* CSS spécifique au catalogue */
    body { background-color: #F5F5F7; }
    .catalogue-header { text-align: center; padding: 60px 20px 40px; }
    .catalogue-header h1 { font-size: 2.5rem; font-weight: 700; color: #1D1D1F; }
    .catalogue-header p { color: #86868B; font-size: 1.1rem; margin-top: 10px; }
    
    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 30px;
        padding: 20px 0 60px;
        max-width: 1200px;
        margin: 0 auto;
    }
    
    /* ATTENTION : Le transform ici crée un nouveau contexte d'empilement (stacking context) */
    /* C'est pour ça qu'il faut un z-index TRÈS haut dans le header (voir public_header.php) */
    .product-card {
        background: white;
        border-radius: 18px;
        padding: 30px;
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 100%;
        border: 1px solid rgba(0,0,0,0.02);
        position: relative; /* Sécurité */
        z-index: 1; /* Reste bas */
    }
    
    .product-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
    .product-image { width: 100%; height: 200px; object-fit: contain; margin-bottom: 20px; }
    .product-card h3 { font-size: 1.2rem; font-weight: 600; margin-bottom: 10px; color: #1D1D1F; }
    .product-card .price { font-size: 1.1rem; font-weight: 400; margin: 15px 0; color: #1D1D1F; }
    
    .btn-group { display: flex; gap: 10px; justify-content: center; margin-top: auto; }
    .btn-small { padding: 8px 16px; font-size: 0.85rem; border-radius: 980px; text-decoration: none;}
    .btn-outline { background: transparent; border: 1px solid #0071E3; color: #0071E3; }
    .btn-outline:hover { background: #E8F2FF; }
    .btn-primary { background: #0071E3; color: white; border: 1px solid #0071E3; }
    .btn-primary:hover { background: #0077ED; }
</style>

<header class="catalogue-header">
    <h1><?= htmlspecialchars($page_title) ?></h1>
    <p>Découvrez notre sélection <?= !empty($cat_filter) ? "de " . htmlspecialchars($cat_filter) : "de produits premium" ?>.</p>
</header>

<div class="container">
    
    <?= $message; ?>

    <div class="product-grid">
        <?php if (!empty($produits)): ?>
            
            <?php foreach ($produits as $produit): ?>
                <div class="product-card">
                    
                    <?php
                    // Gestion Image
                    $img_name = $produit['image'];
                    if (empty($img_name)) { $img_src = "https://dummyimage.com/300x300/eee/aaa&text=No+Image"; }
                    elseif (strpos($img_name, 'http') === 0) { $img_src = $img_name; }
                    else { $img_src = "/startech/assets/images/" . $img_name; }
                    ?>
                    
                    <img src="<?= htmlspecialchars($img_src) ?>"
                         alt="<?= htmlspecialchars($produit['nom']) ?>"
                         class="product-image">
                    
                    <h3><?= htmlspecialchars($produit['nom']) ?></h3>

                    <div class="price">
                        <?= number_format($produit['prix_vente'], 2, ',', ' ') ?> €
                    </div>
                    
                    <div class="btn-group">
                        <a href="detail_produit.php?id=<?= $produit['id'] ?>" class="btn btn-outline btn-small">En savoir plus</a>
                        <a href="panier_ajout.php?id=<?= $produit['id'] ?>" class="btn btn-primary btn-small">Acheter</a>
                    </div>

                </div>
            <?php endforeach; ?>
            <?php else: ?>
            <div style="grid-column: 1/-1; text-align: center; padding: 50px;">
                <h3 style="color: #86868B;">Aucun produit trouvé dans cette catégorie.</h3>
                <a href="catalogue.php" class="btn btn-primary" style="margin-top:20px;">Voir tout le catalogue</a>
            </div>
        <?php endif; ?>
    </div>
    
</div>

<?php
// PIED DE PAGE
require_once '../includes/public_footer.php';
?>