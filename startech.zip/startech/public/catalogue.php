<?php
// public/catalogue.php
require_once '../includes/db_config.php';
require_once '../includes/functions.php'; // Pour les fonctions de formatage

$message = '';
$produits = [];

try {
    // REQUÊTE SQL NETTOYÉE : Utilisation de 'prix_vente' pour la dernière tentative de correction du prix
    $sql = "SELECT id, nom, description, prix_vente, image 
            FROM produits 
            WHERE quantite_stock > 0 AND statut = 'actif' 
            ORDER BY nom ASC";
    $stmt = $pdo->query($sql);
    $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Affichez l'erreur en mode développement si besoin: $e->getMessage()
    $message = "<div class='alert' style='background-color: #f8d7da; color: #721c24;'>Erreur de base de données : Le catalogue est indisponible pour le moment.</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Catalogue Produits</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css"> 
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Boutique</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (0)</a>
                <a href="login.php">Connexion Client</a>
                <a href="../contact.php">Contact</a>
            </nav>
        </div>
    </header>

    <div class="container public-content">
        <h2>Catalogue de nos Produits</h2>
        
        <?php echo $message; ?>

        <div class="product-grid">
            <?php if (!empty($produits)): ?>
                <?php foreach ($produits as $produit): ?>
                    <div class="product-card">
                        <?php 
                        $image_path = !empty($produit['image']) ? $produit['image'] : 'default.png';
                        
                        // Utilisation du prix récupéré
                        $prix_ht = $produit['prix_vente']; 
                        
                        // Calcul du TTC (Hypothèse 20% si la fonction calculer_ttc n'existe pas)
                        $prix_ttc = function_exists('calculer_ttc') ? calculer_ttc($prix_ht) : $prix_ht * 1.2;
                        ?>
                        
                        <img src="../assets/images/produits/<?= htmlspecialchars($image_path) ?>" 
                             alt="<?= htmlspecialchars($produit['nom']) ?>" 
                             class="product-image">
                        
                        <h3><?= htmlspecialchars($produit['nom']) ?></h3>
                        <p class="description"><?= nl2br(htmlspecialchars($produit['description'])) ?></p>
                        <p class="price">
                            <strong>
                                <?= format_montant($prix_ttc) ?> TTC
                            </strong>
                            <span class="ht">(<?= format_montant($prix_ht) ?> HT)</span>
                        </p>
                        <a href="panier.php?action=add&id=<?= $produit['id'] ?>" class="btn btn-primary">
                            Ajouter au panier
                        </a>
                        <a href="detail_produit.php?id=<?= $produit['id'] ?>" class="btn btn-secondary btn-small">
                            Voir Détails
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="alert alert-info">Aucun produit n'est actuellement disponible en stock.</p>
            <?php endif; ?>
        </div>
        
    </div>
</body>
</html>