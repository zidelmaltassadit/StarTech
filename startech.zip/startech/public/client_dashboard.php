<?php
// public/client_dashboard.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 
require_once '../includes/functions.php'; 

// --- SÉCURITÉ : Exiger la connexion client ---
if (!is_logged_in() || $_SESSION['user_role'] !== 'client') {
    header('Location: login.php'); exit();
}

$client_id = $_SESSION['user_id'];
$client_info = [];
$commandes = [];
// Récupération du message flash (succès de modification par exemple)
$message = '';
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}

// --- RÉCUPÉRATION DES DONNÉES ---
if ($client_id) {
    try {
        // 1. Récupérer les infos + LES ADRESSES
        $sql_client = "SELECT id, nom, email, adresse_livraison, adresse_facturation FROM clients WHERE id = :client_id";
        $stmt_client = $pdo->prepare($sql_client);
        $stmt_client->execute([':client_id' => $client_id]);
        $client_info = $stmt_client->fetch(PDO::FETCH_ASSOC);

        if (!$client_info) { session_unset(); session_destroy(); header('Location: login.php'); exit(); }
        
        // 2. Récupérer l'historique des commandes
        try {
            $sql_commandes = "SELECT id, date_commande, statut, total_ttc FROM commandes WHERE client_id = :client_id ORDER BY date_commande DESC LIMIT 5";
            $stmt_commandes = $pdo->prepare($sql_commandes);
            $stmt_commandes->execute([':client_id' => $client_id]);
            $commandes = $stmt_commandes->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e_cmd) { /* Ignore si pas de table commandes */ }

    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Erreur technique : " . $e->getMessage() . "</div>";
    }
}
$prenom_affichage = explode(' ', $client_info['nom'] ?? 'Client')[0];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Compte - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="client-area-page">

    <nav style="background:rgba(255,255,255,0.8); backdrop-filter:blur(20px); position:sticky; top:0; z-index:100; border-bottom:1px solid rgba(0,0,0,0.05); padding:10px 0;">
        <div class="container" style="display:flex; justify-content:space-between; align-items:center;">
            <a href="../index.php" class="logo-text" style="font-weight:600; color:#1D1D1F; text-decoration:none;">StarTech</a>
            <div class="nav-icons" style="display:flex; gap:20px; align-items:center;">
                <a href="catalogue.php" style="color:#1D1D1F; text-decoration:none;">Catalogue</a>
                <a href="panier.php" style="color:#1D1D1F; text-decoration:none;"><i class="fa-solid fa-bag-shopping"></i></a>
                <a href="logout.php" style="color:#FF3B30; font-size:0.9rem;">Déconnexion</a>
            </div>
        </div>
    </nav>

    <header class="account-header">
        <h1>Bonjour, <?= htmlspecialchars($prenom_affichage) ?>.</h1>
        <p style="color: #86868b; font-size: 1.2rem;">Gérez vos informations et suivez vos commandes.</p>
        <?= $message ?>
    </header>

    <div class="container account-layout">
        
        <div class="layout-col-left">
            <section class="apple-card">
                <h2><i class="fa-regular fa-user-circle"></i> Profil & Sécurité</h2>
                <div class="info-row"><span class="info-label">Nom complet</span><span class="info-value"><?= htmlspecialchars($client_info['nom']) ?></span></div>
                <div class="info-row"><span class="info-label">Adresse Email</span><span class="info-value"><?= htmlspecialchars($client_info['email']) ?></span></div>
                <div class="info-row"><span class="info-label">Mot de passe</span><span class="info-value">••••••••••••</span></div>
                <div style="margin-top: 30px;">
                    <a href="edit_profile.php" class="btn btn-primary" style="display:block; text-align:center; text-decoration:none;">Modifier mes informations</a>
                </div>
            </section>

            <section class="apple-card" style="margin-top: 40px;">
                <h2><i class="fa-regular fa-map"></i> Carnet d'adresses</h2>
                
                <?php if(empty($client_info['adresse_livraison'])): ?>
                    <div class="address-block" style="text-align:center; color:#86868b;">
                        <i class="fa-solid fa-location-dot" style="font-size:2rem; margin-bottom:15px; color:#d2d2d7;"></i>
                        <p>Aucune adresse enregistrée.</p>
                        <a href="edit_profile.php" style="color:#0071e3; font-size:0.9rem;">Ajouter une adresse</a>
                    </div>
                <?php else: ?>
                    <div style="margin-top:20px;">
                         <span class="info-label" style="color:#0071e3;"><i class="fa-solid fa-truck"></i> Livraison par défaut</span>
                         <p style="margin-top:5px; line-height:1.5;"><?= nl2br(htmlspecialchars($client_info['adresse_livraison'])) ?></p>
                    </div>
                    <?php if(!empty($client_info['adresse_facturation'])): ?>
                    <div style="margin-top:20px; border-top:1px solid #e5e5e5; padding-top:20px;">
                         <span class="info-label"><i class="fa-solid fa-file-invoice"></i> Facturation</span>
                         <p style="margin-top:5px; line-height:1.5;"><?= nl2br(htmlspecialchars($client_info['adresse_facturation'])) ?></p>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>

        <div class="layout-col-right">
            <section class="apple-card">
                <h2><i class="fa-solid fa-box-archive"></i> Commandes récentes</h2>
                <?php if (!empty($commandes)): ?>
                    <ul class="orders-list">
                        <?php foreach ($commandes as $cmd): ?>
                        <li class="order-item">
                            <div class="order-info">
                                <strong>Commande #<?= htmlspecialchars($cmd['id']) ?></strong>
                                <small><?= (new DateTime($cmd['date_commande']))->format('d/m/Y') ?> • <?= number_format($cmd['total_ttc'], 2, ',', ' ') ?> €</small>
                            </div>
                            <div><span class="order-status status-en_cours"><?= ucfirst(htmlspecialchars($cmd['statut'])) ?></span></div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px 20px; color: #86868b;">
                        <i class="fa-solid fa-box-open" style="font-size: 3rem; margin-bottom: 20px; color: #d2d2d7;"></i>
                        <p style="font-size:1.1rem; color:#1d1d1f;">Aucune commande pour le moment.</p>
                        <a href="catalogue.php" class="btn btn-outline" style="margin-top: 25px; border-radius:20px; padding:10px 25px; text-decoration:none;">Explorer le catalogue</a>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>

</body>
</html>