<?php
// public/finaliser_commande.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 
require_once '../includes/functions.php'; 

// --- SÉCURITÉ : Exige la connexion
if (!is_logged_in()) {
    $_SESSION['flash_message'] = "<div class='alert-warning'>Veuillez vous connecter pour finaliser votre commande.</div>";
    header('Location: login.php');
    exit();
}

$client_id = $_SESSION['user_id'] ?? null;
$panier = $_SESSION['panier'] ?? [];
$message = $_SESSION['flash_message'] ?? '';
unset($_SESSION['flash_message']);
$client_info = [];
$total_panier = calculer_total_panier($panier); // Supposons cette fonction dans functions.php

if (empty($panier)) {
    $_SESSION['flash_message'] = "<div class='alert-warning'>Votre panier est vide.</div>";
    header('Location: catalogue.php');
    exit();
}

try {
    // 1. Récupérer les infos client (pour l'affichage des adresses par défaut)
    $sql_client = "SELECT nom, prenom, email, telephone, adresse_livraison_defaut, adresse_facturation_defaut FROM clients WHERE id = :id";
    $stmt_client = $pdo->prepare($sql_client);
    $stmt_client->execute([':id' => $client_id]);
    $client_info = $stmt_client->fetch(PDO::FETCH_ASSOC);

    if (!$client_info) {
        throw new Exception("Client non trouvé.");
    }

} catch (Exception $e) {
    $_SESSION['flash_message'] = "<div class='alert-danger'>Erreur critique : Impossible de charger vos informations.</div>";
    header('Location: client_dashboard.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Finalisation de la Commande</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>
    <header class="public-header">
        <div class="container">
            <h1>Finalisation de la Commande</h1>
            <nav><a href="catalogue.php">Catalogue</a></nav>
        </div>
    </header>

    <div class="container public-content">
        <h2>Étape 1 : Vérification & Adresses</h2>
        
        <?= $message; ?>

        <div class="checkout-grid">
            <div class="card summary-card">
                <h3>🛒 Récapitulatif</h3>
                <?php foreach ($panier as $item): ?>
                    <p><?= htmlspecialchars($item['nom']) ?> (x<?= $item['quantite'] ?>) : <?= format_montant($item['prix_ttc'] * $item['quantite']) ?></p>
                <?php endforeach; ?>
                <hr>
                <p><strong>Total TTC : <?= format_montant($total_panier['total_ttc']) ?></strong></p>
                <p>Total HT : <?= format_montant($total_panier['total_ht']) ?></p>
            </div>

            <div class="card form-card">
                <h3>📍 Adresses (Utilisation des adresses par défaut)</h3>
                
                <p><strong>Adresse de Livraison :</strong> <?= nl2br(htmlspecialchars($client_info['adresse_livraison_defaut'] ?? 'Non définie')) ?></p>
                <p><strong>Adresse de Facturation :</strong> <?= nl2br(htmlspecialchars($client_info['adresse_facturation_defaut'] ?? 'Non définie')) ?></p>
                
                <p class="alert-info mt-3">
                    Pour modifier les adresses, veuillez aller sur la page <a href="edit_profile.php">Modifier Profil</a>.
                </p>

                <form action="paiement.php" method="POST" class="mt-4">
                    <input type="hidden" name="action" value="process_order">
                    
                    <h3>🔒 Méthode de Paiement</h3>
                    <div class="form-group">
                        <label>
                            <input type="radio" name="methode_paiement" value="virement" checked> Virement Bancaire (Paiement à la réception)
                        </label><br>
                        <label>
                            <input type="radio" name="methode_paiement" value="carte"> Carte Bancaire (Paiement non implémenté)
                        </label>
                    </div>

                    <p class="alert-warning">
                        En cliquant sur "Confirmer et Payer", vous validez votre commande.
                    </p>
                    <button type="submit" class="btn btn-primary btn-lg">Confirmer et Payer</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>