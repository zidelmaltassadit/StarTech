<?php
// public/panier.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/functions.php'; 

// 🚨 ESSENTIEL : Inclut les fonctions d'authentification comme is_logged_in()
require_once '../includes/auth_functions.php'; 


// Initialisation du panier s'il n'existe pas
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

$action = $_GET['action'] ?? null;
$id_produit = $_GET['id'] ?? null;

// --- GESTION DES MESSAGES FLASH ---
$message_panier = $_SESSION['flash_message'] ?? '';
unset($_SESSION['flash_message']);


// --- Logique du Panier ---

if ($action) {
    
    // 1. Traitement de l'action globale 'empty' 
    if ($action === 'empty') {
        $_SESSION['panier'] = [];
        $_SESSION['flash_message'] = "<div class='alert-info'>Le panier a été vidé.</div>";
        header('Location: panier.php');
        exit();
    }
    
    // 2. Le reste du code ne s'exécute que pour les actions 'add', 'update', 'remove'
    if (in_array($action, ['add', 'update', 'remove']) && $id_produit) {
        
        $id_produit = (int)$id_produit;
        $qte_demandee = (int)($_GET['quantite'] ?? 1); 

        
        // Récupérer les données du produit (si besoin)
        $produit = null;
        try {
            $stmt = $pdo->prepare("SELECT nom, prix_vente, quantite_stock FROM produits WHERE id = ?");
            $stmt->execute([$id_produit]);
            $produit = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $_SESSION['flash_message'] = "<div class='alert-danger'>Erreur de base de données.</div>";
        }

        // Si on a les données du produit ou si l'action est 'remove'
        if ($produit || $action === 'remove') {
            
            switch ($action) {
                case 'add':
                    $quantite_actuelle = $_SESSION['panier'][$id_produit]['quantite'] ?? 0;
                    $quantite_demandee_totale = $quantite_actuelle + $qte_demandee; 
                    
                    if ($quantite_demandee_totale <= $produit['quantite_stock']) {
                        $_SESSION['panier'][$id_produit] = [
                            'id' => $id_produit,
                            'nom' => $produit['nom'],
                            'prix_ht' => $produit['prix_vente'], 
                            'quantite' => $quantite_demandee_totale 
                        ];
                        $_SESSION['flash_message'] = "<div class='alert-success'>Produit ajouté au panier !</div>";
                    } else {
                        // Message générique SANS afficher 'Quantité maximale disponible'
                        $_SESSION['flash_message'] = "<div class='alert-warning'>Stock insuffisant pour cette quantité. Le produit n'a pas été ajouté.</div>";
                    }
                    break;
                    
                case 'update':
                    if (isset($_SESSION['panier'][$id_produit])) {
                        
                        if ($qte_demandee < 1) {
                            // Si la quantité est 0 ou moins, on retire l'article
                            unset($_SESSION['panier'][$id_produit]);
                            $_SESSION['flash_message'] = "<div class='alert-info'>Produit retiré du panier.</div>";
                            
                        } else if ($qte_demandee <= $produit['quantite_stock']) {
                            // CAS NORMAL : La nouvelle quantité est appliquée
                            $_SESSION['panier'][$id_produit]['quantite'] = $qte_demandee;
                            $_SESSION['flash_message'] = "<div class='alert-success'>Quantité mise à jour !</div>";
                        } else {
                            // Message générique sans révéler la quantité exacte en stock
                            // On fixe quand même la quantité au maximum disponible pour éviter un panier invalide
                            $_SESSION['panier'][$id_produit]['quantite'] = $produit['quantite_stock'];
                            $_SESSION['flash_message'] = "<div class='alert-warning'>Stock insuffisant. La quantité a été ajustée au maximum disponible.</div>";
                        }
                    }
                    break;
                    
                case 'remove':
                    if (isset($_SESSION['panier'][$id_produit])) {
                        unset($_SESSION['panier'][$id_produit]);
                        $_SESSION['flash_message'] = "<div class='alert-info'>Produit retiré du panier.</div>";
                    }
                    break;
            }
        }
        
        // Rediriger après toute action sur un produit (PRG)
        header('Location: panier.php');
        exit();
    }
}

// Calcul des totaux
$total_ht = 0;
$total_tva = 0;
$taux_tva = 0.20; // Taux standard pour l'exemple

foreach ($_SESSION['panier'] as $item) {
    $sous_total_ht = $item['prix_ht'] * $item['quantite']; 
    $total_ht += $sous_total_ht;
    $total_tva += $sous_total_ht * $taux_tva;
}
$total_ttc = $total_ht + $total_tva;

// --- Fin Logique du Panier ---
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Mon Panier</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    
    <header class="public-header">
    <div class="container">
        <h1>StarTech - Boutique</h1>
        <nav>
            <a href="catalogue.php">Catalogue</a>
            <a href="panier.php">Panier (<?= count($_SESSION['panier'] ?? []) ?>)</a>
            
            <?php if (is_logged_in()): ?>
                <a href="client_dashboard.php">Mon Compte / Profil</a>
                <a href="logout.php">Déconnexion</a>
            <?php else: ?>
                <a href="login.php">Connexion Client</a> 
            <?php endif; ?>

        </nav>
    </div>
</header>

    <div class="container public-content">
        <h2>🛒 Mon Panier</h2>
        
        <?= $message_panier; ?>
        
        <?php if (!empty($_SESSION['panier'])): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Produit</th>
                        <th class="text-center">Quantité</th>
                        <th class="text-right">Prix U. HT</th>
                        <th class="text-right">Sous-Total HT</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['panier'] as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['nom']) ?></td>
                        <td class="text-center">
                            <input type="number" 
                                            name="quantite_<?= $item['id'] ?>" 
                                            value="<?= htmlspecialchars($item['quantite']) ?>"
                                            min="1" 
                                            style="width: 70px; text-align: center;"
                                            onchange="window.location.href='panier.php?action=update&id=<?= $item['id'] ?>&quantite=' + this.value"
                                            required>
                        </td>
                        <td class="text-right"><?= format_montant($item['prix_ht']) ?> €</td> 
                        <td class="text-right"><?= format_montant($item['prix_ht'] * $item['quantite']) ?> €</td>
                        <td>
                            <a href="panier.php?action=remove&id=<?= $item['id'] ?>" class="btn btn-danger btn-small">Retirer</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="panier-summary">
                <h3>Totaux</h3>
                <p>Total HT: <strong><?= format_montant($total_ht) ?> €</strong></p>
                <p>TVA (20%): <strong><?= format_montant($total_tva) ?> €</strong></p>
                <p class="total-ttc">TOTAL TTC: 
                    <strong style="font-size: 1.5em;"><?= format_montant($total_ttc) ?> €</strong>
                </p>
                
                <div class="panier-actions">
                    <a href="panier.php?action=empty" class="btn btn-secondary">Vider le Panier</a>
                    <a href="checkout.php" class="btn btn-success">Passer à la Caisse &rarr;</a>
                </div>
            </div>
            
        <?php else: ?>
            <p class="alert alert-info">Votre panier est vide. <a href="catalogue.php">Continuez vos achats.</a></p>
        <?php endif; ?>
        
    </div>
</body>
</html>