<?php
// public/panier.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// Gestion Actions (Supprimer / Vider)
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['key'])) {
    unset($_SESSION['panier'][$_GET['key']]);
    header('Location: panier.php'); exit;
}

// Calcul du Total
$total_panier = 0;
if (isset($_SESSION['panier'])) {
    foreach ($_SESSION['panier'] as $item) {
        $total_panier += $item['prix'] * $item['quantite'];
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Votre Panier - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #FFFFFF; }
        .cart-container { max-width: 1000px; margin: 60px auto; padding: 0 20px; }
        
        .cart-header { text-align: center; margin-bottom: 50px; padding-bottom: 40px; border-bottom: 1px solid #d2d2d7; }
        .cart-header h1 { font-size: 2.5rem; font-weight: 600; }
        .cart-header .total-display { font-size: 1.2rem; margin-top: 10px; color: #1d1d1f; }

        .cart-item { display: flex; align-items: center; padding: 40px 0; border-bottom: 1px solid #d2d2d7; }
        .cart-img { width: 120px; height: 120px; object-fit: contain; margin-right: 40px; }
        
        .item-details { flex-grow: 1; }
        .item-name { font-size: 1.5rem; font-weight: 600; color: #1d1d1f; margin-bottom: 5px; }
        .item-options { font-size: 0.9rem; color: #86868b; }
        
        .item-actions { display: flex; align-items: center; gap: 20px; }
        .item-price { font-size: 1.2rem; font-weight: 600; text-align: right; min-width: 100px; }
        
        .remove-link { color: #0071e3; text-decoration: none; font-size: 0.9rem; }
        .remove-link:hover { text-decoration: underline; }

        .cart-summary { margin-top: 50px; text-align: right; }
        .summary-row { display: flex; justify-content: flex-end; gap: 40px; margin-bottom: 10px; font-size: 1.1rem; }
        .total-row { font-size: 1.8rem; font-weight: 700; margin-top: 20px; color: #1d1d1f; }
        
        .checkout-btn {
            background-color: #0071e3; color: white; padding: 15px 40px; border-radius: 12px;
            font-size: 1.1rem; text-decoration: none; display: inline-block; margin-top: 30px;
            transition: background 0.3s; width: 100%; max-width: 350px; text-align: center;
        }
        .checkout-btn:hover { background-color: #0077ED; }

        /* Si vide */
        .empty-cart { text-align: center; padding: 100px 0; }
        .empty-cart i { font-size: 4rem; color: #d2d2d7; margin-bottom: 20px; }
    </style>
</head>
<body>

    <nav style="border-bottom: 1px solid #d2d2d7; padding: 15px 0;">
        <div class="container" style="display:flex; justify-content:space-between;">
            <a href="../index.php" class="logo-text">StarTech</a>
            <a href="catalogue.php" style="color:#0071e3; text-decoration:none;">Continuer vos achats</a>
        </div>
    </nav>

    <div class="cart-container">
        
        <?php if (empty($_SESSION['panier'])): ?>
            <div class="empty-cart">
                <i class="fa-solid fa-bag-shopping"></i>
                <h1>Votre panier est vide.</h1>
                <p>Profitez de la livraison gratuite sur tous les produits Apple.</p>
                <a href="catalogue.php" class="checkout-btn" style="margin-top:20px; width:auto;">Voir les produits</a>
            </div>
        <?php else: ?>
            
            <div class="cart-header">
                <h1>Votre panier est prêt.</h1>
                <p class="total-display">Total : <?= number_format($total_panier, 2, ',', ' ') ?> €</p>
            </div>

            <?php foreach ($_SESSION['panier'] as $key => $item): ?>
                <div class="cart-item">
                    
                    <?php 
                        // --- GESTION DE L'IMAGE (CORRIGÉE) ---
                        // 1. On récupère le nom
                        $img_name = !empty($item['image']) ? $item['image'] : 'default.jpg';

                        // 2. On définit le chemin correct
                        if (strpos($img_name, 'http') === 0) {
                            $final_src = $img_name;
                        } else {
                            // On utilise le chemin absolu qui marche à tous les coups
                            $final_src = "/startech/assets/images/" . $img_name;
                        }
                    ?>
                    
                    <img src="<?= htmlspecialchars($final_src) ?>" 
                         alt="<?= htmlspecialchars($item['nom']) ?>" 
                         class="cart-img"
                         onerror="this.style.display='none'"> <div class="item-details">
                        <div class="item-name"><?= htmlspecialchars($item['nom']) ?></div>
                        <div class="item-options">
                            Quantité : <?= $item['quantite'] ?><br>
                            <?php 
                                if (!empty($item['options'])) {
                                    foreach($item['options'] as $k => $v) { 
                                        echo ucfirst($k) . ": " . ucfirst($v) . " | "; 
                                    }
                                }
                            ?>
                        </div>
                        <div style="margin-top: 10px;">
                            <a href="panier.php?action=delete&key=<?= $key ?>" class="remove-link">Supprimer</a>
                        </div>
                    </div>

                    <div class="item-price">
                        <?= number_format($item['prix'] * $item['quantite'], 2, ',', ' ') ?> €
                    </div>
                </div>
            <?php endforeach; ?>
            
            <div class="cart-summary">
                <div class="summary-row">
                    <span>Sous-total</span>
                    <span><?= number_format($total_panier, 2, ',', ' ') ?> €</span>
                </div>
                <div class="summary-row">
                    <span>Livraison</span>
                    <span style="color:#34C759;">Gratuite</span>
                </div>
                <div class="summary-row total-row">
                    <span>Total</span>
                    <span><?= number_format($total_panier, 2, ',', ' ') ?> €</span>
                </div>

              <a href="checkout.php" class="checkout-btn">Passer la commande</a>
            </div>

        <?php endif; ?>
    </div>

</body>
</html>