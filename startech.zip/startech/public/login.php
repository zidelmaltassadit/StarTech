<?php
// ==========================================================
// FICHIER : public/login.php
// LOGIQUE : Connexion SÉCURISÉE et STRICTE selon le rôle visé
// ==========================================================
session_start();

require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- 1. DÉFINITION DU RÔLE VISÉ (LE CONTEXTE) ---
// C'est le rôle que l'utilisateur SOUHAITE utiliser pour se connecter.
$role_vise = isset($_GET['role']) ? strtolower($_GET['role']) : 'client';

// Liste des rôles internes PGI (pour regrouper les admins)
$pgi_roles_internes = ['admin', 'administrateur', 'logistique', 'production', 'rh', 'commercial', 'comptabilite'];

// Configuration visuelle selon le contexte
$page_config = [
    'client' => ['titre' => 'Espace Client', 'icon' => 'fa-bag-shopping', 'color' => '#0071e3'],
    'fournisseur' => ['titre' => 'Portail Fournisseur', 'icon' => 'fa-truck-fast', 'color' => '#34C759'],
    // Pour tous les rôles admin, on utilise la même config visuelle
    'admin_gen' => ['titre' => 'Administration PGI', 'icon' => 'fa-lock', 'color' => '#AF52DE']
];

// On détermine quelle config visuelle utiliser
if ($role_vise === 'client') {
    $current_config = $page_config['client'];
} elseif ($role_vise === 'fournisseur') {
    $current_config = $page_config['fournisseur'];
} elseif (in_array($role_vise, $pgi_roles_internes) || $role_vise === 'admin') {
    // Si c'est un rôle admin (quel qu'il soit), on met le titre générique Admin
    $current_config = $page_config['admin_gen'];
    // On force le rôle visé à une catégorie générique pour la logique SQL plus bas
    $role_vise_categorie = 'admin_pgi';
} else {
    // Rôle inconnu -> retour au défaut client
    $role_vise = 'client';
    $current_config = $page_config['client'];
}

// Si on n'a pas encore défini la catégorie (cas client ou fournisseur)
if (!isset($role_vise_categorie)) { $role_vise_categorie = $role_vise; }


// --- 2. SI DÉJÀ CONNECTÉ : REDIRECTION DIRECTE ---
if (is_logged_in()) {
    rediriger_utilisateur($_SESSION['user_role']);
}

$email = $password = '';
$error_msg = '';

// --- 3. TRAITEMENT DU FORMULAIRE (MODE STRICT) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error_msg = 'Veuillez remplir tous les champs.';
    } else {
        $user = null;
        $sql = "";
        $params = [':email' => $email];

        // =================================================================
        // C'EST ICI QUE LA LOGIQUE STRICTE S'APPLIQUE
        // On ne cherche QUE dans la table correspondant au rôle visé.
        // =================================================================
        switch ($role_vise_categorie) {

            case 'client':
                // Contexte CLIENT : On cherche UNIQUEMENT dans la table 'clients'
                $sql = "SELECT id, nom, password_hash, 'client' as user_role FROM clients WHERE email = :email";
                break;

            case 'fournisseur':
                // Contexte FOURNISSEUR : On cherche dans 'utilisateurs' MAIS UNIQUEMENT si le rôle est 'fournisseur'
                $sql = "SELECT id, nom, password_hash, user_role FROM utilisateurs WHERE email = :email AND user_role = 'fournisseur'";
                break;

            case 'admin_pgi':
                // Contexte ADMIN : On cherche dans 'utilisateurs' TOUT SAUF les fournisseurs
                $sql = "SELECT id, nom, password_hash, user_role FROM utilisateurs WHERE email = :email AND user_role != 'fournisseur'";
                break;
        }

        // Exécution de la requête stricte
        if (!empty($sql)) {
            if ($stmt = $pdo->prepare($sql)) {
                $stmt->execute($params);
                if ($stmt->rowCount() == 1) {
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }
        }

        // --- VÉRIFICATION DU MOT DE PASSE ---
        if ($user && password_verify($password, $user['password_hash'])) {
            // --- SUCCÈS : CONNEXION AUTORISÉE ---
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['user_role'];
            $_SESSION['user_name'] = $user['nom'];

            // Gestion spéciale pour la redirection après panier
            if ($user['user_role'] === 'client' && isset($_SESSION['redirect_after_login'])) {
                $redirect_url = $_SESSION['redirect_after_login'];
                unset($_SESSION['redirect_after_login']);
                header('Location: ' . $redirect_url);
                exit;
            } else {
                // Redirection standard
                rediriger_utilisateur($user['user_role']);
            }

        } else {
            // ÉCHEC : Si l'utilisateur n'est pas trouvé DANS LE BON CONTEXTE, ou si le MDP est faux.
            // On met un message générique par sécurité.
            $error_msg = 'Identifiants incorrects pour cet espace.';
        }
    }
}

// ==========================================================
// FONCTION DE REDIRECTION (Inchangée)
// ==========================================================
function rediriger_utilisateur($role_db) {
    $role_clean = strtolower(trim($role_db));
    $pgi_roles = ['admin', 'administrateur', 'logistique', 'production', 'rh', 'commercial', 'comptabilite'];

    if (in_array($role_clean, $pgi_roles)) {
        header('Location: ../admin/dashboard.php');
        exit;
    } elseif ($role_clean === 'fournisseur') {
        header('Location: ../fournisseurs/dashboard.php');
        exit;
    } else {
        // Client par défaut
        header('Location: client_dashboard.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - <?= $current_config['titre'] ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <main class="login-wrapper">
        <div class="login-card">
            
            <div style="font-size: 3rem; color: <?= $current_config['color'] ?>; margin-bottom: 15px;">
                <i class="fa-solid <?= $current_config['icon'] ?>"></i>
            </div>

            <h1><?= $current_config['titre'] ?></h1>
            <p style="color: #86868b; margin-bottom: 25px; font-size: 0.9rem;">
                Veuillez vous identifier pour accéder à cet espace.
            </p>

            <?php if (!empty($error_msg)): ?>
                <div class="alert alert-danger" style="background:rgba(255,59,48,0.1); color:#FF3B30; padding:10px; border-radius:8px; margin-bottom:20px;">
                    <?= $error_msg ?>
                </div>
            <?php endif; ?>

            <form action="" method="post">
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" placeholder="nom@exemple.com" required value="<?= htmlspecialchars($email) ?>">
                </div>
                
                <div class="form-group">
                    <label>Mot de Passe</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>

                <div class="form-group" style="margin-top: 30px;">
                    <input type="submit" class="btn btn-full" value="Se connecter" style="background-color: <?= $current_config['color'] ?>;">
                </div>

            </form>

            <div style="margin-top: 20px; font-size: 0.8rem;">
                <a href="../index.php" style="color: #86868b;">&larr; Retour à l'accueil</a>
                <?php if ($role_vise_categorie === 'client'): ?>
                    <br><a href="register.php" style="color: #0071e3; margin-top: 5px; display: inline-block;">Créer un compte client</a>
                <?php endif; ?>
            </div>

        </div>
    </main>

</body>
</html>