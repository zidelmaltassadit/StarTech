<?php
// ==========================================================
// FICHIER : public/login.php
// LOGIQUE : Séparation stricte des rôles et Redirection précise
// ==========================================================
session_start();

require_once '../includes/db_config.php'; 
require_once '../includes/auth_functions.php';

// 1. DÉTECTION DU RÔLE VISÉ (Via l'URL) pour l'affichage du formulaire
$role_vise = isset($_GET['role']) ? $_GET['role'] : 'client';

// Configuration visuelle de la page selon le rôle
$page_config = [
    'client' => [
        'titre' => 'Espace Client',
        'icon' => 'fa-bag-shopping',
        'color' => '#0071e3' // Bleu Apple
    ],
    'fournisseur' => [
        'titre' => 'Portail Fournisseur',
        'icon' => 'fa-truck-fast',
        'color' => '#34C759' // Vert Apple
    ],
    'admin' => [
        'titre' => 'Administration',
        'icon' => 'fa-lock',
        'color' => '#AF52DE' // Violet Apple
    ]
];

// On sécurise la variable pour éviter les bugs si quelqu'un écrit n'importe quoi dans l'URL
if (!array_key_exists($role_vise, $page_config)) {
    $role_vise = 'client';
}
$current_config = $page_config[$role_vise];


// 2. SI DÉJÀ CONNECTÉ : REDIRECTION DIRECTE 
if (is_logged_in()) {
    // La fonction rediriger_utilisateur contient la logique complète
    rediriger_utilisateur($_SESSION['user_role']); 
}

$email = $password = '';
$error_msg = '';

// 3. TRAITEMENT DU FORMULAIRE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error_msg = 'Veuillez remplir tous les champs.';
    } else {
        // Requête SQL 
        $sql = "SELECT id, nom, password_hash, user_role FROM clients WHERE email = :email"; 
        
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $user = $stmt->fetch(PDO::FETCH_ASSOC); 
                    
                    if (password_verify($password, $user['password_hash'])) { 
                        
                        // --- SUCCÈS CONNEXION ---
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_role'] = $user['user_role'];
                        $_SESSION['user_name'] = $user['nom']; 

                        // Redirection finale après succès
                        rediriger_utilisateur($user['user_role']);
                        
                    } else {
                        $error_msg = 'Mot de passe incorrect.';
                    }
                } else {
                    $error_msg = 'Aucun compte trouvé avec cet email.';
                }
            } else {
                $error_msg = "Erreur technique base de données.";
            }
        }
    }
}

// ==========================================================
// FONCTION DE REDIRECTION (LOGIQUE CORRIGÉE)
// ==========================================================

function rediriger_utilisateur($role_db) {
    // Liste de TOUS les rôles qui doivent aller au PGI
    $pgi_roles = ['admin', 'administrateur', 'logistique', 'production', 'rh', 'commercial', 'comptabilite'];
    
    // Nettoyage de la variable
    $role_clean = strtolower(trim($role_db)); 

    // AIGUILLAGE
    if (in_array($role_clean, $pgi_roles)) {
        // 🎯 CORRIGÉ : L'administrateur va au dashboard PGI
        header('Location: ../admin/dashboard.php');
        exit;
    } 
    elseif ($role_clean === 'fournisseur') {
        // 🎯 CORRIGÉ : Le fournisseur va à son interface
        header('Location: ../fournisseur/interface.php'); // Chemin standard Fournisseur
        exit;
    } 
    else {
        // PAR DÉFAUT : C'est un Client (vers son tableau de bord ou catalogue)
        header('Location: client_dashboard.php'); // Peut être remplacé par catalogue.php
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - <?= $current_config['titre'] ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <main class="login-wrapper">
        <div class="login-card">
            
            <div style="font-size: 3rem; color: <?= $current_config['color'] ?>; margin-bottom: 15px;">
                <i class="fa-solid <?= $current_config['icon'] ?>"></i>
            </div>

            <h1><?= $current_config['titre'] ?></h1>
            <p style="color: #86868b; margin-bottom: 25px; font-size: 0.9rem;">
                Veuillez vous identifier pour continuer.
            </p>

            <?php if (!empty($error_msg)): ?>
                <div class="alert alert-danger" style="background:rgba(255,59,48,0.1); color:#FF3B30; padding:10px; border-radius:8px; margin-bottom:20px;">
                    <?= $error_msg ?>
                </div>
            <?php endif; ?>

            <form action="" method="post">
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" placeholder="nom@exemple.com" required value="<?= htmlspecialchars($email) ?>">
                </div>
                
                <div class="form-group">
                    <label>Mot de Passe</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>

                <div class="form-group" style="margin-top: 30px;">
                    <input type="submit" class="btn btn-full" value="Se connecter" style="background-color: <?= $current_config['color'] ?>;">
                </div>

            </form>

            <div style="margin-top: 20px; font-size: 0.8rem;">
                <a href="../index.php" style="color: #86868b;">&larr; Retour à l'accueil</a>
                <?php if ($role_vise === 'client'): ?>
                    <br><a href="register.php" style="color: #0071e3; margin-top: 5px; display: inline-block;">Créer un compte client</a>
                <?php endif; ?>
            </div>

        </div>
    </main>

</body>
</html>