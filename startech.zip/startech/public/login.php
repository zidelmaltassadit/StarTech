<?php
// FICHIER : public/login.php
session_start();

// Inclure la configuration de la base de données et les fonctions d'authentification
require_once '../includes/db_config.php'; 
require_once '../includes/auth_functions.php';

// Si l'utilisateur est déjà connecté, le rediriger immédiatement pour éviter les confusions.
if (is_logged_in()) {
    // Les chemins sont corrects (sortent du public/ pour aller dans admin/ ou rester dans public/)
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: ../admin/dashboard.php');
        exit;
    } elseif ($_SESSION['user_role'] === 'fournisseur') {
        // Redirection vers le tableau de bord Fournisseur sécurisé
        header('Location: ../admin/fournisseur_dashboard.php');
        exit;
    } else {
        // Redirection Client 
        header('Location: client_dashboard.php'); 
        exit;
    }
}

$email = $password = '';
$email_err = $password_err = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Validation de l'email et du mot de passe
    if (empty(trim($_POST['email']))) {
        $email_err = 'Veuillez entrer votre email.';
    } else {
        $email = trim($_POST['email']);
    }

    if (empty(trim($_POST['password']))) {
        $password_err = 'Veuillez entrer votre mot de passe.';
    } else {
        $password = trim($_POST['password']);
    }

    // 3. Traitement des identifiants s'il n'y a pas d'erreurs
    if (empty($email_err) && empty($password_err)) {
        
        // Requête pour sélectionner l'utilisateur (on utilise la table 'clients' qui contient le rôle et le hash)
        $sql = "SELECT id, nom, password_hash, user_role FROM clients WHERE email = :email"; 
        
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(':email', $param_email, PDO::PARAM_STR);
            $param_email = $email;

            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $user = $stmt->fetch(PDO::FETCH_ASSOC); 
                    
                    // Vérifiez le mot de passe haché
                    if (password_verify($password, $user['password_hash'])) { 
                        
                        // Connexion réussie ! Initialisation de la session
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_role'] = $user['user_role'];
                        $_SESSION['user_name'] = $user['nom']; 

                        // REDIRECTION CRITIQUE BASÉE SUR LE RÔLE 
                        if ($user['user_role'] === 'admin') {
                            header('Location: ../admin/dashboard.php'); 
                        } elseif ($user['user_role'] === 'fournisseur') {
                            header('Location: ../admin/fournisseur_dashboard.php'); 
                        } else {
                            // Client ou rôle par défaut
                            header('Location: client_dashboard.php'); 
                        }
                        exit;
                        
                    } else {
                        // Mot de passe invalide
                        $password_err = 'Mot de passe invalide.';
                    }
                } else {
                    // Email non trouvé
                    $email_err = 'Aucun compte trouvé avec cet email.';
                }
            } else {
                echo "Oups! Quelque chose a mal tourné avec la requête DB.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/auth_style.css"> 
</head>
<body>
    <div class="wrapper">
        <h2>Connexion</h2>
        <p>Veuillez remplir vos identifiants pour accéder à votre espace.</p>
        
        <?php 
        // Afficher les messages flash (si un accès a été refusé)
        if (isset($_SESSION['flash_message'])) {
            echo $_SESSION['flash_message'];
            unset($_SESSION['flash_message']);
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo $email; ?>">
                <span class="help-block"><?php echo $email_err; ?></span>
            </div>     
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Mot de Passe</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Se Connecter">
            </div>
            <p>
                Vous n'avez pas de compte ? Contactez votre administration pour créer un accès Fournisseur, ou <a href="register.php">inscrivez-vous comme client</a>.
            </p>
        </form>
    </div>     
</body>
</html>