<?php
// public/confidentialite.php

// 1. On inclut l'en-tête (la bannière)
require_once '../includes/public_header.php';
?>

<div class="container" style="padding: 100px 20px; max-width: 800px; margin: 0 auto;">
    <h1>Politique de Confidentialité</h1>
    
    <p style="margin-top: 30px; font-size: 1.1rem; line-height: 1.6; color: #333;">
        Chez StarTech, nous accordons une importance capitale à la protection de vos données personnelles. 
        Cette page a pour but de vous informer en toute transparence sur la manière dont nous collectons, 
        utilisons et protégeons vos informations.
    </p>

    <h2 style="margin-top: 40px;">Collecte des informations</h2>
    <p style="font-size: 1.1rem; line-height: 1.6; color: #333;">
        Nous collectons des informations lorsque vous vous inscrivez sur notre site, passez une commande 
        ou remplissez un formulaire. Les informations collectées incluent votre nom, votre adresse e-mail, 
        votre numéro de téléphone et vos adresses de livraison et de facturation.
    </p>

    <h2 style="margin-top: 40px;">Utilisation des informations</h2>
    <p style="font-size: 1.1rem; line-height: 1.6; color: #333;">
        Toutes les informations que nous recueillons auprès de vous peuvent être utilisées pour :
    </p>
    <ul style="margin-top: 15px; margin-left: 20px; font-size: 1.1rem; line-height: 1.6; color: #333;">
        <li>Personnaliser votre expérience et répondre à vos besoins individuels</li>
        <li>Améliorer notre site Web</li>
        <li>Améliorer le service client et vos besoins de prise en charge</li>
        <li>Vous contacter par e-mail</li>
        <li>Administrer un concours, une promotion, ou une enquête</li>
    </ul>
    
    <p style="margin-top: 30px; font-size: 1.1rem; line-height: 1.6; color: #333;">
        <strong>Vos données ne sont jamais vendues, échangées, transférées, ou données à une autre société 
        pour n'importe quelle raison, sans votre consentement, en dehors de ce qui est nécessaire 
        pour répondre à une demande et / ou une transaction, comme par exemple pour expédier une commande.</strong>
    </p>
</div>

<?php
// 2. On inclut le pied de page
require_once '../includes/public_footer.php';
?>