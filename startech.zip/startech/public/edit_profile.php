<?php
// public/edit_profile.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 

// 1. Exiger la connexion client
if (!is_logged_in()) {
    header('Location: login.php');
    exit();
}

$client_id = $_SESSION['user_id'] ?? null;
$client_info = [];
$message = $_SESSION['flash_message'] ?? ''; 
unset($_SESSION['flash_message']); 

if (!$client_id) {
    $_SESSION['flash_message'] = "<div class='alert-danger'>Erreur de session. ID client manquant. Veuillez vous reconnecter.</div>";
    header('Location: login.php'); // Changé à login.php, pas besoin de passer par logout.php
    exit();
}

// Assure que l'ID est un entier
$client_id = (int)$client_id;

// Champs à récupérer pour l'affichage initial et le traitement
// Suppression des anciennes adresses qui causaient les erreurs précédentes (adresse_livraison_default)
$fields = ['nom', 'prenom', 'email', 'telephone', 'entreprise', 'adresse_livraison_defaut', 'adresse_facturation_defaut'];

try {
    // 2. Récupérer les informations actuelles du client
    // Note: Utiliser implode(', ', $fields) est une bonne pratique.
    $sql_fetch = "SELECT " . implode(', ', $fields) . " FROM clients WHERE id = :id"; 
    $stmt_fetch = $pdo->prepare($sql_fetch);
    $stmt_fetch->execute([':id' => $client_id]);
    $client_info = $stmt_fetch->fetch(PDO::FETCH_ASSOC);

    // Si le client n'est pas trouvé dans la BDD
    if (!$client_info) {
        session_unset();
        session_destroy();
        $_SESSION['flash_message'] = "<div class='alert-danger'>Erreur de session. Client non trouvé. Veuillez vous reconnecter.</div>";
        header('Location: login.php');
        exit(); 
    }

    // 3. Traitement du formulaire POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Nettoyage des données POST
        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $addr_livraison = trim($_POST['adresse_livraison_defaut'] ?? ''); // Récupération de l'adresse de livraison
        $addr_facturation = trim($_POST['adresse_facturation_defaut'] ?? ''); // Récupération de l'adresse de facturation
        
        // Validation essentielle
        if (empty($nom) || empty($prenom) || empty($addr_livraison) || empty($addr_facturation)) {
            $message = "<div class='alert-warning'>Le nom, le prénom, l'adresse de livraison et l'adresse de facturation sont obligatoires.</div>";
            
            // Mettre à jour $client_info avec les valeurs postées pour ne pas les perdre dans le formulaire
            $client_info['nom'] = $nom;
            $client_info['prenom'] = $prenom;
            $client_info['telephone'] = $telephone;
            $client_info['adresse_livraison_defaut'] = $addr_livraison;
            $client_info['adresse_facturation_defaut'] = $addr_facturation;
            
        } else {
            // Mise à jour des informations
            // CORRECTION: La requête SQL doit inclure uniquement les champs mis à jour par le formulaire
            $sql_update = "UPDATE clients SET
                                nom = :nom, 
                                prenom = :prenom,
                                telephone = :telephone, 
                                adresse_livraison_defaut = :addr_livraison, 
                                adresse_facturation_defaut = :addr_facturation
                            WHERE id = :id"; 

            // CORRECTION: Utilisation de $sql_update dans prepare
            $stmt = $pdo->prepare($sql_update); 

            // CORRECTION: Le tableau execute doit correspondre EXACTEMENT aux marqueurs de $sql_update
            $stmt->execute([
                ':id' => $client_id, // Utilisation de $client_id
                ':nom' => $nom,
                ':prenom' => $prenom, // Ajout du prénom
                ':telephone' => $telephone,
                ':addr_livraison' => $addr_livraison, // Correspond à :adresse_livraison_defaut dans la BDD
                ':addr_facturation' => $addr_facturation, // Correspond à :adresse_facturation_defaut dans la BDD
            ]);

            // Redirection après succès (méthode PRG)
            $_SESSION['flash_message'] = "<div class='alert-success'>✅ Vos informations ont été mises à jour avec succès !</div>";
            header('Location: client_dashboard.php'); 
            exit();
        }
    }

} catch (PDOException $e) {
    // Affiche l'erreur en mode développement. En production, utilisez un log.
    $message .= "<div class='alert-danger'>Erreur de base de données : Impossible de sauvegarder les changements. " . (getenv('APP_ENV') === 'development' ? $e->getMessage() : '') . "</div>";
}
// Le code HTML commence ici
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Modifier mon Profil</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Mon Compte</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (<?= count($_SESSION['panier'] ?? []) ?>)</a>
                <a href="client_dashboard.php">Mon Compte</a>
            </nav>
        </div>
    </header>

    <div class="container public-content">
        <h2>Modification du Profil</h2>
        
        <p><a href="client_dashboard.php">&larr; Retour au Tableau de Bord</a></p>
        
        <?= $message; ?>

        <?php if ($client_info): ?>
            <form action="edit_profile.php" method="POST" class="form-standard">
                
                <h3>Informations Générales</h3>
                <div class="form-group">
                    <label for="prenom">Prénom :</label>
                    <input type="text" id="prenom" name="prenom" 
                            value="<?= htmlspecialchars($client_info['prenom'] ?? '') ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="nom">Nom :</label>
                    <input type="text" id="nom" name="nom" 
                            value="<?= htmlspecialchars($client_info['nom'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label for="telephone">Téléphone (Optionnel) :</label>
                    <input type="tel" id="telephone" name="telephone" 
                            value="<?= htmlspecialchars($client_info['telephone'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" 
                            value="<?= htmlspecialchars($client_info['email'] ?? '') ?>" disabled>
                    <small>L'email est utilisé comme identifiant et ne peut pas être modifié ici.</small>
                </div>
                
                <hr>
                
                <h3>Adresses par Défaut</h3>
                
                <div class="form-group">
                    <label for="adresse_livraison_defaut">Adresse de Livraison par Défaut :</label>
                    <textarea id="adresse_livraison_defaut" name="adresse_livraison_defaut" rows="4" required><?= htmlspecialchars($client_info['adresse_livraison_defaut'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label for="adresse_facturation_defaut">Adresse de Facturation par Défaut :</label>
                    <textarea id="adresse_facturation_defaut" name="adresse_facturation_defaut" rows="4" required><?= htmlspecialchars($client_info['adresse_facturation_defaut'] ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-lg">💾 Enregistrer toutes les Modifications</button>
            </form>
            
            <hr>
            
            <h3>Sécurité</h3>
            <a href="change_password.php" class="btn btn-secondary">Changer mon Mot de Passe</a>
            
        <?php endif; ?>
        
    </div>
</body>
</html>