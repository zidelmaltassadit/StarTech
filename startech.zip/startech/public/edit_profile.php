<?php
// ==========================================================
// FICHIER : public/edit_profile.php
// THEME : Modification de profil Apple Style
// ==========================================================
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Accès réservé aux clients connectés ---
if (!is_logged_in() || $_SESSION['user_role'] !== 'client') {
    header('Location: login.php');
    exit();
}

$client_id = $_SESSION['user_id'];
$errors = [];
$success_msg = '';

// --- TRAITEMENT DU FORMULAIRE (QUAND ON CLIQUE SUR ENREGISTRER) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Récupération et nettoyage des données
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $adr_livraison = trim($_POST['adresse_livraison'] ?? '');
    $adr_facturation = trim($_POST['adresse_facturation'] ?? '');
    
    // Gestion du changement de mot de passe (optionnel)
    $new_pass = $_POST['new_password'] ?? '';
    $confirm_pass = $_POST['confirm_password'] ?? '';

    // 2. Validations de base
    if (empty($nom)) $errors[] = "Le nom ne peut pas être vide.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "L'email n'est pas valide.";

    // Validation mot de passe si l'utilisateur veut le changer
    if (!empty($new_pass)) {
        if (strlen($new_pass) < 6) {
            $errors[] = "Le nouveau mot de passe doit faire au moins 6 caractères.";
        }
        if ($new_pass !== $confirm_pass) {
            $errors[] = "La confirmation du mot de passe ne correspond pas.";
        }
    }

    // 3. Mise à jour en base de données si pas d'erreurs
    if (empty($errors)) {
        try {
            // Préparation de la requête de base (infos + adresses)
            $sql = "UPDATE clients SET nom = :nom, email = :email, adresse_livraison = :adr_liv, adresse_facturation = :adr_fac";
            $params = [
                ':nom' => $nom,
                ':email' => $email,
                ':adr_liv' => $adr_livraison,
                ':adr_fac' => $adr_facturation,
                ':id' => $client_id
            ];

            // Si un nouveau mot de passe est fourni, on l'ajoute à la mise à jour
            if (!empty($new_pass)) {
                $sql .= ", password_hash = :pass";
                $params[':pass'] = password_hash($new_pass, PASSWORD_DEFAULT);
            }

            // Finalisation de la requête
            $sql .= " WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            // Mise à jour du nom en session
            $_SESSION['user_name'] = $nom;

            // Message de succès et redirection vers le dashboard
            $_SESSION['flash_message'] = "<div class='alert alert-success' style='margin-bottom:20px; color:green;'>Vos informations ont été mises à jour avec succès.</div>";
            header('Location: client_dashboard.php');
            exit;

        } catch (PDOException $e) {
            $errors[] = "Erreur technique lors de la mise à jour : " . $e->getMessage();
        }
    }
}

// --- CHARGEMENT DES DONNÉES ACTUELLES POUR PRÉ-REMPLIR LE FORMULAIRE ---
try {
    $stmt = $pdo->prepare("SELECT nom, email, adresse_livraison, adresse_facturation FROM clients WHERE id = ?");
    $stmt->execute([$client_id]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur de chargement du profil.");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier mon profil - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Style spécifique pour le formulaire Apple */
        .edit-profile-container { max-width: 700px; margin: 60px auto; padding: 0 20px; }
        .form-section { background: white; padding: 35px; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); margin-bottom: 30px; }
        .form-section h2 { font-size: 1.3rem; margin-bottom: 25px; color: #1d1d1f; border-bottom: 1px solid #e5e5e5; padding-bottom: 15px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 8px; color: #1d1d1f; }
        .form-control { width: 100%; padding: 12px 15px; border: 1px solid #d2d2d7; border-radius: 10px; font-size: 1rem; transition: border-color 0.2s; }
        .form-control:focus { border-color: #0071e3; outline: none; box-shadow: 0 0 0 3px rgba(0,113,227,0.1); }
        textarea.form-control { resize: vertical; height: 100px; }
        .helper-text { font-size: 0.85rem; color: #86868b; margin-top: 5px; }
        .btn-actions { display: flex; gap: 15px; justify-content: flex-end; margin-top: 30px; }
        .btn-cancel { background: #f5f5f7; color: #1d1d1f; }
    </style>
</head>
<body class="client-area-page">

    <nav style="background:rgba(255,255,255,0.8); backdrop-filter:blur(20px); position:sticky; top:0; z-index:100; border-bottom:1px solid rgba(0,0,0,0.05); padding:10px 0;">
        <div class="container" style="display:flex; justify-content:space-between; align-items:center;">
            <a href="../index.php" class="logo-text" style="font-weight:600; color:#1D1D1F; text-decoration:none;">StarTech</a>
            <a href="client_dashboard.php" style="color:#0071e3; text-decoration:none;"><i class="fa-solid fa-chevron-left"></i> Retour au compte</a>
        </div>
    </nav>

    <div class="edit-profile-container">
        <h1 style="font-size: 2.5rem; margin-bottom: 40px;">Modifier mes informations</h1>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" style="background:#fff2f1; color:#d32f2f; padding:15px; border-radius:10px; margin-bottom:30px;">
                <ul style="margin:0; padding-left:20px;">
                    <?php foreach($errors as $error): ?><li><?= htmlspecialchars($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="edit_profile.php">
            
            <div class="form-section">
                <h2>Informations personnelles</h2>
                <div class="form-group">
                    <label for="nom">Nom complet</label>
                    <input type="text" id="nom" name="nom" class="form-control" required value="<?= htmlspecialchars($client['nom']) ?>">
                </div>
                <div class="form-group">
                    <label for="email">Adresse Email</label>
                    <input type="email" id="email" name="email" class="form-control" required value="<?= htmlspecialchars($client['email']) ?>">
                </div>
            </div>

            <div class="form-section">
                <h2>Carnet d'adresses</h2>
                <div class="form-group">
                    <label for="adresse_livraison">Adresse de livraison par défaut</label>
                    <textarea id="adresse_livraison" name="adresse_livraison" class="form-control" placeholder="Rue, Code Postal, Ville, Pays"><?= htmlspecialchars($client['adresse_livraison'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label for="adresse_facturation">Adresse de facturation</label>
                    <textarea id="adresse_facturation" name="adresse_facturation" class="form-control" placeholder="Laisser vide si identique à la livraison"><?= htmlspecialchars($client['adresse_facturation'] ?? '') ?></textarea>
                    <p class="helper-text">Si non renseignée, l'adresse de livraison sera utilisée.</p>
                </div>
            </div>

            <div class="form-section" style="border: 1px solid #e5e5e5;">
                <h2><i class="fa-solid fa-lock" style="color:#86868b;"></i> Sécurité</h2>
                <p class="helper-text" style="margin-bottom: 20px;">Remplissez ces champs uniquement si vous souhaitez changer de mot de passe.</p>
                
                <div class="form-group">
                    <label for="new_password">Nouveau mot de passe</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" placeholder="••••••••">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirmer le nouveau mot de passe</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="••••••••">
                </div>
            </div>

            <div class="btn-actions">
                <a href="client_dashboard.php" class="btn btn-cancel" style="text-decoration:none; padding: 12px 25px; border-radius:10px;">Annuler</a>
                <button type="submit" class="btn btn-primary" style="padding: 12px 25px; border-radius:10px;">Enregistrer les modifications</button>
            </div>
        </form>
    </div>

</body>
</html>