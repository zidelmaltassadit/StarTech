<?php
// ==========================================================
// FICHIER : public/register.php
// THEME : Inscription Apple Style
// ==========================================================
session_start();

// 1. INCLUSIONS
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// Si déjà connecté, on redirige
if (is_logged_in()) {
    rediriger_utilisateur($_SESSION['user_role']);
}

$nom = $email = $password = $confirm_password = '';
$errors = [];

// 2. TRAITEMENT DU FORMULAIRE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Nettoyage des entrées
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // --- VALIDATION ---
    if (empty($nom)) { $errors[] = "Le nom est obligatoire."; }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = "L'adresse email n'est pas valide."; }
    if (strlen($password) < 6) { $errors[] = "Le mot de passe doit contenir au moins 6 caractères."; }
    if ($password !== $confirm_password) { $errors[] = "Les mots de passe ne correspondent pas."; }

    // --- VÉRIFICATION SI L'EMAIL EXISTE DÉJÀ ---
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id FROM clients WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "Cet email est déjà utilisé par un autre compte.";
        }
    }

    // --- CRÉATION DU COMPTE ---
    if (empty($errors)) {
        try {
            // Hachage du mot de passe (SÉCURITÉ CRITIQUE)
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role_default = 'client';

            // Insertion dans la base
            $sql = "INSERT INTO clients (nom, email, password_hash, user_role) VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nom, $email, $hashed_password, $role_default]);

            // Connexion automatique après inscription
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['user_role'] = $role_default;
            $_SESSION['user_name'] = $nom;

            // Message de bienvenue
            $_SESSION['flash_message'] = "Bienvenue chez StarTech ! Votre compte a été créé.";
            
            // Redirection vers l'espace client
            header('Location: client_dashboard.php');
            exit;

        } catch (PDOException $e) {
             $errors[] = "Erreur lors de l'inscription : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un StarTech ID</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <main class="login-wrapper">
        <div class="login-card" style="max-width: 450px;"> <h1>Créer votre StarTech ID</h1>
            <p style="color: #86868b; margin-bottom: 25px; font-size: 0.9rem;">
                Une seule identité pour tous vos achats.
            </p>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger" style="background:rgba(255,59,48,0.1); color:#FF3B30; padding:15px; border-radius:8px; margin-bottom:20px; text-align:left; font-size:0.9rem;">
                    <ul style="margin:0; padding-left:20px;">
                        <?php foreach($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="register.php" method="post">
                
                <div class="form-group">
                    <label>Nom complet</label>
                    <input type="text" name="nom" class="form-control" placeholder="Jean Dupont" required value="<?= htmlspecialchars($nom) ?>">
                </div>

                <div class="form-group">
                    <label>Adresse Email</label>
                    <input type="email" name="email" class="form-control" placeholder="nom@exemple.com" required value="<?= htmlspecialchars($email) ?>">
                </div>
                
                <div class="form-group">
                   <div style="display: flex; gap: 15px;">
                       <div style="flex:1;">
                           <label>Mot de Passe</label>
                           <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                       </div>
                       <div style="flex:1;">
                           <label>Confirmer</label>
                           <input type="password" name="confirm_password" class="form-control" placeholder="••••••••" required>
                       </div>
                   </div>
                   <small style="color:#86868b; display:block; margin-top:5px;">Au moins 6 caractères.</small>
                </div>

                <div class="form-group" style="margin-top: 30px;">
                    <input type="submit" class="btn btn-full" value="Continuer">
                </div>

                <div class="auth-links" style="margin-top: 20px; font-size: 0.85rem;">
                    <p>Vous avez déjà un compte ? <a href="login.php" style="color:#0071e3;">Se connecter</a></p>
                </div>

            </form>
        </div>
    </main>

</body>
</html>