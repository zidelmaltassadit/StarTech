<?php
// public/register.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 

$message = $_SESSION['flash_message'] ?? '';
unset($_SESSION['flash_message']);
$errors = [];

// Valeurs par défaut pour conserver les données si le formulaire échoue
$prenom = $_POST['prenom'] ?? '';
$nom = $_POST['nom'] ?? '';
$email = $_POST['email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Récupération des données POST
    $password = $_POST['password'] ?? '';
    
    // 2. Validation
    if (empty($prenom)) { $errors[] = "Le prénom est obligatoire."; }
    if (empty($nom)) { $errors[] = "Le nom est obligatoire."; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = "Le format de l'email est invalide."; }
    if (strlen($password) < 6) { $errors[] = "Le mot de passe doit contenir au moins 6 caractères."; }

    if (empty($errors)) {
        try {
            // Vérifier si l'email existe déjà
            $sql_check = "SELECT id FROM clients WHERE email = :email";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([':email' => $email]);
            
            if ($stmt_check->rowCount() > 0) {
                $errors[] = "Cet email est déjà utilisé. Veuillez vous connecter ou utiliser un autre email.";
            } else {
                // 3. Insertion dans la base de données
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // Requête SQL (sans entreprise ni telephone, mais avec password_hash)
                $sql_insert = "INSERT INTO clients (prenom, nom, email, password_hash)
                               VALUES (:prenom, :nom, :email, :password_hash)";
                
                $stmt_insert = $pdo->prepare($sql_insert);
                $stmt_insert->execute([
                    ':prenom' => $prenom,
                    ':nom' => $nom,
                    ':email' => $email,
                    ':password_hash' => $password_hash
                ]);

                // Inscription réussie : Rediriger vers la connexion
                $_SESSION['flash_message'] = "<div class='alert-success'>✅ Votre compte a été créé ! Vous pouvez vous connecter.</div>";
                header('Location: login.php');
                exit();
            }
        } catch (PDOException $e) {
            // Affichage du message d'erreur si une autre erreur BDD survenait
            $message = "<div class='alert-danger'>Erreur de base de données : impossible de créer le compte. 
                       <br><strong>Détails :</strong> " . $e->getMessage() . "</div>";
        }
    }
    
    // Si des erreurs existent (validation ou BDD), les afficher
    if (!empty($errors)) {
        $message = "<div class='alert-warning'>" . implode('<br>', $errors) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Inscription Client</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Boutique</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (<?= count($_SESSION['panier'] ?? []) ?>)</a>
            </nav>
        </div>
    </header>

    <div class="container public-content form-container">
        <h2>Créer un compte</h2>
        
        <?= $message; ?>
        
        <form action="register.php" method="POST" class="form-standard">
            
            <div class="form-group">
                <label for="prenom">Prénom * :</label>
                <input type="text" id="prenom" name="prenom" 
                       value="<?= htmlspecialchars($prenom) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="nom">Nom * :</label>
                <input type="text" id="nom" name="nom" 
                       value="<?= htmlspecialchars($nom) ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email * :</label>
                <input type="email" id="email" name="email" 
                       value="<?= htmlspecialchars($email) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Mot de passe * (min 6 caractères) :</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Créer mon compte</button>
            
            <p class="mt-3">
                Déjà un compte ? 
                <a href="login.php">Se connecter</a>
            </p>
        </form>
    </div>
</body>
</html>