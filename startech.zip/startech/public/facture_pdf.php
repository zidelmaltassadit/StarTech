<?php
// ============================================================
// FICHIER : public/facture_pdf.php
// BUT : Générer une facture PDF professionnelle
// ============================================================
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_once '../includes/functions.php';

// --- 1. CHARGEMENT DE LA LIBRAIRIE DOMPDF ---
// Ajuste le chemin si nécessaire selon comment tu as installé Dompdf
require_once '../vendor/dompdf/autoload.inc.php'; 
use Dompdf\Dompdf;
use Dompdf\Options;

// --- 2. SÉCURITÉ ET RÉCUPÉRATION DES DONNÉES ---

// Vérifier connexion
if (!is_logged_in()) { die("Accès refusé. Veuillez vous connecter."); }

$commande_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$client_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

if ($commande_id === 0) { die("Numéro de commande invalide."); }

// A. Récupérer la COMMANDE et le CLIENT
// SÉCURITÉ CRITIQUE : On vérifie dans le WHERE que la commande appartient bien au client connecté (sauf si c'est un admin)
$sql_cmd = "SELECT c.*, cl.nom as client_nom, cl.email as client_email 
            FROM commandes c
            JOIN clients cl ON c.client_id = cl.id
            WHERE c.id = :cmd_id";

// Si ce n'est pas un admin, on ajoute la restriction client
if (!in_array($user_role, ['admin', 'administrateur', 'comptabilite'])) {
    $sql_cmd .= " AND c.client_id = :client_id";
    $params = [':cmd_id' => $commande_id, ':client_id' => $client_id];
} else {
    // L'admin peut voir toutes les factures
    $params = [':cmd_id' => $commande_id];
}

$stmt = $pdo->prepare($sql_cmd);
$stmt->execute($params);
$commande = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$commande) {
    die("Commande introuvable ou accès non autorisé.");
}

// B. Récupérer les DETAILS (Produits)
// Note : On utilise les prix historisés dans la table details_commande
$sql_details = "SELECT dc.*, p.nom as prod_nom 
                FROM details_commande dc
                LEFT JOIN produits p ON dc.produit_id = p.id
                WHERE dc.commande_id = :cmd_id";
$stmt_details = $pdo->prepare($sql_details);
$stmt_details->execute([':cmd_id' => $commande_id]);
$details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

// --- 3. DÉBUT DE LA GÉNÉRATION DU HTML ---
// On utilise la "mise en mémoire tampon" (output buffering) pour capturer le HTML
ob_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Facture #<?= str_pad($commande['id'], 6, '0', STR_PAD_LEFT) ?></title>
    <style>
        /* CSS SPÉCIFIQUE POUR LE PDF (Moteur Dompdf) */
        body { font-family: Helvetica, Arial, sans-serif; font-size: 13px; color: #333; line-height: 1.4; }
        .header { width: 100%; border-bottom: 2px solid #eee; padding-bottom: 20px; margin-bottom: 30px; }
        .logo { font-size: 24px; font-weight: bold; color: #000; }
        .company-info { float: right; text-align: right; font-size: 12px; color: #777; }
        
        .invoice-details { width: 100%; margin-bottom: 30px; }
        .client-col, .invoice-col { width: 48%; display: inline-block; vertical-align: top; }
        .invoice-col { text-align: right; }
        h3 { font-size: 16px; margin-bottom: 10px; color: #000; }
        
        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .items-table th { background: #f8f8f8; border-bottom: 1px solid #ddd; padding: 10px; text-align: left; font-weight: bold; }
        .items-table td { border-bottom: 1px solid #eee; padding: 10px; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        
        .totals-section { width: 100%; }
        .totals-table { float: right; width: 40%; border-collapse: collapse; }
        .totals-table td { padding: 8px; text-align: right; }
        .totals-table .total-row { font-size: 16px; font-weight: bold; border-top: 2px solid #333; color: #000; }
        
        .footer { position: fixed; bottom: 0; left: 0; right: 0; height: 30px; text-align: center; font-size: 10px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }
    </style>
</head>
<body>

    <div class="header">
        <div class="logo">StarTech</div>
        <div class="company-info">
            StarTech SAS<br>
            123 Avenue de la Tech<br>
            75001 Paris, France<br>
            SIRET: 123 456 789 00012<br>
            contact@startech.store
        </div>
        <div style="clear:both;"></div>
    </div>

    <div class="invoice-details">
        <div class="client-col">
            <h3>Facturé à :</h3>
            <strong><?= htmlspecialchars($commande['client_nom']) ?></strong><br>
            <?= nl2br(htmlspecialchars($commande['adresse_facturation'])) ?><br>
            Email : <?= htmlspecialchars($commande['client_email']) ?>
        </div>
        <div class="invoice-col">
            <h1>FACTURE</h1>
            <p><strong>Numéro :</strong> #<?= str_pad($commande['id'], 6, '0', STR_PAD_LEFT) ?></p>
            <p><strong>Date :</strong> <?= (new DateTime($commande['date_commande']))->format('d/m/Y') ?></p>
            <p><strong>Paiement :</strong> <?= htmlspecialchars($commande['moyen_paiement']) ?></p>
        </div>
    </div>

    <table class="items-table">
        <thead>
            <tr>
                <th style="width: 45%;">Description</th>
                <th class="text-center">Qté</th>
                <th class="text-right">Prix Unit. HT</th>
                <th class="text-right">Total HT</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($details as $item): ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($item['prod_nom']) ?></strong>
                        <?php 
                        // Affichage des options si elles existent
                        if (!empty($item['options'])) {
                            $opts = json_decode($item['options'], true);
                            if (is_array($opts)) {
                                echo "<br><small style='color:#777;'>";
                                foreach ($opts as $k => $v) { echo ucfirst($k) . ": " . ucfirst($v) . " | "; }
                                echo "</small>";
                            }
                        }
                        ?>
                    </td>
                    <td class="text-center"><?= $item['quantite'] ?></td>
                    <td class="text-right"><?= number_format($item['prix_unitaire_ht'], 2, ',', ' ') ?> €</td>
                    <td class="text-right"><?= number_format($item['prix_total_ht'], 2, ',', ' ') ?> €</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="totals-section">
        <table class="totals-table">
            <tr>
                <td>Total HT :</td>
                <td><?= number_format($commande['total_ht'], 2, ',', ' ') ?> €</td>
            </tr>
            <tr>
                <td>TVA (20%) :</td>
                <td><?= number_format($commande['total_tva'], 2, ',', ' ') ?> €</td>
            </tr>
            <tr class="total-row">
                <td style="padding-top: 15px;">Total TTC :</td>
                <td style="padding-top: 15px;"><?= number_format($commande['montant_total'], 2, ',', ' ') ?> €</td>
            </tr>
        </table>
        <div style="clear:both;"></div>
    </div>

    <div class="footer">
        Merci de votre confiance. StarTech SAS au capital de 50 000 € - RCS Paris B 123 456 789.
    </div>

</body>
</html>
<?php
// Fin de la capture HTML
$html_content = ob_get_clean();

// --- 4. INITIALISATION ET GÉNÉRATION DOMPDF ---
$options = new Options();
$options->set('defaultFont', 'Helvetica');
$options->set('isRemoteEnabled', true); // Autorise les images externes si besoin

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html_content);

// Réglage du papier (A4 vertical)
$dompdf->setPaper('A4', 'portrait');

// Rendu du PDF (C'est là que la magie opère)
$dompdf->render();

// Envoi du fichier au navigateur pour téléchargement
// "Attachment" => true : force le téléchargement
// "Attachment" => false : affiche dans le navigateur si possible
$dompdf->stream("facture_startech_" . $commande['id'] . ".pdf", ["Attachment" => false]);
?>