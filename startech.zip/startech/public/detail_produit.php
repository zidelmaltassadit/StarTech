<?php
// public/detail_produit.php
session_start();
require_once '../includes/db_config.php';

// 1. RÉCUPÉRATION DE L'ID PRODUIT
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// 2. REQUÊTE SQL POUR RÉCUPÉRER LES INFOS
$stmt = $pdo->prepare("SELECT * FROM produits WHERE id = ?");
$stmt->execute([$id]);
$produit = $stmt->fetch(PDO::FETCH_ASSOC);

// Si le produit n'existe pas, on renvoie au catalogue
if (!$produit) {
    header('Location: catalogue.php');
    exit;
}

// 3. PRÉPARATION DES DONNÉES
$nom = htmlspecialchars($produit['nom']);
$desc = htmlspecialchars($produit['description']);
$prix_base = $produit['prix_vente'];
$cat_id = $produit['categorie_id'];

// Gestion de l'image (Local ou URL)
$img = !empty($produit['image']) ? $produit['image'] : 'default.png';
if (!preg_match("~^(?:f|ht)tps?://~i", $img)) {
    $img = "../assets/images/" . $img;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $nom ?> - Acheter - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="product-page-body">

    <header>
        <div class="container" style="display:flex; justify-content:space-between; align-items:center;">
            <a href="../index.php" class="logo-text">StarTech</a>
            <div class="nav-icons">
                <a href="panier.php"><i class="fa-solid fa-bag-shopping"></i> Panier</a>
            </div>
        </div>
    </header>

    <main class="container product-detail-container">
        
        <div class="product-gallery sticky-gallery">
            <div class="badge-new">Nouveau</div>
            <img src="<?= htmlspecialchars($img) ?>" alt="<?= $nom ?>" class="main-product-img">
        </div>

        <div class="product-config">
            
            <h1 class="product-title"><?= $nom ?></h1>
            <p class="product-subtitle"><?= $desc ?></p>
            
            <div class="price-tag" id="displayed-price">
                <?= number_format($prix_base, 2, ',', ' ') ?> €
            </div>

            <form action="panier_ajout.php" method="POST">
                <input type="hidden" name="product_id" value="<?= $produit['id'] ?>">

                <?php if ($cat_id == 1): ?>
                    
                    <div class="config-section">
                        <h3 class="config-label">Mémoire unifiée (RAM)</h3>
                        <div class="radio-group">
                            <label class="radio-card selected">
                                <input type="radio" name="ram" value="8go" data-price="0" checked onchange="calculateTotal(this)">
                                <div class="card-content">
                                    <span class="spec-name">8 Go</span>
                                    <span class="spec-price">Inclus</span>
                                </div>
                            </label>

                            <label class="radio-card">
                                <input type="radio" name="ram" value="16go" data-price="230" onchange="calculateTotal(this)">
                                <div class="card-content">
                                    <span class="spec-name">16 Go</span>
                                    <span class="spec-price">+ 230,00 €</span>
                                </div>
                            </label>
                            
                            <label class="radio-card">
                                <input type="radio" name="ram" value="24go" data-price="460" onchange="calculateTotal(this)">
                                <div class="card-content">
                                    <span class="spec-name">24 Go</span>
                                    <span class="spec-price">+ 460,00 €</span>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="config-section">
                        <h3 class="config-label">Stockage (SSD)</h3>
                        <div class="radio-group">
                            <label class="radio-card selected">
                                <input type="radio" name="ssd" value="512go" data-price="0" checked onchange="calculateTotal(this)">
                                <div class="card-content">
                                    <span class="spec-name">512 Go SSD</span>
                                    <span class="spec-price">Inclus</span>
                                </div>
                            </label>

                            <label class="radio-card">
                                <input type="radio" name="ssd" value="1to" data-price="230" onchange="calculateTotal(this)">
                                <div class="card-content">
                                    <span class="spec-name">1 To SSD</span>
                                    <span class="spec-price">+ 230,00 €</span>
                                </div>
                            </label>
                        </div>
                    </div>

                <?php endif; ?>
                <div class="action-area">
                    <button type="submit" class="btn btn-primary btn-block">Ajouter au Panier</button>
                    <p class="shipping-info"><i class="fa-solid fa-box-open"></i> Livraison gratuite : Demain</p>
                </div>
            </form>
        </div>
    </main>

    <script>
        // On injecte le prix de base de la BDD dans le JS
        const basePrice = <?= $prix_base ?>;

        function calculateTotal(element) {
            // 1. Gestion visuelle (Bordure bleue)
            const group = element.closest('.radio-group');
            group.querySelectorAll('.radio-card').forEach(card => card.classList.remove('selected'));
            element.closest('.radio-card').classList.add('selected');

            // 2. Calcul mathématique
            let currentTotal = basePrice;

            // Récupérer la RAM choisie (si l'option existe)
            const selectedRam = document.querySelector('input[name="ram"]:checked');
            if (selectedRam) {
                currentTotal += parseInt(selectedRam.getAttribute('data-price'));
            }

            // Récupérer le SSD choisi (si l'option existe)
            const selectedSsd = document.querySelector('input[name="ssd"]:checked');
            if (selectedSsd) {
                currentTotal += parseInt(selectedSsd.getAttribute('data-price'));
            }

            // 3. Mise à jour de l'affichage
            const formattedPrice = new Intl.NumberFormat('fr-FR', { 
                style: 'currency', 
                currency: 'EUR' 
            }).format(currentTotal);

            document.getElementById('displayed-price').innerText = formattedPrice;
        }
    </script>

</body>
</html>