<?php
// public/detail_produit.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/functions.php'; // Inclut les fonctions d'aide (y compris format_montant)

// --- Ancien code de format_montant() supprimé pour éviter la "Fatal error: Cannot redeclare" ---

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: catalogue.php');
    exit();
}

$produit_id = (int)$_GET['id'];
$produit = null;
$message = '';

try {
    // CORRECTION SQL : Remplacement de prix_vente_ht par prix_vente
    $sql = "SELECT id, nom, description, prix_vente, quantite_stock, image 
            FROM produits 
            WHERE id = :id AND statut = 'actif'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $produit_id]);
    $produit = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$produit) {
        $message = "<div class='alert-warning'>Ce produit n'existe pas ou n'est plus disponible.</div>";
    }

} catch (PDOException $e) {
    $message = "<div class='alert-danger'>Erreur de base de données : Impossible de charger le détail du produit.</div>";
}

// Vérification de l'existence de la fonction format_montant
// Si format_montant est dans functions.php, nous allons définir ici une version de secours pour l'affichage TTC et HT
if (function_exists('format_montant')) {
    $format_function = 'format_montant';
} else {
    // Fonction de secours si format_montant n'est pas trouvé (ce qui ne devrait pas arriver)
    $format_function = function ($montant) {
        return number_format((float)$montant, 2, ',', ' ') . ' €';
    };
}

// Fonction pour afficher le TTC (en utilisant format_montant pour le formatage)
function get_ttc_display($montant_ht) {
    // Si la fonction calculer_ttc existe dans functions.php, utilisez-la
    if (function_exists('calculer_ttc')) {
        $montant_ttc = calculer_ttc($montant_ht);
    } else {
        // Sinon, on applique 20% par défaut
        $montant_ttc = $montant_ht * 1.20;
    }
    // Utilisez la fonction format_montant du fichier functions.php
    return format_montant($montant_ttc) . ' TTC';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Détail : <?= htmlspecialchars($produit['nom'] ?? 'Produit') ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Boutique</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (<?= count($_SESSION['panier'] ?? []) ?>)</a>
                <a href="login.php">Connexion Client</a>
            </nav>
        </div>
    </header>

    <div class="container public-content">
        <p><a href="catalogue.php">&larr; Retour au catalogue</a></p>

        <?= $message; ?>
        
        <?php if ($produit): ?>
            
            <div class="product-detail-layout">
                <div class="product-image-section">
                    <?php 
                    $image_path = !empty($produit['image']) ? $produit['image'] : 'default.png';
                    ?>
                    <img src="../assets/images/produits/<?= htmlspecialchars($image_path) ?>" 
                         alt="<?= htmlspecialchars($produit['nom']) ?>" 
                         class="product-detail-image">
                </div>
                
                <div class="product-info-section">
                    <h2><?= htmlspecialchars($produit['nom']) ?></h2>
                    <hr>
                    
                    <p class="description-long"><?= nl2br(htmlspecialchars($produit['description'])) ?></p>
                    
                    <div class="price-box">
                        <p class="price-ttc">
                            Prix : 
                            <strong><?= get_ttc_display($produit['prix_vente']) ?></strong> </p>
                        <p class="price-ht">
                            (<?= format_montant($produit['prix_vente']) ?> HT) </p>
                    </div>

                    <div class="stock-info">
                        <?php if ($produit['quantite_stock'] > 0): ?>
                            <span class="stock-ok">En Stock (<?= $produit['quantite_stock'] ?> disponibles)</span>
                        <?php else: ?>
                            <span class="stock-ko">Rupture de Stock</span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($produit['quantite_stock'] > 0): ?>
                        <form action="panier.php" method="GET" class="add-to-cart-form">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="id" value="<?= $produit['id'] ?>">
                            
                            <label for="quantite">Quantité :</label>
                            <input type="number" name="quantite" id="quantite" value="1" 
                                   min="1" max="<?= $produit['quantite_stock'] ?>" required>
                            
                            <button type="submit" class="btn btn-primary btn-lg">Ajouter au panier</button>
                        </form>
                    <?php endif; ?>

                </div>
            </div>
            
        <?php else: ?>
            <div class="alert alert-danger">Impossible d'afficher les détails du produit.</div>
        <?php endif; ?>
        
    </div>
</body>
</html>