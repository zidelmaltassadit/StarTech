<?php
// public/panier_ajout.php
session_start();
require_once '../includes/db_config.php';

// Vérifier si le panier existe, sinon le créer
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// Récupérer les données envoyées (soit par formulaire, soit par lien URL)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $quantite = 1; // Par défaut
    
    // Gestion des options (RAM/SSD) venant de la page détail
    $options = [];
    if (isset($_POST['ram'])) $options['ram'] = $_POST['ram'];
    if (isset($_POST['ssd'])) $options['ssd'] = $_POST['ssd'];
    
} else {
    // Ajout via lien simple (depuis le catalogue)
    $product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $quantite = 1;
    $options = []; // Pas d'options depuis le catalogue
}

// Validation basique
if ($product_id > 0) {
    
    // On récupère le prix et le nom depuis la BDD pour être sûr
    $stmt = $pdo->prepare("SELECT * FROM produits WHERE id = ?");
    $stmt->execute([$product_id]);
    $produit = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($produit) {
        // Calcul du prix final avec options (Logique simplifiée ici)
        $prix_final = $produit['prix_vente'];
        
        // Exemple simple d'augmentation prix pour options (à adapter selon ta logique métier)
        if (isset($options['ram']) && $options['ram'] == '16go') $prix_final += 230;
        if (isset($options['ram']) && $options['ram'] == '24go') $prix_final += 460;
        if (isset($options['ssd']) && $options['ssd'] == '1to') $prix_final += 230;

        // Création d'une clé unique pour le produit (pour distinguer un Mac 8Go d'un Mac 16Go)
        $cart_key = $product_id . '-' . serialize($options);

        if (isset($_SESSION['panier'][$cart_key])) {
            // Si le produit exact existe déjà, on augmente la quantité
            $_SESSION['panier'][$cart_key]['quantite'] += $quantite;
        } else {
            // Sinon on l'ajoute
            $_SESSION['panier'][$cart_key] = [
                'id' => $produit['id'],
                'nom' => $produit['nom'],
                'prix' => $prix_final,
                'image' => $produit['image'],
                'quantite' => $quantite,
                'options' => $options
            ];
        }
        
        // Message de succès (Flash)
        $_SESSION['flash_success'] = "Produit ajouté au panier !";
    }
}

// Retour au panier ou au catalogue
header('Location: panier.php');
exit;
?>