<?php
// public/a_propos.php

// ============================================================
// 1. ON INCLUT L'EN-TÊTE COMMUN
// ============================================================
require_once '../includes/public_header.php';
?>

<style>
    .about-hero { text-align: center; padding: 80px 20px 60px; background: radial-gradient(circle at center, #f5f5f7 0%, #ffffff 100%); }
    .about-hero h1 { font-size: 3rem; font-weight: 800; color: #1d1d1f; }
    .content-section { max-width: 900px; margin: 60px auto; padding: 0 40px; }
    .section-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 50px; align-items: center; }
    h2 { font-size: 2rem; font-weight: 700; margin-bottom: 20px; }
    p.text-content { font-size: 1.1rem; line-height: 1.6; color: #333; margin-bottom: 20px; }
    .image-placeholder { height: 300px; background: #F5F5F7; border-radius: 20px; display: flex; align-items: center; justify-content: center; }
    .image-placeholder i { font-size: 5rem; color: #d2d2d7; }
</style>

<div>
    <section class="about-hero">
        <h1>L'excellence technologique.<br>Redéfinie.</h1>
        <p style="font-size: 1.3rem; color: #86868b; margin-top: 20px;">Chez StarTech, nous vous connectons au futur.</p>
    </section>

    <section class="content-section" style="padding-top: 40px;">
        <div class="section-grid">
            <div>
                <h2>Notre mission.</h2>
                <p class="text-content">Fondée en 2025, StarTech sélectionne rigoureusement le meilleur de l'écosystème premium pour offrir des outils qui stimulent la créativité.</p>
            </div>
            <div class="image-placeholder"><i class="fa-solid fa-rocket"></i></div>
        </div>
    </section>

    <section class="content-section">
        <div class="section-grid" style="direction: rtl;">
            <div style="direction: ltr;">
                <h2>L'expérience avant tout.</h2>
                <p class="text-content">De la gestion des stocks en temps réel à notre logistique, tout est pensé pour être simple et transparent.</p>
                <a href="support.php" style="color: #0071E3; font-weight: 600; text-decoration: none;">Contactez nos experts ></a>
            </div>
            <div class="image-placeholder" style="direction: ltr;"><i class="fa-solid fa-headset"></i></div>
        </div>
    </section>
</div>

<?php
// ============================================================
// 2. ON INCLUT LE PIED DE PAGE COMMUN
// ============================================================
require_once '../includes/public_footer.php';
?>