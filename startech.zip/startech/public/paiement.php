<?php
// public/paiement.php
session_start();
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : On ne peut arriver ici que si on est passé par l'étape checkout ---
// 1. Panier vide ? -> Dehors
if (empty($_SESSION['panier'])) { header('Location: panier.php'); exit; }
// 2. Pas connecté ? -> Dehors
if (!is_logged_in()) { header('Location: login.php'); exit; }
// 3. Pas d'adresses en session ? -> Retour à l'étape 1
if (!isset($_SESSION['checkout_adresses'])) { header('Location: checkout.php'); exit; }

// --- CALCUL DU TOTAL ---
$total_panier = 0;
foreach ($_SESSION['panier'] as $item) { $total_panier += $item['prix'] * $item['quantite']; }

// --- TRAITEMENT (SIMULATION) DU PAIEMENT ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // C'est ici qu'aurait lieu l'appel à Stripe ou PayPal.
    // Pour la simulation, on fait semblant que ça a marché.
    // On stocke une "preuve" de paiement en session.
    $_SESSION['payment_success'] = true;
    $_SESSION['payment_method'] = 'Carte Bancaire (Simulé)';
    
    // Redirection vers la page finale de confirmation
    header('Location: confirmation.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiement - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* STYLE SPÉCIFIQUE PAIEMENT */
        body { background: #F5F5F7; }
        .checkout-container { max-width: 1000px; margin: 40px auto; display: grid; grid-template-columns: 1.5fr 1fr; gap: 40px; padding: 0 20px; }
        .checkout-step { background: white; padding: 30px; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); }
        .checkout-step h2 { font-size: 1.5rem; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }
        .step-number { background: #0071e3; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 600; }
        
        /* Style Carte Bancaire "Apple Style" */
        .payment-form { margin-top: 30px; }
        .card-input-container { position: relative; margin-bottom: 20px; }
        .card-icon { position: absolute; top: 50%; left: 15px; transform: translateY(-5%); color: #86868b; font-size: 1.2rem; }
        .form-control.card-num { padding-left: 50px; letter-spacing: 2px; font-family: monospace; font-size: 1.1rem; }
        .card-expiry-cvc { display: flex; gap: 20px; }
        
        .summary-section { margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #e5e5e5; }
        .summary-title { font-weight: 600; margin-bottom: 10px; color: #1d1d1f; }
        .summary-content { font-size: 0.95rem; color: #86868b; line-height: 1.5; }
        .edit-link { color: #0071e3; text-decoration: none; font-size: 0.9rem; float: right; }

        .pay-btn { background: #000000; /* Noir Apple Pay */ color: white; border: none; padding: 15px; width: 100%; border-radius: 12px; font-size: 1.1rem; font-weight: 600; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 10px; }
        .pay-btn:hover { background: #333333; }
    </style>
</head>
<body>

    <nav style="background:white; padding: 15px 0; border-bottom: 1px solid #d2d2d7;">
        <div class="container" style="display:flex; justify-content:space-between;">
            <span class="logo-text">StarTech | Paiement</span>
            </div>
    </nav>

    <div class="checkout-container">
        
        <div class="checkout-step">
            <h2><span class="step-number">2</span> Paiement sécurisé</h2>
            
            <form method="post" action="paiement.php" class="payment-form">
                
                <p style="margin-bottom: 20px; color: #86868b;"><i class="fa-solid fa-lock"></i> Vos informations sont chiffrées. (Ceci est une simulation)</p>

                <div class="form-group card-input-container">
                    <label>Numéro de carte</label>
                    <i class="fa-regular fa-credit-card card-icon"></i>
                    <input type="text" class="form-control card-num" placeholder="•••• •••• •••• ••••" required value="4242 4242 4242 4242">
                </div>
                
                <div class="card-expiry-cvc">
                    <div class="form-group" style="flex:1;">
                        <label>Expiration (MM/AA)</label>
                        <input type="text" class="form-control" placeholder="MM/AA" required value="12/28">
                    </div>
                    <div class="form-group" style="flex:1;">
                        <label>CVC <i class="fa-regular fa-circle-question" style="color:#86868b; cursor:help;" title="Les 3 derniers chiffres au dos de votre carte"></i></label>
                        <input type="text" class="form-control" placeholder="•••" required value="123">
                    </div>
                </div>

                <div class="form-group">
                    <label>Nom sur la carte</label>
                    <input type="text" class="form-control" required value="<?= htmlspecialchars($_SESSION['user_name']) ?>">
                </div>

                <button type="submit" class="pay-btn">
                    <i class="fa-brands fa-apple-pay" style="font-size: 1.5rem;"></i> Payer <?= number_format($total_panier, 2, ',', ' ') ?> €
                </button>
            </form>
        </div>

        <div class="checkout-step">
            <h2>Vérification</h2>
            
            <div class="summary-section">
                <div class="summary-title">Adresse de livraison <a href="checkout.php" class="edit-link">Modifier</a></div>
                <div class="summary-content">
                    <?= nl2br(htmlspecialchars($_SESSION['checkout_adresses']['livraison'])) ?>
                </div>
            </div>
            
            <?php if ($_SESSION['checkout_adresses']['facturation'] !== $_SESSION['checkout_adresses']['livraison']): ?>
            <div class="summary-section">
                <div class="summary-title">Adresse de facturation</div>
                <div class="summary-content">
                    <?= nl2br(htmlspecialchars($_SESSION['checkout_adresses']['facturation'])) ?>
                </div>
            </div>
            <?php endif; ?>

            <div style="margin-top: 20px;">
                <div class="summary-row total-row"><span>Total à payer</span><span><?= number_format($total_panier, 2, ',', ' ') ?> €</span></div>
                <p style="font-size: 0.9rem; color: #86868b; margin-top: 10px;">TVA incluse.</p>
            </div>
        </div>

    </div>

</body>
</html>