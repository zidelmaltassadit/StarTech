<?php
// public/paiement.php (Traitement de la commande)
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 

// --- SÉCURITÉ : Exige la connexion et la méthode POST
if (!is_logged_in() || $_SERVER['REQUEST_METHOD'] !== 'POST' || ($_POST['action'] ?? '') !== 'process_order') {
    header('Location: finaliser_commande.php');
    exit();
}

$client_id = $_SESSION['user_id'];
$panier = $_SESSION['panier'] ?? [];
$methode_paiement = $_POST['methode_paiement'] ?? 'virement';

if (empty($panier)) {
    $_SESSION['flash_message'] = "<div class='alert-warning'>Votre panier est vide.</div>";
    header('Location: catalogue.php');
    exit();
}

// Supposons que vous avez calculé le total (à refaire par sécurité)
require_once '../includes/functions.php'; 
$totaux = calculer_total_panier($panier); 
$total_ht = $totaux['total_ht'];
$total_ttc = $totaux['total_ttc'];

$success = false;

try {
    // 1. Démarrer une transaction (pour s'assurer que tout réussit ou tout échoue)
    $pdo->beginTransaction();

    // 2. Récupérer les adresses du client (à partir de la BDD pour éviter la manipulation de formulaire)
    $sql_addr = "SELECT adresse_livraison_defaut, adresse_facturation_defaut FROM clients WHERE id = :id";
    $stmt_addr = $pdo->prepare($sql_addr);
    $stmt_addr->execute([':id' => $client_id]);
    $adresses = $stmt_addr->fetch(PDO::FETCH_ASSOC);
    
    // 3. Insérer la Commande Principale dans la table 'commandes'
    $sql_cmd = "INSERT INTO commandes (
        client_id, date_commande, statut, total_ht, total_ttc, 
        methode_paiement, adresse_livraison, adresse_facturation
    ) VALUES (
        :client_id, NOW(), :statut, :total_ht, :total_ttc, 
        :methode_paiement, :addr_livraison, :addr_facturation
    )";
    
    // Le statut dépend de la méthode de paiement
    $statut_initial = ($methode_paiement === 'virement') ? 'en_attente_paiement' : 'en_attente';
    
    $stmt_cmd = $pdo->prepare($sql_cmd);
    $stmt_cmd->execute([
        ':client_id'      => $client_id,
        ':statut'         => $statut_initial,
        ':total_ht'       => $total_ht,
        ':total_ttc'      => $total_ttc,
        ':methode_paiement' => $methode_paiement,
        ':addr_livraison' => $adresses['adresse_livraison_defaut'] ?? 'Non définie',
        ':addr_facturation' => $adresses['adresse_facturation_defaut'] ?? 'Non définie'
    ]);
    
    $commande_id = $pdo->lastInsertId();

    // 4. Préparer la requête pour la mise à jour du stock
    // ** TEMPORAIREMENT COMMENTÉ POUR LE DÉBOGAGE **
    // $sql_stock_update = "UPDATE produits SET quantite_stock = quantite_stock - :quantite WHERE id = :produit_id";
    // $stmt_stock_update = $pdo->prepare($sql_stock_update);

    // 5. Insérer les Détails et mettre à jour le stock
    $sql_detail = "INSERT INTO details_commande (
        commande_id, produit_id, quantite, prix_unitaire_ht, prix_unitaire_ttc
    ) VALUES (
        :commande_id, :produit_id, :quantite, :prix_ht, :prix_ttc
    )";
    
    foreach ($panier as $item) {
        // Exécution de l'insertion des détails
        $stmt_detail = $pdo->prepare($sql_detail);
        $stmt_detail->execute([
            ':commande_id' => $commande_id,
            ':produit_id'  => $item['id'],
            ':quantite'    => $item['quantite'],
            ':prix_ht'     => $item['prix_ht'],
            ':prix_ttc'    => $item['prix_ttc']
        ]);
        
        // ** TEMPORAIREMENT COMMENTÉ POUR LE DÉBOGAGE **
        // Exécution de la mise à jour du stock
        /*
        $stmt_stock_update->execute([
            ':quantite'    => $item['quantite'],
            ':produit_id'  => $item['id']
        ]);
        */
    }

    // 6. Si tout est bon, valider la transaction
    $pdo->commit();
    $success = true;

} catch (PDOException $e) {
    // --- BLOC DE DÉBOGAGE CRITIQUE : Affichage sécurisé de l'erreur SQL ---
    if ($pdo->inTransaction()) {
        $pdo->rollBack(); // Annuler toutes les insertions en cas d'erreur
    }
    
    // Utilisation de htmlspecialchars pour éviter de casser le HTML sur la redirection
    $error_message = "<div class='alert-danger'>❌ Erreur SQL lors de la finalisation : 
                      <br><strong>Détails SQL :</strong> " . htmlspecialchars($e->getMessage()) . "</div>";
    
    $_SESSION['flash_message'] = $error_message;
    // --- FIN BLOC DE DÉBOGAGE ---

    header('Location: finaliser_commande.php'); // Rediriger pour afficher l'erreur
    exit();
    
} catch (Exception $e) {
    // Gérer les autres exceptions (comme "Client non trouvé")
    $_SESSION['flash_message'] = "<div class='alert-danger'>Erreur interne : " . htmlspecialchars($e->getMessage()) . "</div>";
    header('Location: finaliser_commande.php');
    exit();
}

if ($success) {
    // Vider le panier après succès
    unset($_SESSION['panier']);
    $_SESSION['flash_message'] = "<div class='alert-success'>✅ Commande N°{$commande_id} enregistrée avec succès. Merci pour votre achat !</div>";
    header('Location: detail_commande.php?id=' . $commande_id); // Rediriger vers le détail
    exit();
} else {
    // Ce cas ne devrait normalement pas être atteint
    $_SESSION['flash_message'] = "<div class='alert-danger'>❌ Une erreur inconnue est survenue.</div>";
    header('Location: finaliser_commande.php');
    exit();
}