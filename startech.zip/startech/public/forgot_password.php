<?php
// public/forgot_password.php
session_start();
require_once '../includes/db_config.php';
// Nous aurons besoin de fonctions pour envoyer l'email plus tard, mais ce n'est pas encore le cas.

$message = '';
$email_sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "<div class='alert-warning'>Veuillez saisir une adresse email valide.</div>";
    } else {
        // --- LOGIQUE DE RÉINITIALISATION (À COMPLÉTER PLUS TARD) ---
        
        // 1. Vérifier si l'email existe dans la table clients
        $sql = "SELECT id FROM clients WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':email' => $email]);
        $client = $stmt->fetch();

        if ($client) {
            // Dans une vraie application, on générerait ici un token de réinitialisation,
            // on l'enregistrerait dans la BDD avec une date d'expiration, 
            // puis on enverrait l'email contenant ce token.

            // Pour l'instant, on simule le succès pour l'utilisateur
            $email_sent = true;
            $message = "<div class='alert-success'>✅ Si cet email est associé à un compte, vous recevrez un lien de réinitialisation. Vérifiez votre boîte de réception.</div>";
        } else {
            // Bonne pratique de sécurité : Ne pas révéler si l'email existe ou non.
            $email_sent = true;
            $message = "<div class='alert-success'>✅ Si cet email est associé à un compte, vous recevrez un lien de réinitialisation. Vérifiez votre boîte de réception.</div>";
        }
        
        // --------------------------------------------------------
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Mot de Passe Oublié</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Boutique</h1>
        </div>
    </header>

    <div class="container public-content form-container">
        <h2>Mot de passe oublié</h2>
        
        <?= $message; ?>
        
        <?php if (!$email_sent): ?>
            <p>Veuillez entrer votre adresse email. Nous vous enverrons un lien pour réinitialiser votre mot de passe.</p>
            
            <form action="forgot_password.php" method="POST" class="form-standard">
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Envoyer le lien de réinitialisation</button>
            </form>
            <p class="mt-3"><a href="login.php">&larr; Retour à la Connexion</a></p>
        <?php else: ?>
            <p><a href="login.php" class="btn btn-secondary">Retour à la Connexion</a></p>
        <?php endif; ?>
        
    </div>
</body>
</html>