<?php
// public/checkout.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. VÉRIFICATION DE SÉCURITÉ
// Si le panier est vide, pas de commande possible
if (empty($_SESSION['panier'])) {
    header('Location: panier.php'); exit;
}

// Si pas connecté, on redirige vers login en mémorisant la page actuelle
if (!is_logged_in()) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    $_SESSION['flash_message'] = "<div class='alert-info'>Veuillez vous connecter pour finaliser votre commande.</div>";
    header('Location: login.php');
    exit;
}

// 2. RÉCUPÉRATION DES ADRESSES DU CLIENT
$client_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT adresse_livraison, adresse_facturation FROM clients WHERE id = ?");
$stmt->execute([$client_id]);
$client_adresses = $stmt->fetch(PDO::FETCH_ASSOC);

// 3. CALCUL DU TOTAL POUR AFFICHAGE
$total_panier = 0;
foreach ($_SESSION['panier'] as $item) { $total_panier += $item['prix'] * $item['quantite']; }

// 4. TRAITEMENT DU FORMULAIRE (Si le client valide ses adresses)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // On stocke les adresses choisies en session pour la prochaine étape (paiement)
    $_SESSION['checkout_adresses'] = [
        'livraison' => trim($_POST['adresse_livraison']),
        'facturation' => !empty($_POST['adresse_facturation']) ? trim($_POST['adresse_facturation']) : trim($_POST['adresse_livraison'])
    ];
    
    // Mise à jour optionnelle des adresses par défaut en BDD si le client le souhaite
    if (isset($_POST['save_addresses'])) {
        $sql = "UPDATE clients SET adresse_livraison = :liv, adresse_facturation = :fac WHERE id = :id";
        $stmt_update = $pdo->prepare($sql);
        $stmt_update->execute([
            ':liv' => $_SESSION['checkout_adresses']['livraison'],
            ':fac' => $_SESSION['checkout_adresses']['facturation'],
            ':id' => $client_id
        ]);
    }

    // Passage à l'étape paiement
    header('Location: paiement.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Livraison - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Style spécifique Checkout (très épuré pour la concentration) */
        body { background: #F5F5F7; }
        .checkout-container { max-width: 1000px; margin: 40px auto; display: grid; grid-template-columns: 1.5fr 1fr; gap: 40px; padding: 0 20px; }
        .checkout-step { background: white; padding: 30px; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); }
        .checkout-step h2 { font-size: 1.5rem; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }
        .step-number { background: #0071e3; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 600; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 8px; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #d2d2d7; border-radius: 10px; resize: vertical; height: 80px; }
        
        .order-summary { position: sticky; top: 80px; height: fit-content; }
        .summary-row { display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 1.1rem; }
        .total-row { font-size: 1.5rem; font-weight: 700; border-top: 1px solid #e5e5e5; padding-top: 15px; }
        .btn-continue { background: #0071e3; color: white; border: none; padding: 15px; width: 100%; border-radius: 12px; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: background 0.3s; }
        .btn-continue:hover { background: #0077ED; }
    </style>
</head>
<body>

    <nav style="background:white; padding: 15px 0; border-bottom: 1px solid #d2d2d7;">
        <div class="container" style="display:flex; justify-content:space-between;">
            <span class="logo-text">StarTech | Commande</span>
            <a href="panier.php" style="color:#0071e3; text-decoration:none;">Retour au panier</a>
        </div>
    </nav>

    <div class="checkout-container">
        
        <div class="checkout-step">
            <h2><span class="step-number">1</span> Adresse de livraison</h2>
            
            <form method="post" action="checkout.php">
                <div class="form-group">
                    <label for="adresse_livraison">Où souhaitez-vous être livré ?</label>
                    <textarea id="adresse_livraison" name="adresse_livraison" class="form-control" required placeholder="Rue, Code Postal, Ville..."><?= htmlspecialchars($client_adresses['adresse_livraison'] ?? '') ?></textarea>
                </div>

                <div style="margin-bottom: 20px;">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" id="same_address" checked onchange="toggleFacturation()">
                        <span>L'adresse de facturation est identique.</span>
                    </label>
                </div>

                <div class="form-group" id="facturation_group" style="display: none;">
                    <label for="adresse_facturation">Adresse de facturation</label>
                    <textarea id="adresse_facturation" name="adresse_facturation" class="form-control" placeholder="Si différente de la livraison..."><?= htmlspecialchars($client_adresses['adresse_facturation'] ?? '') ?></textarea>
                </div>
                
                 <div style="margin-bottom: 30px;">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="save_addresses" value="1" checked>
                        <span style="color: #86868b; font-size: 0.9rem;">Mettre à jour mes adresses par défaut avec ces informations.</span>
                    </label>
                </div>

                <button type="submit" class="btn-continue">Continuer vers le paiement</button>
            </form>
        </div>

        <div class="checkout-step order-summary">
            <h2>Résumé de la commande</h2>
            
            <div style="margin-bottom: 20px; max-height: 200px; overflow-y: auto;">
               <?php foreach ($_SESSION['panier'] as $item): ?>
                <div style="display: flex; align-items: center; margin-bottom: 15px;">
                    
                    <?php 
                        // --- CORRECTION IMAGE ---
                        $img_name = !empty($item['image']) ? $item['image'] : 'default.jpg';
                        
                        if (strpos($img_name, 'http') === 0) {
                            $final_src = $img_name;
                        } else {
                            // Chemin absolu vers le dossier images (sans le dossier "produits")
                            $final_src = "/startech/assets/images/" . $img_name;
                        }
                    ?>
                    
                    <img src="<?= htmlspecialchars($final_src) ?>" 
                         style="width: 50px; height: 50px; object-fit: contain; margin-right: 15px;"
                         onerror="this.style.display='none'"> <div>
                        <div style="font-weight: 500;"><?= htmlspecialchars($item['nom']) ?></div>
                        <div style="color: #86868b; font-size: 0.9rem;">Qté: <?= $item['quantite'] ?></div>
                    </div>
                    <div style="margin-left: auto; font-weight: 500;">
                        <?= number_format($item['prix'] * $item['quantite'], 2, ',', ' ') ?> €
                    </div>
                </div>
            <?php endforeach; ?>
            </div>

            <div class="summary-row"><span>Sous-total</span><span><?= number_format($total_panier, 2, ',', ' ') ?> €</span></div>
            <div class="summary-row"><span>Livraison</span><span style="color:#34C759;">Gratuite</span></div>
            <div class="summary-row total-row"><span>Total à payer</span><span><?= number_format($total_panier, 2, ',', ' ') ?> €</span></div>
        </div>

    </div>

    <script>
        // Petit script pour afficher/cacher l'adresse de facturation
        function toggleFacturation() {
            const checkBox = document.getElementById('same_address');
            const factuGroup = document.getElementById('facturation_group');
            factuGroup.style.display = checkBox.checked ? 'none' : 'block';
        }
        // Lancer au chargement pour respecter l'état initial
        toggleFacturation();
    </script>

</body>
</html>