<?php
// public/support.php
// On démarre la session si nécessaire (le header le fait aussi, mais c'est une sécurité)
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/db_config.php';

// Traitement du formulaire (Simulation)
$message_succes = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simulation de succès
    $message_succes = true;
}

// ============================================================
// 1. ON INCLUT L'EN-TÊTE COMMUN (La même bannière que l'accueil)
// ============================================================
require_once '../includes/public_header.php';
?>

<style>
    .support-container { max-width: 800px; margin: 60px auto; padding: 0 20px; }
    .header-section { text-align: center; margin-bottom: 40px; }
    .header-section h1 { font-size: 2.5rem; font-weight: 700; color: #1d1d1f; }
    .contact-card { background: white; border-radius: 24px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); border: 1px solid #e5e5e5; }
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .form-group { margin-bottom: 25px; }
    .form-label { display: block; font-weight: 600; margin-bottom: 8px; }
    .form-input, .form-select, .form-textarea { width: 100%; padding: 15px; border: 1px solid #d2d2d7; border-radius: 12px; font-size: 1rem; }
    .btn-submit { width: 100%; background: #0071E3; color: white; border: none; padding: 18px; border-radius: 12px; font-size: 1.1rem; font-weight: 600; cursor: pointer; }
    .success-box { text-align: center; padding: 50px; background: white; border-radius: 24px; border: 1px solid #e5e5e5; }
    .simulation-hint { background: #F2F8FF; border-left: 4px solid #0071E3; padding: 15px; border-radius: 8px; margin-top: 10px; display: none; }
</style>

<div class="support-container" style="padding-top: 40px;">
    
    <?php if ($message_succes): ?>
        <div class="success-box">
            <i class="fa-solid fa-circle-check" style="font-size: 4rem; color: #34C759; margin-bottom: 20px;"></i>
            <h1>Demande envoyée !</h1>
            <p style="color: #86868b; font-size: 1.2rem; margin-bottom: 30px;">Notre équipe vous répondra sous 24h.</p>
            <a href="../index.php" style="color: #0071E3; text-decoration: none;">Retour à l'accueil ></a>
        </div>
    <?php else: ?>
        <div class="header-section">
            <h1>Support & Assistance</h1>
            <p style="color: #86868b; font-size: 1.1rem;">Utilisez notre assistant pour qualifier votre demande.</p>
        </div>

        <div class="contact-card">
            <form method="post">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Votre Nom</label>
                        <input type="text" name="nom" class="form-input" required value="<?= isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : '' ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Votre Email</label>
                        <input type="email" name="email" class="form-input" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Sujet <span style="color:#0071E3;">(Assistant)</span></label>
                    <select name="sujet" id="sujet-select" class="form-select" required onchange="updateSimulator()">
                        <option value="">-- Choisir --</option>
                        <option value="commande">Problème commande</option>
                        <option value="technique">Question technique</option>
                        <option value="compte">Accès compte</option>
                    </select>
                    <div id="hint-commande" class="simulation-hint"><i class="fa-solid fa-box"></i> Merci d'indiquer votre N° de commande.</div>
                    <div id="hint-technique" class="simulation-hint"><i class="fa-solid fa-microchip"></i> Précisez le modèle et le numéro de série.</div>
                    <div id="hint-compte" class="simulation-hint"><i class="fa-solid fa-lock"></i> Pour le mot de passe, utilisez la page de connexion.</div>
                </div>

                <div class="form-group">
                    <label class="form-label">Message</label>
                    <textarea name="message" class="form-textarea" required style="height: 120px;"></textarea>
                </div>

                <button type="submit" class="btn-submit">Envoyer la demande</button>
            </form>
        </div>
    <?php endif; ?>

</div>

<script>
    function updateSimulator() {
        document.querySelectorAll('.simulation-hint').forEach(el => el.style.display = 'none');
        const val = document.getElementById('sujet-select').value;
        if (val && document.getElementById('hint-' + val)) {
            document.getElementById('hint-' + val).style.display = 'block';
        }
    }
</script>

<?php
// ============================================================
// 2. ON INCLUT LE PIED DE PAGE COMMUN
// ============================================================
require_once '../includes/public_footer.php';
?>