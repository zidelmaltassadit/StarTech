<?php
// public/confirmation.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_once '../includes/functions.php'; // Pour generer_numero_commande() si tu l'as

// --- SÉCURITÉ MAXIMALE ---
// On ne peut arriver ici que SI : Panier rempli + Connecté + Adresses OK + Paiement SUCCÈS
if (empty($_SESSION['panier']) || !is_logged_in() || !isset($_SESSION['checkout_adresses']) || !isset($_SESSION['payment_success'])) {
    // Si une condition manque, c'est une tentative de triche ou un bug -> Retour panier
    header('Location: panier.php');
    exit;
}

$client_id = $_SESSION['user_id'];
$adresses = $_SESSION['checkout_adresses'];
$panier = $_SESSION['panier'];
$order_id = null;
$erreur_commande = '';

// --- TRANSACTION SQL (Le moment critique) ---
try {
    // 1. Démarrer la transaction (tout ou rien)
    $pdo->beginTransaction();

    // 2. Calcul du total
    $total_ht = 0;
    $total_ttc = 0;
    foreach ($panier as $item) {
        $prix_ttc_item = $item['prix'];
        // On suppose un taux de TVA de 20% (à adapter si besoin)
        $prix_ht_item = $prix_ttc_item / 1.20;
        
        $total_ttc += $prix_ttc_item * $item['quantite'];
        $total_ht += $prix_ht_item * $item['quantite'];
    }
    $total_tva = $total_ttc - $total_ht;

    // 3. Insérer la COMMANDE principale
    // CORRECTION ICI : J'ai remplacé 'total_ttc' par 'montant_total' pour correspondre à ta base
    $sql_cmd = "INSERT INTO commandes (client_id, date_commande, statut, total_ht, total_tva, montant_total, adresse_livraison, adresse_facturation, moyen_paiement) 
                VALUES (:client, NOW(), 'en_attente', :ht, :tva, :ttc, :liv, :fac, :pay)";
    
    $stmt_cmd = $pdo->prepare($sql_cmd);
    $stmt_cmd->execute([
        ':client' => $client_id,
        ':ht' => $total_ht,
        ':tva' => $total_tva,
        ':ttc' => $total_ttc, // On met la valeur du TTC dans la colonne montant_total
        ':liv' => $adresses['livraison'],
        ':fac' => $adresses['facturation'],
        ':pay' => $_SESSION['payment_method']
    ]);
    
    $order_id = $pdo->lastInsertId();

    // 4. Insérer les LIGNES de commande et MAJ STOCK
    // (Le reste du code ne change pas)
    $sql_ligne = "INSERT INTO details_commande (commande_id, produit_id, quantite, prix_unitaire_ht, prix_total_ht, prix_total_ttc, options) 
                  VALUES (:cmd_id, :prod_id, :qte, :pu_ht, :pt_ht, :pt_ttc, :opts)";
    
    $sql_stock = "UPDATE produits SET quantite_stock = quantite_stock - :qte WHERE id = :prod_id";
    
    $stmt_ligne = $pdo->prepare($sql_ligne);
    $stmt_stock = $pdo->prepare($sql_stock);

    foreach ($panier as $item) {
        $prix_ttc_item = $item['prix'];
        $prix_ht_item = $prix_ttc_item / 1.20;

        $stmt_ligne->execute([
            ':cmd_id' => $order_id,
            ':prod_id' => $item['id'],
            ':qte' => $item['quantite'],
            ':pu_ht' => $prix_ht_item,
            ':pt_ht' => $prix_ht_item * $item['quantite'],
            ':pt_ttc' => $prix_ttc_item * $item['quantite'],
            ':opts' => !empty($item['options']) ? json_encode($item['options']) : null
        ]);

        $stmt_stock->execute([
            ':qte' => $item['quantite'],
            ':prod_id' => $item['id']
        ]);
    }

    // 5. Si tout est OK, on valide la transaction
    $pdo->commit();

    // 6. GRAND NETTOYAGE
    unset($_SESSION['panier']);
    unset($_SESSION['checkout_adresses']);
    unset($_SESSION['payment_success']);
    unset($_SESSION['payment_method']);

} catch (PDOException $e) {
    // En cas d'erreur, on annule tout
    $pdo->rollBack();
    
    // On définit un message d'erreur "propre" pour l'utilisateur
    $erreur_commande = "Une erreur technique est survenue lors de l'enregistrement de votre commande. Veuillez contacter le support.";
    
    // NOTE POUR TOI (DEV) : Si tu veux voir l'erreur réelle pour déboguer, 
    // décommente temporairement la ligne suivante :
    // die($e->getMessage()); 
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Confirmation - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #F5F5F7; display: flex; justify-content: center; align-items: center; min-height: 80vh; }
        .confirmation-card { background: white; padding: 50px; border-radius: 24px; box-shadow: 0 10px 40px rgba(0,0,0,0.08); text-align: center; max-width: 600px; width: 100%; }
        .success-icon { font-size: 5rem; color: #34C759; margin-bottom: 30px; }
        h1 { font-size: 2.5rem; margin-bottom: 20px; color: #1d1d1f; }
        .order-number { font-size: 1.8rem; font-weight: 700; color: #0071e3; margin: 20px 0; }
        .btn-group { display: flex; gap: 15px; justify-content: center; margin-top: 40px; }
        .btn-secondary { background: #f5f5f7; color: #1d1d1f; }
    </style>
</head>
<body>

    <div class="confirmation-card">
        <?php if ($order_id): ?>
            <i class="fa-solid fa-circle-check success-icon"></i>
            <h1>Merci pour votre commande !</h1>
            <p style="font-size: 1.1rem; color: #86868b;">Votre paiement a été validé. Vous recevrez bientôt un email de confirmation.</p>
            
            <div class="order-number">Commande #<?= str_pad($order_id, 6, '0', STR_PAD_LEFT) ?></div>
            
            <div class="btn-group">
                <a href="facture_pdf.php?id=<?= $order_id ?>" target="_blank" class="btn btn-secondary">
                    <i class="fa-solid fa-file-pdf"></i> Télécharger la facture
                </a>
                <a href="client_dashboard.php" class="btn btn-primary">
                    Voir dans mon compte
                </a>
            </div>

        <?php else: ?>
            <i class="fa-solid fa-triangle-exclamation success-icon" style="color: #FF3B30;"></i>
            <h1>Oups, une erreur est survenue.</h1>
            <p>Votre commande n'a pas pu être enregistrée.</p>
            <div class="alert alert-danger" style="margin-top: 20px; text-align: left;"><?= $erreur_commande ?></div>
            <p style="margin-top: 20px;">Veuillez contacter le support si le problème persiste.</p>
            <a href="panier.php" class="btn btn-primary" style="margin-top: 30px;">Retour au panier</a>
        <?php endif; ?>
    </div>

</body>
</html>