<?php
// fournisseurs/dashboard.php
session_start();
// On remonte d'un cran pour trouver le dossier includes
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ : Accès strictement réservé aux fournisseurs
if (!is_logged_in() || $_SESSION['user_role'] !== 'fournisseur') {
    // Si ce n'est pas un fournisseur, on le renvoie vers la page de connexion publique
    header('Location: ../public/login.php');
    exit;
}

$fournisseur_id = $_SESSION['user_id'];

// 2. RÉCUPÉRATION DES STATS (KPIs)
// A. Nombre de commandes "commandee" (c'est-à-dire en attente de traitement par le fournisseur)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM commandes_achat WHERE fournisseur_id = ? AND statut = 'commandee'");
$stmt->execute([$fournisseur_id]);
$nb_a_traiter = $stmt->fetchColumn();

// B. Nombre de produits de ce fournisseur référencés dans le catalogue
$stmt = $pdo->prepare("SELECT COUNT(*) FROM produits WHERE fournisseur_id = ?");
$stmt->execute([$fournisseur_id]);
$nb_produits = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Partenaire - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Styles spécifiques pour l'espace fournisseur */
        .supplier-body { background-color: #F5F5F7; }
        .supplier-layout { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
        
        /* Style de la barre de navigation */
        .nav-supplier {
            background: white; padding: 20px 30px; border-radius: 18px;
            margin-bottom: 40px; display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        }
        .nav-links a {
            text-decoration: none; color: #86868b; font-weight: 600; margin-left: 30px;
            transition: color 0.2s;
        }
        .nav-links a:hover, .nav-links a.active { color: #0071E3; }
        
        /* En-tête de bienvenue */
        .welcome-header { margin-bottom: 40px; }
        .welcome-header h1 { font-size: 2.5rem; font-weight: 700; color: #1D1D1F; margin-bottom: 10px; }
    </style>
</head>
<body class="supplier-body">

    <div class="supplier-layout">
        
        <nav class="nav-supplier">
            <div class="logo-text" style="font-size: 1.2rem;">StarTech | Portail Fournisseur</div>
            <div class="nav-links">
                <a href="dashboard.php" class="active">Accueil</a>
                <a href="mes_produits.php">Mes Produits</a>
                <a href="commandes.php">Mes Commandes</a>
                
                <span style="margin-left: 40px; margin-right: 20px; color: #86868b; font-weight: 500;">
                    <i class="fa-regular fa-user-circle"></i> <?= htmlspecialchars($_SESSION['user_name']) ?>
                </span>
                <a href="../public/logout.php" style="color: #FF3B30;"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            </div>
        </nav>

        <div class="welcome-header">
            <h1>Bonjour, partenaire.</h1>
            <p style="font-size: 1.2rem; color: #86868b;">Bienvenue sur votre espace de gestion StarTech.</p>
        </div>

        <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
            
            <div class="kpi-card" style="cursor: pointer;" onclick="window.location='commandes.php'">
                <div class="icon-box orange"><i class="fa-solid fa-box-open"></i></div>
                <div class="kpi-info">
                    <h3>Commandes en attente</h3>
                    <p class="value"><?= $nb_a_traiter ?></p>
                    <?php if($nb_a_traiter > 0): ?>
                        <span class="trend negative" style="color: #FF9F43;"><i class="fa-solid fa-circle-exclamation"></i> Action requise</span>
                    <?php else: ?>
                        <span class="trend positive"><i class="fa-solid fa-check-circle"></i> À jour</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="kpi-card">
                <div class="icon-box blue"><i class="fa-solid fa-tag"></i></div>
                <div class="kpi-info">
                    <h3>Produits référencés</h3>
                    <p class="value"><?= $nb_produits ?></p>
                    <span class="trend neutral" style="color: #86868b;">Dans le catalogue StarTech</span>
                </div>
            </div>

        </div>

    </div>

</body>
</html>