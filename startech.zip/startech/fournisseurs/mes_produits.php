<?php
// fournisseurs/mes_produits.php (VERSION MODIFIABLE)
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in() || $_SESSION['user_role'] !== 'fournisseur') {
    header('Location: ../public/login.php');
    exit;
}

$fournisseur_id = $_SESSION['user_id'];

// Gestion des messages de confirmation
$message = '';
if (isset($_GET['msg']) && $_GET['msg'] == 'updated') {
    $count = (int)($_GET['count'] ?? 0);
    $message = "<div class='alert-floating'><i class='fa-solid fa-circle-check'></i> Succès : {$count} prix mis à jour.</div>";
}

// 2. RÉCUPÉRATION DES PRODUITS
$sql = "SELECT p.*, c.nom as cat_nom
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.fournisseur_id = ?
        ORDER BY p.nom ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$fournisseur_id]);
$produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gérer mes tarifs - Espace Fournisseur</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .supplier-body { background-color: #F5F5F7; }
        .supplier-layout { max-width: 1200px; margin: 40px auto; padding: 0 20px; padding-bottom: 80px; /* Place pour le bouton fixe */ }
        .nav-supplier {
            background: white; padding: 20px 30px; border-radius: 18px;
            margin-bottom: 40px; display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        }
        .nav-links a {
            text-decoration: none; color: #86868b; font-weight: 600; margin-left: 30px;
            transition: color 0.2s;
        }
        .nav-links a:hover, .nav-links a.active { color: #0071E3; }
        .apple-table th { background: #F5F5F7; }
        .product-img-small { width: 40px; height: 40px; object-fit: contain; border-radius: 8px; background: #fff; padding: 2px; border: 1px solid #eee; }
        
        /* Styles pour les champs de prix modifiables */
        .price-input {
            width: 100px;
            padding: 8px 12px;
            border: 1px solid #d2d2d7;
            border-radius: 8px;
            font-weight: 600;
            text-align: right;
            font-size: 1rem;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .price-input:focus {
            border-color: #0071E3;
            box-shadow: 0 0 0 3px rgba(0,113,227,0.1);
            outline: none;
        }
        .currency-symbol { margin-left: 5px; color: var(--text-secondary); font-weight: 600; }

        /* Barre d'action fixe en bas */
        .bottom-action-bar {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: white; padding: 15px 30px;
            border-top: 1px solid var(--border-color);
            display: flex; justify-content: flex-end; align-items: center;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.05);
            z-index: 100;
        }

        /* Alerte flottante */
        .alert-floating {
            position: fixed; top: 30px; right: 30px;
            background: #E8FDF2; color: #1D1D1F; padding: 15px 25px;
            border-radius: 50px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            font-weight: 600; z-index: 200; animation: slideIn 0.3s ease-out;
            display: flex; align-items: center; gap: 10px;
        }
        .alert-floating i { color: #34C759; font-size: 1.2rem; }
        @keyframes slideIn { from { transform: translateY(-100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    </style>
</head>
<body class="supplier-body">

    <?= $message ?>

    <div class="supplier-layout">
        
        <nav class="nav-supplier">
            <div class="logo-text" style="font-size: 1.2rem;">StarTech | Portail Fournisseur</div>
            <div class="nav-links">
                <a href="dashboard.php">Accueil</a>
                <a href="mes_produits.php" class="active">Gérer mes tarifs</a>
                <a href="commandes.php">Mes Commandes</a>
                
                <span style="margin-left: 40px; margin-right: 20px; color: #86868b; font-weight: 500;">
                    <i class="fa-regular fa-user-circle"></i> <?= htmlspecialchars($_SESSION['user_name']) ?>
                </span>
                <a href="../public/logout.php" style="color: #FF3B30;"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            </div>
        </nav>

        <header class="top-bar" style="margin-bottom: 10px;">
            <h1>Catalogue et Tarifs</h1>
        </header>
        <p style="color: var(--text-secondary); margin-bottom: 30px;">Modifiez vos prix de vente HT dans la colonne dédiée et enregistrez en bas de page.</p>

        <form action="traitement_prix.php" method="post">

            <div class="card" style="padding: 0; overflow: hidden;">
                <table class="apple-table">
                    <thead>
                        <tr>
                            <th style="padding-left: 30px;">Image</th>
                            <th>Nom du Produit</th>
                            <th>Catégorie</th>
                            <th style="color: #0071E3;">Votre Prix de Vente (HT) <i class="fa-solid fa-pen" style="font-size: 0.8rem;"></i></th>
                            <th>Stock StarTech</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($produits)): ?>
                            <tr><td colspan="5" style="text-align:center; color:#86868b; padding: 40px;">Aucun produit n'est associé à votre compte.</td></tr>
                        <?php else: ?>
                            <?php foreach($produits as $p): ?>
                                <?php $img_src = !empty($p['image']) ? (strpos($p['image'], 'http') === 0 ? $p['image'] : "/startech/assets/images/produits/" . $p['image']) : 'https://dummyimage.com/40x40/eee/aaa'; ?>
                                <tr>
                                    <td style="padding-left: 30px;">
                                        <img src="<?= htmlspecialchars($img_src) ?>" class="product-img-small">
                                    </td>
                                    <td style="font-weight: 600;"><?= htmlspecialchars($p['nom']) ?></td>
                                    <td><span style="background:#F5F5F7; padding:4px 10px; border-radius:12px; font-size:0.85rem;"><?= htmlspecialchars($p['cat_nom'] ?? '-') ?></span></td>
                                    
                                    <td style="font-weight: 700;">
                                        <div style="display: flex; align-items: center;">
                                            <input type="number" step="0.01" min="0" 
                                                   name="prix[<?= $p['id'] ?>]" 
                                                   value="<?= $p['prix_achat'] ?>" 
                                                   class="price-input">
                                            <span class="currency-symbol">€</span>
                                        </div>
                                    </td>
                                    
                                    <td style="color: #86868b;">
                                        <?= $p['quantite_stock'] ?> unités
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="bottom-action-bar">
                <div style="margin-right: 20px; color: var(--text-secondary); font-size: 0.9rem;">
                    <i class="fa-solid fa-circle-info"></i> N'oubliez pas d'enregistrer vos modifications.
                </div>
                <button type="submit" name="update_prix" class="btn btn-primary" style="padding: 12px 25px; font-size: 1rem; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-floppy-disk"></i> Enregistrer les nouveaux tarifs
                </button>
            </div>

        </form> </div>

    <script>
        setTimeout(function() {
            const alert = document.querySelector('.alert-floating');
            if (alert) {
                alert.style.transition = 'opacity 0.5s, transform 0.5s';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 500);
            }
        }, 3000);
    </script>

</body>
</html>