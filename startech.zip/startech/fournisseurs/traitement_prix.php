<?php
// fournisseurs/traitement_prix.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ MAXIMALE
if (!is_logged_in() || $_SESSION['user_role'] !== 'fournisseur') {
    die("Accès refusé.");
}

$fournisseur_id = $_SESSION['user_id'];

// 2. TRAITEMENT DU FORMULAIRE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_prix'])) {
    
    // On récupère le tableau des prix envoyé par le formulaire
    // Le format est : [ id_produit => nouveau_prix, id_produit2 => nouveau_prix2, ... ]
    $nouveaux_prix = $_POST['prix'] ?? [];
    $count_updated = 0;

    try {
        $pdo->beginTransaction();

        // Requête préparée pour la sécurité.
        // TRÈS IMPORTANT : La clause "AND fournisseur_id = ?" empêche un fournisseur 
        // de modifier les prix d'un autre fournisseur en bidouillant le HTML.
        $sql = "UPDATE produits SET prix_achat = ? WHERE id = ? AND fournisseur_id = ?";
        $stmt = $pdo->prepare($sql);

        foreach ($nouveaux_prix as $prod_id => $prix_valeur) {
            // Nettoyage et validation du prix
            $prix_float = (float) str_replace(',', '.', $prix_valeur); // Gère les virgules

            if ($prix_float >= 0 && is_numeric($prod_id)) {
                // Exécution de la mise à jour
                $stmt->execute([$prix_float, $prod_id, $fournisseur_id]);
                // rowCount() retourne le nombre de lignes affectées. Si > 0, c'est que ça a marché.
                if ($stmt->rowCount() > 0) {
                    $count_updated++;
                }
            }
        }

        $pdo->commit();
        
        // Redirection avec message de succès
        header("Location: mes_produits.php?msg=updated&count=" . $count_updated);
        exit;

    } catch (PDOException $e) {
        $pdo->rollBack();
        // En production, on loguerait l'erreur dans un fichier
        die("Erreur lors de la mise à jour : " . $e->getMessage());
    }
} else {
    // Si on essaie d'accéder à la page sans soumettre le formulaire
    header("Location: mes_produits.php");
    exit;
}
?>