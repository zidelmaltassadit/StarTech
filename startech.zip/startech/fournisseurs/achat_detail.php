<?php
// fournisseurs/achat_detail.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ : Accès fournisseur uniquement
if (!is_logged_in() || $_SESSION['user_role'] !== 'fournisseur') {
    header('Location: ../public/login.php');
    exit;
}

$fournisseur_id = $_SESSION['user_id'];
$achat_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($achat_id === 0) { die("ID de commande invalide."); }

$message = '';

// --- RÉCUPÉRATION INITIALE (Pour vérifier les droits avant traitement) ---
$stmt_check = $pdo->prepare("SELECT statut FROM commandes_achat WHERE id = ? AND fournisseur_id = ?");
$stmt_check->execute([$achat_id, $fournisseur_id]);
$statut_actuel = $stmt_check->fetchColumn();

if (!$statut_actuel) { die("Commande introuvable ou accès refusé."); }

// --- TRAITEMENT : CONFIRMATION D'EXPÉDITION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['expedier'])) {
    if ($statut_actuel === 'commandee') {
        try {
            $stmt_update = $pdo->prepare("UPDATE commandes_achat SET statut = 'expediee' WHERE id = ?");
            $stmt_update->execute([$achat_id]);
            // On rafraîchit la page pour voir le changement
            header("Location: achat_detail.php?id=" . $achat_id . "&msg=expediee");
            exit;
        } catch (PDOException $e) {
            $message = "<div class='alert alert-danger'>Erreur : " . $e->getMessage() . "</div>";
        }
    }
}

// Message de succès après redirection
if (isset($_GET['msg']) && $_GET['msg'] === 'expediee') {
    $message = "<div class='alert alert-success' style='background:#E8F2FF; color:#0071E3; padding:15px; border-radius:12px; margin-bottom:20px; font-weight:600;'><i class='fa-solid fa-truck-fast'></i> Commande marquée comme expédiée. Merci !</div>";
}


// --- RÉCUPÉRATION COMPLÈTE DES DONNÉES POUR L'AFFICHAGE ---
try {
    // A. Infos Commande
    $sql_cmd = "SELECT * FROM commandes_achat WHERE id = ?";
    $stmt = $pdo->prepare($sql_cmd);
    $stmt->execute([$achat_id]);
    $achat = $stmt->fetch(PDO::FETCH_ASSOC);

    // B. Détails (Produits)
    $sql_details = "SELECT dca.*, p.nom as prod_nom, p.image as prod_image
                    FROM details_commande_achat dca
                    LEFT JOIN produits p ON dca.produit_id = p.id
                    WHERE dca.commande_achat_id = ?";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([$achat_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}

// Définition du style et du libellé du statut
$status_class = 'status-en_attente';
$statut_label = ucfirst($achat['statut']);

switch($achat['statut']) {
    case 'commandee': 
        $statut_label = 'À Traiter'; 
        break;
    case 'expediee':
        $status_class = 'status-expediee'; // Nouveau style
        $statut_label = 'En cours de livraison';
        break;
    case 'receptionnee':
        $status_class = 'status-livree';
        $statut_label = 'Terminée';
        break;
    case 'annulee':
        $status_class = 'status-annulee';
        break;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Commande #<?= $achat_id ?> - Espace Fournisseur</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .supplier-body { background-color: #F5F5F7; }
        .supplier-layout { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
        .nav-supplier { background: white; padding: 20px 30px; border-radius: 18px; margin-bottom: 40px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .nav-links a { text-decoration: none; color: #86868b; font-weight: 600; margin-left: 30px; transition: color 0.2s; }
        .nav-links a:hover, .nav-links a.active { color: #0071E3; }
        
        /* Styles pour le détail */
        .detail-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
        .product-item { display: flex; align-items: center; gap: 20px; padding: 15px 0; border-bottom: 1px solid var(--border-color); }
        .product-img { width: 60px; height: 60px; object-fit: contain; border-radius: 10px; background: #F5F5F7; padding: 5px; }

        /* NOUVEAU STYLE POUR LE STATUT EXPÉDIÉE */
        .status-expediee { background: #F2E8FF; color: #9D50FF; } /* Violet */
    </style>
</head>
<body class="supplier-body">

    <div class="supplier-layout">
        
        <nav class="nav-supplier">
            <div class="logo-text" style="font-size: 1.2rem;">StarTech | Portail Fournisseur</div>
            <div class="nav-links">
                <a href="dashboard.php">Accueil</a>
                <a href="mes_produits.php">Mes Produits</a>
                <a href="commandes.php" class="active">Mes Commandes</a>
                <span style="margin-left: 40px; margin-right: 20px; color: #86868b; font-weight: 500;">
                    <i class="fa-regular fa-user-circle"></i> <?= htmlspecialchars($_SESSION['user_name']) ?>
                </span>
                <a href="../public/logout.php" style="color: #FF3B30;"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            </div>
        </nav>

        <div class="main-content" style="padding: 0;">
            
            <a href="commandes.php" style="display:inline-flex; align-items:center; gap:10px; margin-bottom:30px; font-weight:600;">
                <i class="fa-solid fa-arrow-left"></i> Retour à la liste
            </a>

            <header class="top-bar">
                <h1>Commande #ACH-<?= str_pad($achat['id'], 5, '0', STR_PAD_LEFT) ?></h1>
                <span class="status-badge <?= $status_class ?>" style="font-size: 1rem; padding: 8px 20px;">
                    <?= $statut_label ?>
                </span>
            </header>

            <?= $message ?>

            <div class="detail-layout">
                
                <div class="left-col">
                    <div class="card">
                        <div class="section-header"><h2><i class="fa-solid fa-circle-info"></i> Informations de la commande</h2></div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                            <div>
                                <h3 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 10px;">Client (Nous)</h3>
                                <p><strong>StarTech SAS</strong></p>
                                <p>123 Avenue de la Tech, Paris</p>
                                <p>service.achats@startech.com</p>
                            </div>
                            <div>
                                <h3 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 10px;">Dates</h3>
                                <p>Reçue le : <strong><?= (new DateTime($achat['date_commande']))->format('d/m/Y') ?></strong></p>
                                <p>Livraison attendue : <strong><?= !empty($achat['date_reception_prevue']) ? (new DateTime($achat['date_reception_prevue']))->format('d/m/Y') : 'Non spécifiée' ?></strong></p>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="section-header"><h2><i class="fa-solid fa-box-open"></i> Produits à expédier</h2></div>
                        <?php foreach($details as $item): ?>
                            <?php $img_src = !empty($item['prod_image']) ? (strpos($item['prod_image'], 'http') === 0 ? $item['prod_image'] : "/startech/assets/images/produits/" . $item['prod_image']) : 'https://dummyimage.com/60x60/eee/aaa'; ?>
                            <div class="product-item">
                                <img src="<?= htmlspecialchars($img_src) ?>" class="product-img">
                                <div style="flex-grow: 1;">
                                    <div style="font-weight: 600; font-size: 1.1rem;"><?= htmlspecialchars($item['prod_nom']) ?></div>
                                    <small style="color: var(--text-secondary);">Réf interne: #<?= $item['produit_id'] ?></small>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: 1.2rem;">Quantité : <strong><?= $item['quantite_commandee'] ?></strong></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="right-col">
                    <div class="card" style="background: #F5F5F7; border: 1px solid var(--border-color); position: sticky; top: 30px;">
                        <div class="section-header">
                            <h2><i class="fa-solid fa-truck-fast"></i> Traitement</h2>
                        </div>
                        
                        <?php if ($achat['statut'] === 'commandee'): ?>
                            <p style="color: var(--text-primary); margin-bottom: 20px;">
                                Une fois la marchandise préparée et envoyée, veuillez confirmer l'expédition ici.
                            </p>
                            <form method="post">
                                <button type="submit" name="expedier" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;" onclick="return confirm('Confirmer l\'expédition de la commande ?');">
                                    <i class="fa-solid fa-check"></i> Confirmer l'expédition
                                </button>
                            </form>

                        <?php elseif ($achat['statut'] === 'expediee'): ?>
                            <div class="alert alert-info" style="background:#F2E8FF; color:#9D50FF; padding:15px; border-radius:12px; font-weight:600; margin-bottom: 20px;">
                                <i class="fa-solid fa-truck"></i> Commande en cours de livraison
                            </div>
                            <p style="color: var(--text-secondary);">En attente de réception par StarTech.</p>

                        <?php elseif ($achat['statut'] === 'receptionnee'): ?>
                            <div class="alert alert-success" style="background:#E8FDF2; color:var(--accent-green); padding:15px; border-radius:12px; font-weight:600;">
                                <i class="fa-solid fa-circle-check"></i> Commande terminée
                            </div>
                            <p style="text-align:center; margin-top:10px; color:var(--text-secondary);">Marchandise reçue par StarTech.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>

</body>
</html>