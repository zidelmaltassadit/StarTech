<?php
// fournisseurs/commandes.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in() || $_SESSION['user_role'] !== 'fournisseur') {
    header('Location: ../public/login.php');
    exit;
}

$fournisseur_id = $_SESSION['user_id'];

// 2. RÉCUPÉRATION DES COMMANDES DE CE FOURNISSEUR
// On compte aussi le nombre de produits par commande
$sql = "SELECT ca.*,
               (SELECT COUNT(*) FROM details_commande_achat WHERE commande_achat_id = ca.id) as nb_produits
        FROM commandes_achat ca
        WHERE ca.fournisseur_id = ?
        ORDER BY ca.date_commande DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$fournisseur_id]);
$commandes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Commandes - Espace Fournisseur</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .supplier-body { background-color: #F5F5F7; }
        .supplier-layout { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
        .nav-supplier {
            background: white; padding: 20px 30px; border-radius: 18px;
            margin-bottom: 40px; display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        }
        .nav-links a {
            text-decoration: none; color: #86868b; font-weight: 600; margin-left: 30px;
            transition: color 0.2s;
        }
        .nav-links a:hover, .nav-links a.active { color: #0071E3; }
        /* On force le fond des en-têtes de tableau en gris clair pour ce layout */
        .apple-table th { background: #F5F5F7; }
    </style>
</head>
<body class="supplier-body">

    <div class="supplier-layout">
        
        <nav class="nav-supplier">
            <div class="logo-text" style="font-size: 1.2rem;">StarTech | Portail Fournisseur</div>
            <div class="nav-links">
                <a href="dashboard.php">Accueil</a>
                <a href="mes_produits.php">Mes Produits</a>
                <a href="commandes.php" class="active">Mes Commandes</a>
                
                <span style="margin-left: 40px; margin-right: 20px; color: #86868b; font-weight: 500;">
                    <i class="fa-regular fa-user-circle"></i> <?= htmlspecialchars($_SESSION['user_name']) ?>
                </span>
                <a href="../public/logout.php" style="color: #FF3B30;"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            </div>
        </nav>

        <header class="top-bar">
            <h1>Historique des commandes</h1>
        </header>

        <div class="card" style="padding: 0; overflow: hidden;">
            <table class="apple-table">
                <thead>
                    <tr>
                        <th style="padding-left: 30px;">N° Commande</th>
                        <th>Date</th>
                        <th>Date Prévue</th>
                        <th>Articles</th>
                        <th>Montant HT</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($commandes)): ?>
                        <tr><td colspan="7" style="text-align:center; color:#86868b; padding: 40px;">Vous n'avez reçu aucune commande pour le moment.</td></tr>
                    <?php else: ?>
                        <?php foreach($commandes as $c): ?>
                            <?php 
                                $status_class = 'status-en_attente'; // Pour 'commandee' ou 'brouillon'
                                if($c['statut'] == 'receptionnee') $status_class = 'status-livree';
                                if($c['statut'] == 'annulee') $status_class = 'status-annulee';
                                $statut_label = ($c['statut'] == 'commandee') ? 'À Traiter' : ucfirst($c['statut']);
                            ?>
                            <tr>
                                <td style="padding-left: 30px;" class="font-mono">#ACH-<?= str_pad($c['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                <td><?= (new DateTime($c['date_commande']))->format('d/m/Y') ?></td>
                                <td><?= !empty($c['date_reception_prevue']) ? (new DateTime($c['date_reception_prevue']))->format('d/m/Y') : '-' ?></td>
                                <td><?= $c['nb_produits'] ?></td>
                                <td style="font-weight: 700;"><?= number_format($c['montant_total'], 2, ',', ' ') ?> €</td>
                                <td>
                                    <span class="status-badge <?= $status_class ?>">
                                        <?= $statut_label ?>
                                    </span>
                                </td>
                                <td>
                                   <a href="achat_detail.php?id=<?= $c['id'] ?>" class="btn-small btn-outline">Voir le détail</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

</body>
</html>