<?php
// admin/produits.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
// Rôles autorisés à voir et gérer les produits
$allowed = ['admin', 'administrateur', 'logistique', 'production', 'commercial'];
if (!in_array(strtolower($_SESSION['user_role']), $allowed)) { die("Accès refusé."); }

// 2. RÉCUPÉRATION DES PRODUITS (Avec jointures pour les noms de cat. et fourn.)
// On utilise LEFT JOIN pour afficher le produit même s'il n'a pas de catégorie ou fournisseur
$sql = "SELECT p.*, c.nom as cat_nom, u.nom as fourn_nom
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        LEFT JOIN utilisateurs u ON p.fournisseur_id = u.id
        ORDER BY p.nom ASC";
$produits = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Produits - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="admin-body">

    <div class="admin-layout grid-layout">
     <?php include 'admin_sidebar.php'; ?>

        <main class="main-content">
            
            <header class="top-bar">
                <h1>Produits & Stock</h1>
                <a href="produit_form.php" class="btn btn-primary" style="display:flex; align-items:center; gap:10px;">
                    <i class="fa-solid fa-plus"></i> Nouveau Produit
                </a>
            </header>

            <div class="card" style="padding: 0; overflow: hidden;">
                <table class="apple-table">
                    <thead>
                        <tr>
                            <th style="padding-left: 30px;">Image</th>
                            <th>Nom du Produit</th>
                            <th>Catégorie</th>
                            <th>Stock</th>
                            <th>Seuil Alerte</th>
                            <th>Prix Vente (TTC)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($produits as $p): ?>
                            <?php 
                                // Gestion de l'image
                                $img_src = !empty($p['image']) ? (strpos($p['image'], 'http') === 0 ? $p['image'] : "/startech/assets/images/produits/" . $p['image']) : 'https://dummyimage.com/50x50/eee/aaa';
                                // Statut du stock
                                $stock_class = ($p['quantite_stock'] <= $p['seuil_alerte']) ? 'status-annulee' : 'status-livree'; // Rouge si sous le seuil, vert sinon
                            ?>
                            <tr>
                              <td style="padding-left: 30px;">
    <img src="../assets/images/produits/<?= $p['image'] ?>" class="product-img-small">
</td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($p['nom']) ?></td>
                                <td>
                                    <span style="background:#F5F5F7; padding:4px 10px; border-radius:12px; font-size:0.85rem; font-weight:500;">
                                        <?= htmlspecialchars($p['cat_nom'] ?? 'Aucune') ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="status-badge <?= $stock_class ?>">
                                        <?= $p['quantite_stock'] ?> unités
                                    </span>
                                </td>
                                <td class="font-mono"><?= $p['seuil_alerte'] ?></td>
                                <td style="font-weight: 700;"><?= number_format($p['prix_vente'], 2, ',', ' ') ?> €</td>
                                <td style="display: flex; gap: 10px;">
                                    <a href="produit_form.php?id=<?= $p['id'] ?>" class="btn-small btn-outline" title="Modifier">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <a href="produit_delete.php?id=<?= $p['id'] ?>" class="btn-small btn-danger" title="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.');">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

</body>
</html>