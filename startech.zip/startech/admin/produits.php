<?php
// FICHIER : admin/produits.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...
$message = '';
$produit_a_modifier = null;
$action = $_GET['action'] ?? 'read';

// ==============================================
// 1. RÉCUPÉRATION DES DONNÉES POUR LES MENUS DÉROULANTS
// ==============================================
try {
    
    $sql_categories = "SELECT id, nom FROM categories ORDER BY nom ASC";
    $stmt_cat = $pdo->query($sql_categories);
    $categories = $stmt_cat->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les fournisseurs
    $sql_fournisseurs = "SELECT id, nom_societe FROM fournisseurs ORDER BY nom_societe ASC";
    $stmt_four = $pdo->query($sql_fournisseurs);
    $fournisseurs_list = $stmt_four->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des listes : " . $e->getMessage() . "</div>";
    $categories = [];
    $fournisseurs_list = [];
}

// ==============================================
// 2. GESTION DES REQUÊTES POST (AJOUT/MODIFICATION/SUPPRESSION)
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage et validation des données
    $nom = trim($_POST['nom'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $prix_achat_moyen = floatval($_POST['prix_achat_moyen'] ?? 0);
    
    // Suppression des espaces insécables : cette ligne était la source probable de l'erreur
    $prix_vente = floatval($_POST['prix_vente'] ?? 0);
    
    $quantite_stock = intval($_POST['quantite_stock'] ?? 0);
    $seuil_alerte_stock = intval($_POST['seuil_alerte_stock'] ?? 10);
    $unite_mesure = trim($_POST['unite_mesure'] ?? 'piece');
    $categorie_id = intval($_POST['categorie_id'] ?? 0);
    $fournisseur_principal_id = intval($_POST['fournisseur_principal_id'] ?? 0);
    $statut = trim($_POST['statut'] ?? 'actif');
    $produit_id = $_POST['id'] ?? null;

    if (empty($nom) || $prix_vente <= 0 || $categorie_id === 0) {
        $message = "<div class='alert alert-danger'>Le nom, le prix de vente et la catégorie sont obligatoires.</div>";
    } else {
        if (isset($_POST['add'])) {
            // --- C: Création (Ajouter un produit)
            try {
                // Assurez-vous que les noms de colonnes ici correspondent EXACTEMENT à votre BDD
                $sql = "INSERT INTO produits (nom, description, prix_achat_moyen, prix_vente, quantite_stock, seuil_alerte_stock, unite_mesure, categorie_id, fournisseur_principal_id, statut) 
                            VALUES (:nom, :desc, :pa, :pv, :stock, :seuil, :unite, :cat_id, :four_id, :statut)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':nom' => $nom,
                    ':desc' => $description,
                    ':pa' => $prix_achat_moyen,
                    ':pv' => $prix_vente,
                    ':stock' => $quantite_stock,
                    ':seuil' => $seuil_alerte_stock,
                    ':unite' => $unite_mesure,
                    ':cat_id' => $categorie_id,
                    ':four_id' => $fournisseur_principal_id > 0 ? $fournisseur_principal_id : null, // Mettre NULL si 0
                    ':statut' => $statut
                ]);
                $message = "<div class='alert alert-success'>Produit **{$nom}** ajouté avec succès.</div>";
                $action = 'read';
            } catch (PDOException $e) {
                $message = "<div class='alert alert-danger'>Erreur base de données : " . $e->getMessage() . "</div>";
            }
        } elseif (isset($_POST['update']) && $produit_id) {
            // --- U: Mise à jour (Modifier un produit)
            try {
                // Assurez-vous que les noms de colonnes ici correspondent EXACTEMENT à votre BDD
                $sql = "UPDATE produits SET nom = :nom, description = :desc, prix_achat_moyen = :pa, prix_vente = :pv, quantite_stock = :stock, seuil_alerte_stock = :seuil, unite_mesure = :unite, categorie_id = :cat_id, fournisseur_principal_id = :four_id, statut = :statut WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':nom' => $nom,
                    ':desc' => $description,
                    ':pa' => $prix_achat_moyen,
                    ':pv' => $prix_vente,
                    ':stock' => $quantite_stock,
                    ':seuil' => $seuil_alerte_stock,
                    ':unite' => $unite_mesure,
                    ':cat_id' => $categorie_id,
                    ':four_id' => $fournisseur_principal_id > 0 ? $fournisseur_principal_id : null,
                    ':statut' => $statut,
                    ':id' => $produit_id
                ]);
                $message = "<div class='alert alert-success'>Produit **{$nom}** mis à jour avec succès.</div>";
                $action = 'read';
            } catch (PDOException $e) {
                $message = "<div class='alert alert-danger'>Erreur lors de la mise à jour : " . $e->getMessage() . "</div>";
            }
        } elseif (isset($_POST['delete']) && $produit_id) {
            // --- D: Suppression (Supprimer un produit)
            try {
                // La FK ON DELETE RESTRICT dans la DB empêche la suppression si le produit est dans une commande
                $sql = "DELETE FROM produits WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':id' => $produit_id]);
                $message = "<div class='alert alert-warning'>Produit supprimé avec succès.</div>";
                $action = 'read';
            } catch (PDOException $e) {
                if ($e->getCode() == '23000') {
                    $message = "<div class='alert alert-danger'>Impossible de supprimer ce produit : il est lié à des **commandes clients**, des **mouvements de stock** ou une **nomenclature**.</div>";
                } else {
                    $message = "<div class='alert alert-danger'>Erreur lors de la suppression : " . $e->getMessage() . "</div>";
                }
            }
        }
    }
}

// ==============================================
// 3. GESTION DES REQUÊTES GET (PRÉ-REMPLISSAGE ET LECTURE)
// ==============================================

// --- U: Pré-remplissage pour modification
if ($action === 'edit' && isset($_GET['id'])) {
    try {
        $sql = "SELECT * FROM produits WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $_GET['id']]);
        $produit_a_modifier = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$produit_a_modifier) {
            $message = "<div class='alert alert-warning'>Produit non trouvé.</div>";
            $action = 'read';
        }
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Erreur de récupération des données : " . $e->getMessage() . "</div>";
        $action = 'read';
    }
}

// --- R: Lecture (Récupérer tous les produits avec les noms liés)
try {
    // Si la colonne de prix est bien 'prix_vente' dans la table, on peut utiliser SELECT p.*,
    // Sinon, remplacez 'p.prix_vente' par l'alias approprié, par exemple p.prix_ht AS prix_vente, 
    // si la colonne s'appelle 'prix_ht' dans votre base de données.
    $sql_produits = "SELECT p.*, p.prix_ht AS prix_vente, c.nom AS categorie_nom, f.nom_societe AS fournisseur_nom 
                      FROM produits p
                      JOIN categories c ON p.categorie_id = c.id
                      LEFT JOIN fournisseurs f ON p.fournisseur_principal_id = f.id
                      ORDER BY p.nom ASC";
    $stmt_produits = $pdo->query($sql_produits);
    $produits = $stmt_produits->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement de la liste des produits : " . $e->getMessage() . "</div>";
    $produits = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Produits et Stocks</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>📦 Gestion des Produits & Stocks</h1>
        
        <div style="text-align: right; margin-bottom: 20px;">
            <a href="categories.php" class="btn btn-info">🏷️ Gérer les Catégories</a>
        </div>
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="card mb-4">
            <h2><?php echo ($action === 'edit' ? 'Modifier le Produit' : 'Ajouter un Nouveau Produit'); ?></h2>
            <form action="produits.php" method="POST">
                
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($produit_a_modifier['id']) ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="nom">Nom du Produit <span class="required">*</span> :</label>
                    <input type="text" id="nom" name="nom" required 
                                value="<?= htmlspecialchars($produit_a_modifier['nom'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="description">Description :</label>
                    <textarea id="description" name="description"><?= htmlspecialchars($produit_a_modifier['description'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="categorie_id">Catégorie <span class="required">*</span> :</label>
                    <select id="categorie_id" name="categorie_id" required>
                        <option value="">-- Sélectionner --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" 
                                <?= (isset($produit_a_modifier['categorie_id']) && $produit_a_modifier['categorie_id'] == $cat['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['nom']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($categories)): ?><p class="required">⚠ Aucune catégorie trouvée. Veuillez en ajouter une d'abord.</p><?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="fournisseur_principal_id">Fournisseur Principal :</label>
                    <select id="fournisseur_principal_id" name="fournisseur_principal_id">
                        <option value="0">-- Aucun / Non applicable --</option>
                        <?php foreach ($fournisseurs_list as $four): ?>
                            <option value="<?= $four['id'] ?>" 
                                <?= (isset($produit_a_modifier['fournisseur_principal_id']) && $produit_a_modifier['fournisseur_principal_id'] == $four['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($four['nom_societe']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group row-group">
                    <div>
                        <label for="prix_achat_moyen">Prix Achat Moyen (€) :</label>
                        <input type="number" step="0.01" id="prix_achat_moyen" name="prix_achat_moyen" value="<?= htmlspecialchars($produit_a_modifier['prix_achat_moyen'] ?? 0.00) ?>">
                    </div>
                    <div>
                        <label for="prix_vente">Prix Vente (€) <span class="required">*</span> :</label>
                        <input type="number" step="0.01" id="prix_vente" name="prix_vente" required value="<?= htmlspecialchars($produit_a_modifier['prix_vente'] ?? 0.00) ?>">
                    </div>
                </div>

                <div class="form-group row-group">
                    <div>
                        <label for="quantite_stock">Quantité en Stock :</label>
                        <input type="number" id="quantite_stock" name="quantite_stock" value="<?= htmlspecialchars($produit_a_modifier['quantite_stock'] ?? 0) ?>">
                    </div>
                    <div>
                        <label for="seuil_alerte_stock">Seuil Alerte Stock :</label>
                        <input type="number" id="seuil_alerte_stock" name="seuil_alerte_stock" value="<?= htmlspecialchars($produit_a_modifier['seuil_alerte_stock'] ?? 10) ?>">
                    </div>
                </div>
                
                <div class="form-group row-group">
                    <div>
                        <label for="unite_mesure">Unité de Mesure :</label>
                        <input type="text" id="unite_mesure" name="unite_mesure" value="<?= htmlspecialchars($produit_a_modifier['unite_mesure'] ?? 'piece') ?>">
                    </div>
                    <div>
                        <label for="statut">Statut :</label>
                        <select id="statut" name="statut">
                            <?php 
                                $statuts = ['actif', 'inactif', 'archive', 'a_produire'];
                                $current_statut = $produit_a_modifier['statut'] ?? 'actif';
                            ?>
                            <?php foreach ($statuts as $s): ?>
                                <option value="<?= $s ?>" <?= ($current_statut == $s) ? 'selected' : '' ?>>
                                    <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>


                <?php if ($action === 'edit'): ?>
                    <button type="submit" name="update" class="btn btn-primary">💾 Enregistrer les Modifications</button>
                    <a href="produits.php" class="btn btn-secondary">Annuler</a>
                <?php else: ?>
                    <button type="submit" name="add" class="btn btn-success">➕ Ajouter le Produit</button>
                <?php endif; ?>
            </form>
        </div>
        
        <h2>Liste des Produits (<?= count($produits) ?>)</h2>
        
        <?php if (!empty($produits)): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Catégorie</th>
                        <th>Fournisseur</th>
                        <th>Prix Achat</th>
                        <th>Prix Vente</th>
                        <th>Stock</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($produits as $p): ?>
                    <tr class="<?= ($p['quantite_stock'] <= $p['seuil_alerte_stock']) ? 'stock-alert' : '' ?>">
                        <td><?= htmlspecialchars($p['id']) ?></td>
                        <td><?= htmlspecialchars($p['nom']) ?></td>
                        <td><?= htmlspecialchars($p['categorie_nom']) ?></td>
                        <td><?= htmlspecialchars($p['fournisseur_nom'] ?? '-') ?></td>
                        <td><?= number_format($p['prix_achat_moyen'], 2) ?> €</td>
                        <td><?= number_format(floatval($p['prix_vente'] ?? 0), 2) ?> €</td>
                        <td class="text-center <?= ($p['quantite_stock'] == 0) ? 'text-danger' : (($p['quantite_stock'] <= $p['seuil_alerte_stock']) ? 'text-warning' : '') ?>">
                            **<?= htmlspecialchars($p['quantite_stock']) ?>**
                        </td>
                        <td><?= ucfirst($p['statut']) ?></td>
                        <td>
                            <a href="produits.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-edit btn-small">Modifier</a>
                            <form method="POST" action="produits.php" style="display:inline-block;" onsubmit="return confirm('ATTENTION : Supprimer un produit peut casser l\'historique des commandes. Confirmez ?');">
                                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                <button type="submit" name="delete" class="btn btn-danger btn-small">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Aucun produit n'a été enregistré pour le moment. Vous devez ajouter au moins une catégorie d'abord.</p>
        <?php endif; ?>

    </div>
</body>
</html>