<?php
// startech/admin/categories.php
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_admin();

$message = '';
$categorie_a_modifier = null;

// --- GESTION DES POST --- (Ajout/Modification/Suppression)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $nom = htmlspecialchars(trim($_POST['nom'] ?? ''));
    $id = intval($_POST['id'] ?? 0);

    try {
        if ($action === 'ajouter') {
            if (empty($nom)) throw new Exception("Le nom de la catégorie est obligatoire.");
            $sql = "INSERT INTO categories (nom) VALUES (?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nom]);
            $message = "<div class='alert alert-success'>Catégorie **{$nom}** ajoutée.</div>";
        } elseif ($action === 'modifier') {
            if ($id <= 0 || empty($nom)) throw new Exception("ID ou nom de catégorie manquant.");
            $sql = "UPDATE categories SET nom = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nom, $id]);
            $message = "<div class='alert alert-success'>Catégorie mise à jour.</div>";
        } elseif ($action === 'supprimer') {
            if ($id <= 0) throw new Exception("ID de catégorie manquant pour la suppression.");
            $sql = "DELETE FROM categories WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id]);
            $message = "<div class='alert alert-warning'>Catégorie supprimée.</div>";
        }
    } catch (PDOException $e) {
        if ($e->getCode() == '23000') {
             $message = "<div class='alert alert-danger'>Impossible de supprimer : cette catégorie est utilisée par des **produits** existants.</div>";
        } else {
             $message = "<div class='alert alert-danger'>Erreur BD : " . $e->getMessage() . "</div>";
        }
    } catch (Exception $e) {
        $message = "<div class='alert alert-danger'>Erreur : " . $e->getMessage() . "</div>";
    }
}

// --- GESTION DU MODE MODIFICATION (GET) ---
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
        $sql = "SELECT * FROM categories WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $categorie_a_modifier = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// --- LECTURE : Récupérer toutes les catégories
$categories = [];
try {
    $sql_categories = "SELECT id, nom FROM categories ORDER BY nom ASC";
    $stmt_cat = $pdo->query($sql_categories);
    $categories = $stmt_cat->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Gestion des erreurs
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Catégories</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>🏷️ Gestion des Catégories de Produits</h1>
        
        <?php echo $message; ?>

        <div class="card mb-4" style="max-width: 600px; margin: 0 auto 30px;">
            <h2><?= $categorie_a_modifier ? 'Modifier la Catégorie #' . $categorie_a_modifier['id'] : 'Ajouter une Nouvelle Catégorie' ?></h2>
            <form action="categories.php" method="POST">
                <input type="hidden" name="action" value="<?= $categorie_a_modifier ? 'modifier' : 'ajouter' ?>">
                <?php if ($categorie_a_modifier): ?>
                    <input type="hidden" name="id" value="<?= $categorie_a_modifier['id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="nom">Nom de la Catégorie <span class="required">*</span> :</label>
                    <input type="text" id="nom" name="nom" required 
                           value="<?= htmlspecialchars($categorie_a_modifier['nom'] ?? '') ?>">
                </div>

                <button type="submit" class="btn btn-success">
                    <?= $categorie_a_modifier ? '💾 Enregistrer' : '➕ Ajouter' ?>
                </button>
                <?php if ($categorie_a_modifier): ?>
                    <a href="categories.php" class="btn btn-secondary">Annuler</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="card">
            <h2>Liste des Catégories (<?= count($categories) ?>)</h2>
            <?php if (!empty($categories)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td><?= htmlspecialchars($cat['id']) ?></td>
                            <td>**<?= htmlspecialchars($cat['nom']) ?>**</td>
                            <td>
                                <a href="categories.php?action=edit&id=<?= $cat['id'] ?>" class="btn btn-edit btn-small">Modifier</a>
                                <form method="POST" action="categories.php" style="display:inline;" onsubmit="return confirm('Supprimer cette catégorie ? Les produits liés devront être mis à jour.');">
                                    <input type="hidden" name="action" value="supprimer">
                                    <input type="hidden" name="id" value="<?= $cat['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucune catégorie n'est définie. Veuillez en ajouter une ci-dessus.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>