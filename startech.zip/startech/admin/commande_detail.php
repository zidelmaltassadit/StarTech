<?php
// admin/commande_detail.php
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Exige l'accès administrateur
require_admin();

$message = '';
$commande = null;
$details = [];
$commande_id = intval($_GET['id'] ?? 0);

if ($commande_id <= 0) {
    // Rediriger si l'ID est manquant
    header('Location: commandes.php');
    exit;
}

try {
    // 1. Récupérer l'en-tête de la commande et les infos client
    $sql_commande = "
        SELECT 
            c.*, 
            cl.nom AS client_nom, cl.prenom AS client_prenom, cl.entreprise, 
            cl.email, cl.telephone, cl.adresse, cl.code_postal, cl.ville, cl.pays
        FROM 
            commandes c
        JOIN 
            clients cl ON c.client_id = cl.id
        WHERE c.id = ?
    ";
    $stmt_commande = $pdo->prepare($sql_commande);
    $stmt_commande->execute([$commande_id]);
    $commande = $stmt_commande->fetch(PDO::FETCH_ASSOC);

    if (!$commande) {
        throw new Exception("Commande #{$commande_id} non trouvée.");
    }

    // 2. Récupérer les détails des lignes de commande
    $sql_details = "
        SELECT 
            cd.*,
            p.nom AS produit_nom, 
            p.reference AS produit_reference
        FROM 
            commande_details cd
        LEFT JOIN 
            produits p ON cd.produit_id = p.id
        WHERE cd.commande_id = ?
        ORDER BY cd.id ASC
    ";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([$commande_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $message = "<div class='alert alert-danger'>Erreur de chargement de la commande : " . $e->getMessage() . "</div>";
    $commande = null;
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détail Commande #<?= $commande_id ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .detail-row span:first-child { font-weight: bold; width: 150px; display: inline-block; }
        .address-box { border: 1px solid #ddd; padding: 15px; border-radius: 5px; background-color: #f9f9f9; }
        .total-box { background-color: #e9ecef; padding: 15px; border-radius: 5px; text-align: right; }
        .total-box h4 { margin-bottom: 5px; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h1>📄 Détail de la Commande #<?= $commande_id ?></h1>
            <a href="commandes.php" class="btn btn-secondary">← Retour aux commandes</a>
        </div>
        
        <?php echo $message; ?>

        <?php if ($commande): ?>
        
            <div class="card mb-4 detail-grid">
                
                <div class="card-body">
                    <h2>Informations Générales</h2>
                    <div class="detail-row"><span class="label">Date de Commande :</span> <?= date('d/m/Y H:i', strtotime($commande['date_commande'])) ?></div>
                    <div class="detail-row"><span class="label">Statut Actuel :</span> <span class="status-badge status-<?= $commande['statut'] ?>"><?= ucfirst(str_replace('_', ' ', $commande['statut'])) ?></span></div>
                    <div class="detail-row"><span class="label">Statut Facturation :</span> <span class="status-badge status-<?= strtolower($commande['statut_facturation']) ?>"><?= ucfirst(str_replace('_', ' ', $commande['statut_facturation'])) ?></span></div>
                    <div class="detail-row"><span class="label">Date Livraison Prévue :</span> <?= !empty($commande['date_livraison']) ? date('d/m/Y', strtotime($commande['date_livraison'])) : 'N/A' ?></div>
                </div>

                <div class="card-body">
                    <h2>Informations Client</h2>
                    <div class="detail-row"><span class="label">Nom :</span> **<?= htmlspecialchars($commande['client_nom'] . ' ' . $commande['client_prenom']) ?>**</div>
                    <div class="detail-row"><span class="label">Entreprise :</span> <?= htmlspecialchars($commande['entreprise'] ?? '-') ?></div>
                    <div class="detail-row"><span class="label">Email :</span> <a href="mailto:<?= htmlspecialchars($commande['email']) ?>"><?= htmlspecialchars($commande['email']) ?></a></div>
                    <div class="detail-row"><span class="label">Téléphone :</span> <?= htmlspecialchars($commande['telephone'] ?? '-') ?></div>
                    
                    <h4 style="margin-top: 15px;">Adresse de Facturation/Livraison</h4>
                    <div class="address-box">
                        <?= nl2br(htmlspecialchars($commande['adresse'])) ?><br>
                        <?= htmlspecialchars($commande['code_postal']) ?> <?= htmlspecialchars($commande['ville']) ?><br>
                        <?= htmlspecialchars($commande['pays']) ?>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <h2>Lignes de Produits</h2>
                <?php if (!empty($details)): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Réf.</th>
                                <th>Nom Produit</th>
                                <th>Quantité</th>
                                <th>Prix U. HT</th>
                                <th>Total Ligne HT</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($details as $d): ?>
                            <tr>
                                <td><?= htmlspecialchars($d['produit_reference'] ?? 'N/A') ?></td>
                                <td>**<?= htmlspecialchars($d['produit_nom'] ?? 'Produit Supprimé') ?>**</td>
                                <td><?= htmlspecialchars($d['quantite']) ?></td>
                                <td class="text-right"><?= number_format($d['prix_unitaire_ht'], 2, ',', ' ') ?> €</td>
                                <td class="text-right"><?= number_format($d['total_ligne_ht'], 2, ',', ' ') ?> €</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-right">**TOTAL HT** :</td>
                                <td class="text-right">**<?= number_format($commande['total_ht'], 2, ',', ' ') ?> €**</td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right">TVA (20%) :</td>
                                <td class="text-right"><?= number_format($commande['total_ttc'] - $commande['total_ht'], 2, ',', ' ') ?> €</td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right">**TOTAL TTC** :</td>
                                <td class="text-right">**<?= number_format($commande['total_ttc'], 2, ',', ' ') ?> €**</td>
                            </tr>
                        </tfoot>
                    </table>
                <?php else: ?>
                    <p class="alert alert-warning">Aucune ligne de produit pour cette commande.</p>
                <?php endif; ?>
            </div>

            <div class="card mb-4" style="text-align: center;">
                <a href="commandes_vente.php?action=edit&id=<?= $commande_id ?>" class="btn btn-primary btn-large">Modifier la commande (Saisie)</a>
                <a href="facture_generation.php?commande_id=<?= $commande_id ?>" class="btn btn-info btn-large">Générer la Facture</a>
            </div>

        <?php else: ?>
            <p class="alert alert-danger">Impossible d'afficher les détails de la commande.</p>
        <?php endif; ?>

    </div>
</body>
</html>