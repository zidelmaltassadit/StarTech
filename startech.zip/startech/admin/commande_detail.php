<?php
// admin/commande_detail.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_once '../includes/functions.php';

// 1. SÉCURITÉ (Admin uniquement)
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
$allowed_roles = ['admin', 'administrateur', 'logistique', 'commercial', 'comptabilite'];
if (!in_array(strtolower($_SESSION['user_role']), $allowed_roles)) {
    die("Accès refusé.");
}

$commande_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($commande_id === 0) { die("ID de commande invalide."); }

$message = '';

// --- TRAITEMENT DU FORMULAIRE DE MISE À JOUR DU STATUT ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nouveau_statut'])) {
    $nouveau_statut = $_POST['nouveau_statut'];
    try {
        $stmt = $pdo->prepare("UPDATE commandes SET statut = ? WHERE id = ?");
        $stmt->execute([$nouveau_statut, $commande_id]);
        $message = "<div class='alert alert-success' style='margin-bottom:20px; color:green; background:#E8FDF2; padding:15px; border-radius:12px;'>Statut de la commande mis à jour avec succès : <strong>" . ucfirst($nouveau_statut) . "</strong></div>";
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Erreur lors de la mise à jour : " . $e->getMessage() . "</div>";
    }
}

// --- RÉCUPÉRATION DES DONNÉES (Requête SQL Corrigée) ---
try {
    // A. Infos Commande & Client (On ne cherche plus cl.pays)
    $sql_cmd = "SELECT c.*, cl.nom as client_nom, cl.email as client_email
                FROM commandes c
                LEFT JOIN clients cl ON c.client_id = cl.id
                WHERE c.id = ?";
    $stmt = $pdo->prepare($sql_cmd);
    $stmt->execute([$commande_id]);
    $commande = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$commande) { die("Commande introuvable."); }

    // B. Détails (Produits)
    $sql_details = "SELECT dc.*, p.nom as prod_nom, p.image as prod_image
                    FROM details_commande dc
                    LEFT JOIN produits p ON dc.produit_id = p.id
                    WHERE dc.commande_id = ?";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([$commande_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}

// Liste des statuts possibles pour le menu déroulant
$statuts_possibles = [
    'en_attente' => 'En attente',
    'en_preparation' => 'En préparation',
    'expediee' => 'Expédiée',
    'livree' => 'Livrée',
    'annulee' => 'Annulée'
];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Commande #<?= $commande_id ?> - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Style spécifique pour cette page */
        .detail-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
        .info-group h3 { font-size: 1.1rem; font-weight: 600; margin-bottom: 15px; color: var(--text-primary); }
        .info-group p { margin-bottom: 10px; line-height: 1.5; color: var(--text-secondary); }
        .info-group strong { color: var(--text-primary); }
        .product-item { display: flex; align-items: center; gap: 20px; padding: 15px 0; border-bottom: 1px solid var(--border-color); }
        .product-img { width: 60px; height: 60px; object-fit: contain; border-radius: 10px; background: #F5F5F7; padding: 5px; }
        .action-card { position: sticky; top: 30px; }
        .form-select { width: 100%; padding: 12px; border-radius: 12px; border: 1px solid #d2d2d7; margin-bottom: 15px; font-size: 1rem; }
    </style>
</head>
<body class="admin-body">
    
    <div class="main-content" style="padding-top: 40px;">
        
        <a href="dashboard.php" style="display:inline-flex; align-items:center; gap:10px; margin-bottom:30px; font-weight:600;">
            <i class="fa-solid fa-arrow-left"></i> Retour au tableau de bord
        </a>

        <header class="top-bar">
            <h1>Commande #<?= str_pad($commande['id'], 6, '0', STR_PAD_LEFT) ?></h1>
            <span class="status-badge status-<?= strtolower($commande['statut']) ?>" style="font-size: 1rem; padding: 8px 20px;">
                <?= ucfirst($commande['statut']) ?>
            </span>
        </header>

        <?= $message ?>

        <div class="detail-layout">
            
            <div class="left-col">
                
                <div class="card">
                    <div class="section-header"><h2><i class="fa-solid fa-circle-info"></i> Informations</h2></div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                        <div class="info-group">
                            <h3>Client</h3>
                            <p><strong><?= htmlspecialchars($commande['client_nom'] ?? 'Client supprimé') ?></strong></p>
                            <p><a href="mailto:<?= htmlspecialchars($commande['client_email']) ?>"><?= htmlspecialchars($commande['client_email']) ?></a></p>
                        </div>
                        <div class="info-group">
                            <h3>Commande</h3>
                            <p>Date : <strong><?= (new DateTime($commande['date_commande']))->format('d/m/Y à H:i') ?></strong></p>
                            <p>Paiement : <strong><?= htmlspecialchars($commande['moyen_paiement']) ?></strong></p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="section-header"><h2><i class="fa-solid fa-truck"></i> Livraison & Facturation</h2></div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                        <div class="info-group">
                            <h3>Adresse de Livraison</h3>
                            <p><?= nl2br(htmlspecialchars($commande['adresse_livraison'])) ?></p>
                        </div>
                        <div class="info-group" style="border-left: 1px solid var(--border-color); padding-left: 30px;">
                            <h3>Adresse de Facturation</h3>
                            <p><?= nl2br(htmlspecialchars($commande['adresse_facturation'])) ?></p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="section-header"><h2><i class="fa-solid fa-bag-shopping"></i> Produits Commandés</h2></div>
                    
                    <?php foreach($details as $item): ?>
                        <?php 
                            $img_src = !empty($item['prod_image']) ? (strpos($item['prod_image'], 'http') === 0 ? $item['prod_image'] : "/startech/assets/images/produits/" . $item['prod_image']) : 'https://dummyimage.com/60x60/eee/aaa';
                        ?>
                        <div class="product-item">
                            <img src="<?= htmlspecialchars($img_src) ?>" class="product-img">
                            <div style="flex-grow: 1;">
                                <div style="font-weight: 600; font-size: 1.1rem;"><?= htmlspecialchars($item['prod_nom']) ?></div>
                                <?php if(!empty($item['options'])): ?>
                                    <small style="color: var(--text-secondary);">
                                        <?php 
                                            $opts = json_decode($item['options'], true);
                                            if(is_array($opts)) { foreach($opts as $k => $v) echo ucfirst($k).': '.ucfirst($v).' | '; }
                                        ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                            <div style="text-align: right;">
                                <div><?= $item['quantite'] ?> x <strong><?= number_format($item['prix_unitaire_ht'] * 1.20, 2, ',', ' ') ?> €</strong></div>
                                <div style="font-weight: 700; color: var(--accent-blue);"><?= number_format($item['prix_total_ttc'], 2, ',', ' ') ?> €</div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <div style="margin-top: 30px; text-align: right;">
                        <p>Total HT : <?= number_format($commande['total_ht'], 2, ',', ' ') ?> €</p>
                        <p>TVA (20%) : <?= number_format($commande['total_tva'], 2, ',', ' ') ?> €</p>
                        <h3 style="font-size: 1.8rem; color: var(--accent-blue); margin-top: 15px;">Total TTC : <?= number_format($commande['montant_total'], 2, ',', ' ') ?> €</h3>
                    </div>
                </div>

            </div>

            <div class="right-col">
                <div class="card action-card" style="background: #E8F2FF; border: 1px solid #D0E1F9;">
                    <div class="section-header">
                        <h2 style="color: var(--accent-blue);"><i class="fa-solid fa-gear"></i> Gestion</h2>
                    </div>
                    
                    <form method="post">
                        <label for="nouveau_statut" style="display:block; font-weight:600; margin-bottom:10px;">Changer le statut :</label>
                        <select name="nouveau_statut" id="nouveau_statut" class="form-select">
                            <?php foreach($statuts_possibles as $key => $label): ?>
                                <option value="<?= $key ?>" <?= $commande['statut'] == $key ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;">
                            Mettre à jour la commande
                        </button>
                    </form>

                    <hr style="margin: 25px 0; border-color: rgba(0,113,227,0.2);">
                    
                    <a href="../public/facture_pdf.php?id=<?= $commande_id ?>" target="_blank" class="btn btn-outline" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-file-pdf"></i> Voir la Facture PDF
                    </a>
                </div>
            </div>

        </div>
    </div>

</body>
</html>