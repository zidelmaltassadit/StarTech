<aside class="sidebar">
    <div class="sidebar-header">
        <span class="logo-text">StarTech | PGI</span>
    </div>
    
    <nav class="sidebar-nav">
        <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-chart-line"></i> Tableau de bord
        </a>
        
        <div class="nav-divider">GESTION COMMERCIALE</div>
        
        <a href="commandes.php" class="<?= basename($_SERVER['PHP_SELF']) == 'commandes.php' || basename($_SERVER['PHP_SELF']) == 'commande_detail.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-box-archive"></i> Commandes
        </a>
        <a href="produits.php" class="<?= basename($_SERVER['PHP_SELF']) == 'produits.php' || basename($_SERVER['PHP_SELF']) == 'produit_form.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-tag"></i> Produits & Stock
        </a>
        <a href="clients.php" class="<?= basename($_SERVER['PHP_SELF']) == 'clients.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-users"></i> Clients
        </a>
        
        <div class="nav-divider">RELATIONS PARTENAIRES</div>
        
        <a href="fournisseurs.php" class="<?= basename($_SERVER['PHP_SELF']) == 'fournisseurs.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-truck"></i> Fournisseurs
        </a>
        <a href="achats.php" class="<?= basename($_SERVER['PHP_SELF']) == 'achats.php' || basename($_SERVER['PHP_SELF']) == 'achat_form.php' || basename($_SERVER['PHP_SELF']) == 'achat_detail.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-cart-flatbed"></i> Commandes d'Achat
        </a>
    </nav>

    <div class="user-profile-bottom">
        <div class="user-info">
            <p class="name"><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?></p>
            <p class="role badge-role"><?= ucfirst($_SESSION['user_role'] ?? 'Personnel') ?></p>
        </div>
        <a href="../public/logout.php" class="logout-btn-icon" title="Déconnexion">
            <i class="fa-solid fa-arrow-right-from-bracket"></i>
        </a>
    </div>
</aside>