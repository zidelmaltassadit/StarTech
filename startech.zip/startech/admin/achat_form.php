<?php
// admin/achat_form.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
if (!in_array(strtolower($_SESSION['user_role']), ['admin', 'administrateur', 'logistique', 'achats'])) { die("Accès refusé."); }

// Variables initiales
$etape = 1;
$fournisseur_id = null;
$fournisseur_nom = '';
$produits_fournisseur = [];
$errors = [];
$titre_page = "Nouvelle Commande Achat";
// --- NOUVEAU : GESTION DE LA PRÉ-SÉLECTION VIA URL (VENANT DES ALERTES STOCK) ---
if (isset($_GET['preselect']) && is_numeric($_GET['preselect'])) {
    // Si un ID est passé dans l'URL, on le prend et on saute directement à l'étape 2
    $fournisseur_id = (int)$_GET['preselect'];
    $etape = 2;
}

// --- TRAITEMENT DU FORMULAIRE (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // -> CAS 1 : On vient de choisir le fournisseur (étape 1 -> étape 2)
    if (isset($_POST['step1_submit'])) {
        if (!empty($_POST['fournisseur_id'])) {
            $fournisseur_id = $_POST['fournisseur_id'];
            $etape = 2; // On passe à l'étape suivante
        } else {
            $errors[] = "Veuillez sélectionner un fournisseur.";
        }
    }

    // -> CAS 2 : On valide la commande finale (étape 2 -> enregistrement)
    elseif (isset($_POST['step2_submit'])) {
        // On récupère l'ID fournisseur et les tableaux de produits/quantités/prix
        $fournisseur_id = $_POST['fournisseur_id_final'];
        $produits_post = $_POST['produit_id'] ?? [];
        $qtes_post = $_POST['quantite'] ?? [];
        $prix_post = $_POST['prix_achat'] ?? [];
        $date_prevue = !empty($_POST['date_reception_prevue']) ? $_POST['date_reception_prevue'] : null;

        // Validation basique : au moins une ligne de produit
        $lignes_valides = [];
        $total_ht = 0;
        for ($i = 0; $i < count($produits_post); $i++) {
            if (!empty($produits_post[$i]) && $qtes_post[$i] > 0) {
                $lignes_valides[] = [
                    'prod_id' => $produits_post[$i],
                    'qte' => $qtes_post[$i],
                    'prix' => $prix_post[$i]
                ];
                $total_ht += $qtes_post[$i] * $prix_post[$i];
            }
        }

        if (empty($lignes_valides)) {
            $errors[] = "Veuillez ajouter au moins un produit avec une quantité valide.";
            $etape = 2; // On reste à l'étape 2 pour corriger
        } else {
            // TOUT EST BON -> INSERTION EN BASE DE DONNÉES
            try {
                $pdo->beginTransaction();

                // A. Insérer la commande d'achat (en-tête)
                $sql_cmd = "INSERT INTO commandes_achat (fournisseur_id, date_reception_prevue, statut, montant_total) 
                            VALUES (?, ?, 'commandee', ?)";
                $stmt_cmd = $pdo->prepare($sql_cmd);
                $stmt_cmd->execute([$fournisseur_id, $date_prevue, $total_ht]);
                $commande_id = $pdo->lastInsertId();

                // B. Insérer les lignes de détails
                $sql_detail = "INSERT INTO details_commande_achat (commande_achat_id, produit_id, quantite_commandee, prix_achat_unitaire) 
                               VALUES (?, ?, ?, ?)";
                $stmt_detail = $pdo->prepare($sql_detail);
                foreach ($lignes_valides as $ligne) {
                    $stmt_detail->execute([$commande_id, $ligne['prod_id'], $ligne['qte'], $ligne['prix']]);
                }

                $pdo->commit();
                // Redirection vers la liste avec message de succès
                header("Location: achats.php?msg=success_created");
                exit;

            } catch (PDOException $e) {
                $pdo->rollBack();
                $errors[] = "Erreur SQL : " . $e->getMessage();
                $etape = 2;
            }
        }
    }
}

// --- PRÉPARATION DES DONNÉES POUR L'AFFICHAGE ---
// Si on est à l'étape 1, on charge la liste des fournisseurs
if ($etape === 1) {
    $fournisseurs = $pdo->query("SELECT id, nom FROM utilisateurs WHERE user_role = 'fournisseur' ORDER BY nom ASC")->fetchAll(PDO::FETCH_KEY_PAIR);
}
// Si on est à l'étape 2, on charge le nom du fournisseur et ses produits
elseif ($etape === 2 && $fournisseur_id) {
    // Nom du fournisseur
    $stmt_f = $pdo->prepare("SELECT nom FROM utilisateurs WHERE id = ?");
    $stmt_f->execute([$fournisseur_id]);
    $fournisseur_nom = $stmt_f->fetchColumn();
    $titre_page = "Commande pour : " . $fournisseur_nom;

    // Produits de ce fournisseur uniquement
    $stmt_p = $pdo->prepare("SELECT id, nom, prix_achat FROM produits WHERE fournisseur_id = ? ORDER BY nom ASC");
    $stmt_p->execute([$fournisseur_id]);
    $produits_fournisseur = $stmt_p->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $titre_page ?> - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-weight: 600; margin-bottom: 8px; }
        .form-select, .form-input { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 12px; }
        /* Style du tableau des lignes de produits */
        .lines-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; }
        .lines-table th { text-align: left; padding: 10px; color: var(--text-secondary); font-size: 0.85rem; }
        .lines-table td { background: #F5F5F7; padding: 10px; vertical-align: top; }
        .lines-table tr:first-child td:first-child { border-top-left-radius: 12px; border-bottom-left-radius: 12px; }
        .lines-table tr:first-child td:last-child { border-top-right-radius: 12px; border-bottom-right-radius: 12px; }
        .small-input { padding: 8px; border-radius: 8px; font-size: 0.9rem; }
        .btn-delete-line { color: var(--accent-red); cursor: pointer; padding: 5px; font-size: 1.1rem; }
    </style>
</head>
<body class="admin-body">
    
    <div class="main-content" style="padding-top: 40px;">
        <a href="achats.php" style="display:inline-flex; align-items:center; gap:10px; margin-bottom:30px; font-weight:600;">
            <i class="fa-solid fa-arrow-left"></i> Retour à la liste
        </a>
        <header class="top-bar"><h1><?= $titre_page ?></h1></header>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" style="background:#FFF2F2; color:var(--accent-red); padding:20px; border-radius:15px; margin-bottom:30px;">
                <ul style="margin:0; padding-left:20px;">
                    <?php foreach($errors as $error): ?><li><?= htmlspecialchars($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post">

            <?php if ($etape === 1): ?>
                <div class="card" style="max-width: 600px;">
                    <div class="section-header"><h2>1. Sélectionner le fournisseur</h2></div>
                    
                    <?php if (empty($fournisseurs)): ?>
                        <p class="alert alert-warning">Aucun fournisseur n'a été créé. Veuillez d'abord en créer un dans la section "Fournisseurs".</p>
                    <?php else: ?>
                        <div class="form-group">
                            <label class="form-label">Fournisseur <span style="color:var(--accent-red)">*</span></label>
                            <select name="fournisseur_id" class="form-select" required>
                                <option value="">-- Choisir un fournisseur --</option>
                                <?php foreach($fournisseurs as $id => $nom): ?>
                                    <option value="<?= $id ?>"><?= htmlspecialchars($nom) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="step1_submit" class="btn btn-primary" style="width:100%; padding:15px;">
                            Continuer <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>


            <?php if ($etape === 2): ?>
                <input type="hidden" name="fournisseur_id_final" value="<?= $fournisseur_id ?>">
                
                <div class="admin-layout grid-layout" style="grid-template-columns: 2fr 1fr; gap:30px; padding:0; height:auto; background:transparent;">
                    
                    <div class="card">
                        <div class="section-header">
                            <h2>2. Produits à commander</h2>
                            <button type="button" class="btn btn-small btn-outline" onclick="ajouterLigne()">
                                <i class="fa-solid fa-plus"></i> Ajouter une ligne
                            </button>
                        </div>

                        <?php if (empty($produits_fournisseur)): ?>
                            <p class="alert alert-warning">Ce fournisseur n'a aucun produit associé dans le catalogue. Veuillez d'abord associer des produits à ce fournisseur.</p>
                        <?php else: ?>
                            <table class="lines-table" id="lignes-container">
                                <thead>
                                    <tr>
                                        <th style="width:40%;">Produit</th>
                                        <th style="width:20%;">Quantité</th>
                                        <th style="width:25%;">Prix Achat HT (€)</th>
                                        <th style="width:5%;"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="ligne-produit">
                                        <td>
                                            <select name="produit_id[]" class="form-select small-input" required onchange="majPrix(this)">
                                                <option value="">-- Choisir --</option>
                                                <?php foreach($produits_fournisseur as $p): ?>
                                                    <option value="<?= $p['id'] ?>" data-prix="<?= $p['prix_achat'] ?>"><?= htmlspecialchars($p['nom']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="number" name="quantite[]" class="form-input small-input" required min="1" value="1">
                                        </td>
                                        <td>
                                            <input type="number" name="prix_achat[]" class="form-input small-input prix-input" required step="0.01" placeholder="Prix auto...">
                                        </td>
                                        <td></td> </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                    <div class="card" style="position:sticky; top:30px;">
                        <div class="section-header"><h2>Validation</h2></div>
                        
                        <div class="form-group">
                            <label class="form-label">Date de réception prévue (Optionnel)</label>
                            <input type="date" name="date_reception_prevue" class="form-input">
                        </div>
                        
                        <hr style="margin: 20px 0; border-color: var(--border-color);">
                        
                        <button type="submit" name="step2_submit" class="btn btn-primary" style="width:100%; padding:15px; font-size:1.1rem;" <?= empty($produits_fournisseur) ? 'disabled' : '' ?>>
                            <i class="fa-solid fa-check"></i> Passer la commande d'achat
                        </button>
                    </div>
                </div>
            <?php endif; ?>

        </form>
    </div>

    <script>
        <?php if ($etape === 2 && !empty($produits_fournisseur)): ?>
        function ajouterLigne() {
            const container = document.querySelector('#lignes-container tbody');
            const nouvelleLigne = container.firstElementChild.cloneNode(true);
            
            // Reset des valeurs
            nouvelleLigne.querySelector('select').value = '';
            nouvelleLigne.querySelector('input[type="number"][name="quantite[]"]').value = '1';
            nouvelleLigne.querySelector('.prix-input').value = '';
            
            // Ajout du bouton supprimer
            nouvelleLigne.lastElementChild.innerHTML = '<i class="fa-solid fa-trash-can btn-delete-line" onclick="supprimerLigne(this)"></i>';
            
            container.appendChild(nouvelleLigne);
        }

        function supprimerLigne(btn) {
            btn.closest('tr').remove();
        }

        // Met à jour le champ prix d'achat automatiquement quand on choisit un produit
        function majPrix(selectElement) {
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const prix = selectedOption.getAttribute('data-prix');
            // On trouve le champ input de prix sur la MÊME ligne (tr)
            const prixInput = selectElement.closest('tr').querySelector('.prix-input');
            prixInput.value = prix ? prix : '';
        }
        <?php endif; ?>
    </script>

</body>
</html>