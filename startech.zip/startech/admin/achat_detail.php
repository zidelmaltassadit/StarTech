<?php
// Inclure les fichiers de configuration
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Exige l'accès administrateur
require_admin();

$message = '';
$commande_achat_id = intval($_GET['id'] ?? 0);

if ($commande_achat_id === 0) {
    header('Location: achats.php');
    exit;
}

// ==============================================
// 1. RÉCUPÉRATION DES DONNÉES DE BASE (Commande, Fournisseur, Produits listés)
// ==============================================
try {
    // 1.1 Récupérer les détails de la commande d'achat
    $sql_commande = "SELECT ca.*, f.nom_societe AS fournisseur_nom 
                     FROM commandes_achat ca
                     JOIN fournisseurs f ON ca.fournisseur_id = f.id
                     WHERE ca.id = :id";
    $stmt_commande = $pdo->prepare($sql_commande);
    $stmt_commande->execute([':id' => $commande_achat_id]);
    $commande_achat = $stmt_commande->fetch(PDO::FETCH_ASSOC);

    if (!$commande_achat) {
        $message = "<div class='alert alert-danger'>Commande d'achat non trouvée.</div>";
        // Si non trouvée, on redirige vers la liste
        header('Location: achats.php');
        exit;
    }
    
    // 1.2 Récupérer la liste des produits pour le menu déroulant d'ajout d'article
    $sql_produits = "SELECT id, nom, prix_achat_moyen, unite_mesure FROM produits ORDER BY nom ASC";
    $stmt_produits = $pdo->query($sql_produits);
    $produits_list = $stmt_produits->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des données : " . $e->getMessage() . "</div>";
}

// ==============================================
// 2. GESTION DES REQUÊTES POST (AJOUT/SUPPRESSION/MISE À JOUR)
// ==============================================

// Fonction utilitaire pour recalculer le total de la commande
function update_commande_total($pdo, $commande_id) {
    $sql_total = "SELECT SUM(quantite * prix_unitaire_ht) AS nouveau_total 
                  FROM lignes_commande_achat 
                  WHERE commande_achat_id = :id";
    $stmt_total = $pdo->prepare($sql_total);
    $stmt_total->execute([':id' => $commande_id]);
    $nouveau_total = $stmt_total->fetchColumn();

    $sql_update = "UPDATE commandes_achat SET total_ht = :total WHERE id = :id";
    $stmt_update = $pdo->prepare($sql_update);
    $stmt_update->execute([':total' => $nouveau_total ?: 0, ':id' => $commande_id]);
    
    return $nouveau_total ?: 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 2.1 Ajouter une ligne de commande
    if (isset($_POST['add_item'])) {
        $produit_id = intval($_POST['produit_id'] ?? 0);
        $quantite = intval($_POST['quantite'] ?? 0);
        $prix_ht = floatval($_POST['prix_unitaire_ht'] ?? 0.00);

        if ($produit_id > 0 && $quantite > 0 && $prix_ht > 0) {
            try {
                $sql = "INSERT INTO lignes_commande_achat (commande_achat_id, produit_id, quantite, prix_unitaire_ht) 
                        VALUES (:cmd_id, :prod_id, :qty, :prix)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':cmd_id' => $commande_achat_id,
                    ':prod_id' => $produit_id,
                    ':qty' => $quantite,
                    ':prix' => $prix_ht
                ]);
                $message = "<div class='alert alert-success'>Article ajouté.</div>";
                
                // Recalcul du total de la commande
                $commande_achat['total_ht'] = update_commande_total($pdo, $commande_achat_id);

            } catch (PDOException $e) {
                $message = "<div class='alert alert-danger'>Erreur lors de l'ajout de l'article : " . $e->getMessage() . "</div>";
            }
        } else {
            $message = "<div class='alert alert-danger'>Veuillez vérifier les champs (Produit, Quantité > 0, Prix > 0).</div>";
        }
    }
    // 2.2 Supprimer une ligne de commande
    elseif (isset($_POST['delete_item'])) {
        $ligne_id = intval($_POST['ligne_id'] ?? 0);
        
        try {
            $sql = "DELETE FROM lignes_commande_achat WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':id' => $ligne_id]);
            
            $message = "<div class='alert alert-warning'>Article supprimé de la commande.</div>";
            
            // Recalcul du total de la commande
            $commande_achat['total_ht'] = update_commande_total($pdo, $commande_achat_id);
            
        } catch (PDOException $e) {
             $message = "<div class='alert alert-danger'>Erreur lors de la suppression : " . $e->getMessage() . "</div>";
        }
    }

    // Réactualisation de la page pour éviter le double envoi de formulaire
    header("Location: achat_detail.php?id={$commande_achat_id}");
    exit;
}

// ==============================================
// 3. LECTURE : RÉCUPÉRATION DES LIGNES DE COMMANDE
// ==============================================
$lignes_achat = [];
try {
    $sql_lignes = "
        SELECT 
            lca.*, p.nom AS produit_nom, p.unite_mesure
        FROM 
            lignes_commande_achat lca
        JOIN 
            produits p ON lca.produit_id = p.id
        WHERE 
            lca.commande_achat_id = :id
    ";
    $stmt_lignes = $pdo->prepare($sql_lignes);
    $stmt_lignes->execute([':id' => $commande_achat_id]);
    $lignes_achat = $stmt_lignes->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des articles : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails Commande Achat #<?= $commande_achat_id ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <script>
        // Permet de mettre à jour le prix HT suggéré dans le formulaire d'ajout
        const produitsData = <?= json_encode($produits_list) ?>;
        
        function updatePrixAchat() {
            const select = document.getElementById('produit_id');
            const inputPrix = document.getElementById('prix_unitaire_ht');
            const selectedId = select.value;

            const produit = produitsData.find(p => p.id == selectedId);
            
            if (produit) {
                // Utilise le Prix Achat Moyen du produit comme prix suggéré
                inputPrix.value = parseFloat(produit.prix_achat_moyen).toFixed(2);
            } else {
                inputPrix.value = '0.00';
            }
        }
    </script>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1 style="border-bottom: 2px solid #2c3e50; padding-bottom: 10px;">
            Détails Commande Achat #<?= htmlspecialchars($commande_achat_id) ?> 
            <a href="achats.php" class="btn btn-secondary btn-small" style="float: right;">&larr; Retour aux Achats</a>
        </h1>
        
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="card mb-4 row-group">
            <div>
                <h2>Informations Commande</h2>
                <p><strong>Fournisseur :</strong> <?= htmlspecialchars($commande_achat['fournisseur_nom']) ?></p>
                <p><strong>Date Commande :</strong> <?= date('d/m/Y', strtotime($commande_achat['date_commande'])) ?></p>
                <p><strong>Livraison Prévue :</strong> <?= date('d/m/Y', strtotime($commande_achat['date_livraison_prevue'])) ?></p>
            </div>
            <div style="text-align: right;">
                <p style="font-size: 1.5em; margin-bottom: 5px;">
                    Statut actuel : <span class="status-badge status-achat-<?= str_replace('ç', 'c', $commande_achat['statut']) ?>"><?= ucfirst($commande_achat['statut']) ?></span>
                </p>
                <p style="font-size: 2em; font-weight: bold; color: #27ae60;">
                    Total HT : <?= number_format($commande_achat['total_ht'], 2) ?> €
                </p>
            </div>
        </div>

        <div class="card mb-4">
            <h3>➕ Ajouter un Article à la Commande</h3>
            <form action="achat_detail.php?id=<?= $commande_achat_id ?>" method="POST">
                <div class="form-group row-group" style="align-items: flex-end;">
                    <div style="flex: 2;">
                        <label for="produit_id">Produit/Composant <span class="required">*</span> :</label>
                        <select id="produit_id" name="produit_id" required onchange="updatePrixAchat()">
                            <option value="">-- Sélectionner un produit --</option>
                            <?php foreach ($produits_list as $prod): ?>
                                <option value="<?= $prod['id'] ?>">
                                    <?= htmlspecialchars($prod['nom']) ?> (PAM: <?= number_format($prod['prix_achat_moyen'], 2) ?> €)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($produits_list)): ?><p class="required">⚠ Aucun produit trouvé. Ajoutez-en un d'abord.</p><?php endif; ?>
                    </div>
                    <div style="flex: 1;">
                        <label for="quantite">Quantité <span class="required">*</span> :</label>
                        <input type="number" id="quantite" name="quantite" required min="1" value="1">
                    </div>
                    <div style="flex: 1;">
                        <label for="prix_unitaire_ht">Prix Unitaire HT (€) <span class="required">*</span> :</label>
                        <input type="number" step="0.01" id="prix_unitaire_ht" name="prix_unitaire_ht" required value="0.00">
                    </div>
                    <div>
                        <button type="submit" name="add_item" class="btn btn-primary">Ajouter la Ligne</button>
                    </div>
                </div>
            </form>
        </div>
        
        <h2>Articles Commandés (<?= count($lignes_achat) ?>)</h2>
        
        <?php if (!empty($lignes_achat)): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID Ligne</th>
                        <th>Produit</th>
                        <th>Quantité</th>
                        <th>Unité</th>
                        <th>Prix U. HT</th>
                        <th>Sous-Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lignes_achat as $ligne): ?>
                    <tr>
                        <td><?= htmlspecialchars($ligne['id']) ?></td>
                        <td><?= htmlspecialchars($ligne['produit_nom']) ?></td>
                        <td class="text-center"><?= htmlspecialchars($ligne['quantite']) ?></td>
                        <td><?= htmlspecialchars($ligne['unite_mesure']) ?></td>
                        <td><?= number_format($ligne['prix_unitaire_ht'], 2) ?> €</td>
                        <td>**<?= number_format($ligne['quantite'] * $ligne['prix_unitaire_ht'], 2) ?> €**</td>
                        <td>
                            <form method="POST" action="achat_detail.php?id=<?= $commande_achat_id ?>" style="display:inline-block;" onsubmit="return confirm('Supprimer cette ligne ?');">
                                <input type="hidden" name="ligne_id" value="<?= $ligne['id'] ?>">
                                <button type="submit" name="delete_item" class="btn btn-danger btn-small">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <tr style="background-color: #f0f0f0; font-weight: bold;">
                        <td colspan="5" style="text-align: right;">TOTAL HT</td>
                        <td><?= number_format($commande_achat['total_ht'], 2) ?> €</td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <p class="alert alert-warning">Aucun article n'a été ajouté à cette commande d'achat pour le moment.</p>
        <?php endif; ?>

    </div>
</body>
</html>