<?php
// admin/achat_detail.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
if (!in_array(strtolower($_SESSION['user_role']), ['admin', 'administrateur', 'logistique', 'achats'])) { die("Accès refusé."); }

$achat_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($achat_id === 0) { die("ID de commande invalide."); }

$message = '';

// --- TRAITEMENT DE LA RÉCEPTION DE COMMANDE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['receptionner'])) {
    try {
        $pdo->beginTransaction();

        // A. Vérifier que la commande n'est pas déjà réceptionnée
        $stmt_check = $pdo->prepare("SELECT statut FROM commandes_achat WHERE id = ?");
        $stmt_check->execute([$achat_id]);
        $statut_actuel = $stmt_check->fetchColumn();

        if ($statut_actuel === 'receptionnee') {
             throw new Exception("Cette commande a déjà été réceptionnée.");
        }

        // B. Mettre à jour le statut de la commande
        $stmt_update_cmd = $pdo->prepare("UPDATE commandes_achat SET statut = 'receptionnee' WHERE id = ?");
        $stmt_update_cmd->execute([$achat_id]);

        // C. Mettre à jour le stock pour chaque produit
        // On récupère les produits et quantités de cette commande
        $stmt_details = $pdo->prepare("SELECT produit_id, quantite_commandee FROM details_commande_achat WHERE commande_achat_id = ?");
        $stmt_details->execute([$achat_id]);
        $lignes = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

        $stmt_update_stock = $pdo->prepare("UPDATE produits SET quantite_stock = quantite_stock + ? WHERE id = ?");
        
        foreach ($lignes as $ligne) {
            // On augmente le stock
            $stmt_update_stock->execute([$ligne['quantite_commandee'], $ligne['produit_id']]);
        }

        $pdo->commit();
        $message = "<div class='alert alert-success' style='color:green; background:#E8FDF2; padding:15px; border-radius:12px; margin-bottom:20px;'>Commande réceptionnée avec succès ! Le stock a été mis à jour.</div>";

    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger' style='color:red; background:#FFF2F2; padding:15px; border-radius:12px; margin-bottom:20px;'>Erreur lors de la réception : " . $e->getMessage() . "</div>";
    }
}

// --- RÉCUPÉRATION DES DONNÉES POUR L'AFFICHAGE ---
try {
    // A. Infos Commande & Fournisseur
    $sql_cmd = "SELECT ca.*, u.nom as fournisseur_nom, u.email as fournisseur_email
                FROM commandes_achat ca
                JOIN utilisateurs u ON ca.fournisseur_id = u.id
                WHERE ca.id = ?";
    $stmt = $pdo->prepare($sql_cmd);
    $stmt->execute([$achat_id]);
    $achat = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$achat) { die("Commande d'achat introuvable."); }

    // B. Détails (Produits)
    $sql_details = "SELECT dca.*, p.nom as prod_nom, p.image as prod_image
                    FROM details_commande_achat dca
                    LEFT JOIN produits p ON dca.produit_id = p.id
                    WHERE dca.commande_achat_id = ?";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([$achat_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}

// Définition du style du statut
$status_class = 'status-en_attente';
if($achat['statut'] == 'receptionnee') $status_class = 'status-livree';
if($achat['statut'] == 'annulee') $status_class = 'status-annulee';
$statut_label = ucfirst($achat['statut']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Achat #<?= $achat_id ?> - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .detail-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
        .product-item { display: flex; align-items: center; gap: 20px; padding: 15px 0; border-bottom: 1px solid var(--border-color); }
        .product-img { width: 60px; height: 60px; object-fit: contain; border-radius: 10px; background: #F5F5F7; padding: 5px; }
    </style>
</head>
<body class="admin-body">
    
    <div class="admin-layout grid-layout">
        <?php include 'admin_sidebar.php'; ?>

        <div class="main-content" style="padding-top: 40px;">
            
            <a href="achats.php" style="display:inline-flex; align-items:center; gap:10px; margin-bottom:30px; font-weight:600;">
                <i class="fa-solid fa-arrow-left"></i> Retour à la liste
            </a>

            <header class="top-bar">
                <h1>Commande Achat #ACH-<?= str_pad($achat['id'], 5, '0', STR_PAD_LEFT) ?></h1>
                <span class="status-badge <?= $status_class ?>" style="font-size: 1rem; padding: 8px 20px;">
                    <?= $statut_label ?>
                </span>
            </header>

            <?= $message ?>

            <div class="detail-layout">
                
                <div class="left-col">
                    <div class="card">
                        <div class="section-header"><h2><i class="fa-solid fa-circle-info"></i> Informations</h2></div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                            <div>
                                <h3 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 10px;">Fournisseur</h3>
                                <p><strong><?= htmlspecialchars($achat['fournisseur_nom']) ?></strong></p>
                                <p><a href="mailto:<?= htmlspecialchars($achat['fournisseur_email']) ?>"><?= htmlspecialchars($achat['fournisseur_email']) ?></a></p>
                            </div>
                            <div>
                                <h3 style="font-size: 1.1rem; font-weight: 600; margin-bottom: 10px;">Dates</h3>
                                <p>Commandé le : <strong><?= (new DateTime($achat['date_commande']))->format('d/m/Y') ?></strong></p>
                                <p>Réception prévue : <strong><?= !empty($achat['date_reception_prevue']) ? (new DateTime($achat['date_reception_prevue']))->format('d/m/Y') : 'Non définie' ?></strong></p>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="section-header"><h2><i class="fa-solid fa-box-open"></i> Produits Commandés</h2></div>
                        
                        <?php foreach($details as $item): ?>
                            <?php $img_src = !empty($item['prod_image']) ? (strpos($item['prod_image'], 'http') === 0 ? $item['prod_image'] : "/startech/assets/images/produits/" . $item['prod_image']) : 'https://dummyimage.com/60x60/eee/aaa'; ?>
                            <div class="product-item">
                                <img src="<?= htmlspecialchars($img_src) ?>" class="product-img">
                                <div style="flex-grow: 1;">
                                    <div style="font-weight: 600; font-size: 1.1rem;"><?= htmlspecialchars($item['prod_nom']) ?></div>
                                </div>
                                <div style="text-align: right;">
                                    <div><?= $item['quantite_commandee'] ?> unités x <?= number_format($item['prix_achat_unitaire'], 2, ',', ' ') ?> € HT</div>
                                    <div style="font-weight: 700; color: var(--accent-blue);">Total HT : <?= number_format($item['quantite_commandee'] * $item['prix_achat_unitaire'], 2, ',', ' ') ?> €</div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div style="margin-top: 30px; text-align: right;">
                            <h3 style="font-size: 1.8rem; color: var(--accent-blue); margin-top: 15px;">Total Commande HT : <?= number_format($achat['montant_total'], 2, ',', ' ') ?> €</h3>
                        </div>
                    </div>
                </div>

                <div class="right-col">
                    <div class="card" style="background: #E8F2FF; border: 1px solid #D0E1F9; position: sticky; top: 30px;">
                        <div class="section-header">
                            <h2 style="color: var(--accent-blue);"><i class="fa-solid fa-gear"></i> Actions</h2>
                        </div>
                        
                        <?php if ($achat['statut'] !== 'receptionnee'): ?>
                            <p style="margin-bottom: 20px; color: var(--text-secondary);">Lorsque la marchandise arrive à l'entrepôt, validez la réception pour mettre à jour le stock.</p>
                            <form method="post">
                                <button type="submit" name="receptionner" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem; background-color: var(--accent-green);" onclick="return confirm('Confirmer la réception de toute la marchandise ? Le stock sera mis à jour.');">
                                    <i class="fa-solid fa-check-double"></i> Réceptionner la commande
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-success" style="background:#E8FDF2; color:var(--accent-green); padding:15px; border-radius:12px; text-align:center; font-weight:600;">
                                <i class="fa-solid fa-circle-check"></i> Commande déjà réceptionnée.
                            </div>
                            <p style="text-align:center; margin-top:10px; color:var(--text-secondary);">Le stock a été mis à jour.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>

</body>
</html>