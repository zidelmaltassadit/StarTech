<?php
// startech/admin/commandes.php
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Exige l'accès administrateur
require_admin();

$message = '';
$filter_status = $_GET['statut'] ?? 'all'; // Statut par défaut : tout afficher

// Liste des statuts possibles pour le filtre et la mise à jour
$statuts_possibles = [
    'brouillon', 
    'en_attente', 
    'en_preparation', 
    'expediee', 
    'livre', // Renommé 'livre' pour correspondre à votre ENUM dans le code précédent
    'annulee', 
    // 'remboursee' (Ce statut est souvent géré au niveau de la FACTURE, pas de la COMMANDE)
];


// ==============================================
// 1. GESTION DES REQUÊTES POST (MISE À JOUR DU STATUT)
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $commande_id = intval($_POST['commande_id'] ?? 0);
    $new_status = trim($_POST['new_status'] ?? '');

    // Sécurité: Vérifier que le statut est valide
    if (!in_array($new_status, $statuts_possibles)) {
        $message = "<div class='alert alert-danger'>Statut invalide.</div>";
    } elseif ($commande_id > 0 && !empty($new_status)) {
        try {
            $sql = "UPDATE commandes SET statut = :statut, date_mise_a_jour = NOW() WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':statut' => $new_status, ':id' => $commande_id]);

            $message = "<div class='alert alert-success'>Statut de la commande #{$commande_id} mis à jour à **" . ucfirst(str_replace('_', ' ', $new_status)) . "**." . "</div>";
        } catch (PDOException $e) {
            $message = "<div class='alert alert-danger'>Erreur lors de la mise à jour : " . $e->getMessage() . "</div>";
        }
    }
}

// ==============================================
// 2. LECTURE : RÉCUPÉRATION DES COMMANDES FILTRÉES
// ==============================================
$commandes = [];
$statut_bind = [];
$where_clause = '';

if ($filter_status !== 'all') {
    $where_clause = " WHERE c.statut = :statut";
    $statut_bind = [':statut' => $filter_status];
}

try {
    // CORRECTION DE LA REQUÊTE : Utilisation de 'clients' et des totaux HT/TTC
    $sql_commandes = "
        SELECT 
            c.id, c.client_id, c.date_commande, c.statut, c.total_ttc, c.date_mise_a_jour,
            cl.nom AS client_nom, cl.prenom AS client_prenom, cl.entreprise, cl.email AS client_email
        FROM 
            commandes c
        JOIN 
            clients cl ON c.client_id = cl.id /* Jointure corrigée vers la table clients */
        {$where_clause}
        ORDER BY 
            c.date_commande DESC
    ";
    $stmt_commandes = $pdo->prepare($sql_commandes);
    $stmt_commandes->execute($statut_bind);
    $commandes = $stmt_commandes->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des commandes : " . $e->getMessage() . "</div>";
    $commandes = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Commandes Clients</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        /* Styles pour la cohérence visuelle */
        .status-badge { padding: 3px 8px; border-radius: 4px; font-weight: bold; }
        .status-brouillon { background-color: #f7d247; color: #333; }
        .status-en_attente { background-color: #f7a047; color: #fff; }
        .status-en_preparation { background-color: #5bc0de; color: #fff; }
        .status-expediee { background-color: #4CAF50; color: #fff; }
        .status-livre { background-color: #28a745; color: #fff; }
        .status-annulee { background-color: #dc3545; color: #fff; }
        .active-filter { border: 2px solid #007bff !important; }
        .form-control-small { padding: 4px 8px; border: 1px solid #ccc; border-radius: 4px; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>🛒 Gestion des Commandes Clients</h1>
        
        <?php echo $message; // Affichage des messages de statut ?>
        
        <div class="card mb-4">
            <a href="commandes_vente.php" class="btn btn-primary">+ Créer une nouvelle commande</a>
        </div>


        <div class="card mb-4" style="display: flex; gap: 10px; flex-wrap: wrap;">
            <h3>Filtrer par Statut :</h3>
            <a href="commandes.php?statut=all" class="btn btn-secondary <?= $filter_status === 'all' ? 'active-filter' : '' ?>">Toutes (<?= count($commandes) ?>)</a>
            
            <?php foreach ($statuts_possibles as $stat): ?>
                <?php
                    // Compter combien de commandes correspondent à ce statut (Optionnel, nécessite une requête supplémentaire pour être précis)
                    // Pour l'instant, on affiche le bouton sans le compte précis si le filtre n'est pas actif.
                    $count = ($filter_status === $stat) ? count($commandes) : 0; 
                ?>
                <a href="commandes.php?statut=<?= $stat ?>" 
                   class="btn btn-primary btn-small <?= $filter_status === $stat ? 'active-filter' : '' ?>">
                    <?= ucfirst(str_replace('_', ' ', $stat)) ?>
                    <?php if ($filter_status === $stat): ?>
                        (<?= $count ?>)
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <h2>Liste des Commandes (Statut: <?= $filter_status === 'all' ? 'Toutes' : ucfirst(str_replace('_', ' ', $filter_status)) ?>)</h2>
        
        <?php if (!empty($commandes)): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID Commande</th>
                        <th>Client</th>
                        <th>Email</th>
                        <th>Date Commande</th>
                        <th>Montant TTC</th>
                        <th>Statut Actuel</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($commandes as $c): ?>
                    <tr>
                        <td>#<?= htmlspecialchars($c['id']) ?></td>
                        <td>
                            **<?= htmlspecialchars($c['client_nom']) ?>** <?= htmlspecialchars($c['client_prenom']) ?>
                            <?php if (!empty($c['entreprise'])): ?>(<?= htmlspecialchars($c['entreprise']) ?>)<?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($c['client_email']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($c['date_commande'])) ?></td>
                        <td class="text-right">**<?= number_format($c['total_ttc'], 2, ',', ' ') ?> €**</td>
                        <td><span class="status-badge status-<?= $c['statut'] ?>"><?= ucfirst(str_replace('_', ' ', $c['statut'])) ?></span></td>
                        <td>
                            <form method="POST" action="commandes.php?statut=<?= $filter_status ?>" style="display:inline-flex; gap: 5px;">
                                <input type="hidden" name="commande_id" value="<?= $c['id'] ?>">
                                <select name="new_status" required class="form-control-small">
                                    <?php foreach ($statuts_possibles as $s): ?>
                                        <option value="<?= $s ?>" <?= ($c['statut'] == $s) ? 'selected' : '' ?>>
                                            <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-primary btn-small">MàJ</button>
                            </form>
                            
                            <a href="commandes_vente.php?action=edit&id=<?= $c['id'] ?>" class="btn btn-edit btn-small">Modifier Saisie</a>
                            
                            <a href="commande_detail.php?id=<?= $c['id'] ?>" class="btn btn-secondary btn-small">Détails</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="alert alert-warning">Aucune commande trouvée pour le statut "<?= $filter_status === 'all' ? 'Toutes' : ucfirst(str_replace('_', ' ', $filter_status)) ?>".</p>
        <?php endif; ?>

    </div>
</body>
</html>