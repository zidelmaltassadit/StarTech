<?php
// admin/commandes.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
$allowed = ['admin', 'administrateur', 'logistique', 'commercial', 'comptabilite'];
if (!in_array(strtolower($_SESSION['user_role']), $allowed)) { die("Accès refusé."); }

// 2. RÉCUPÉRATION DES COMMANDES (Liste complète, du plus récent au plus ancien)
$sql = "SELECT c.*, cl.nom as client_nom 
        FROM commandes c
        LEFT JOIN clients cl ON c.client_id = cl.id
        ORDER BY c.date_commande DESC";
$commandes = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Commandes - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="admin-body">

    <div class="admin-layout grid-layout">
        <?php include 'admin_sidebar.php'; ?>

        <main class="main-content">
            
            <header class="top-bar">
                <h1>Commandes Clients</h1>
            </header>

            <div class="card" style="padding: 0; overflow: hidden;">
                <table class="apple-table">
                    <thead>
                        <tr>
                            <th style="padding-left: 30px;">N° Commande</th>
                            <th>Client</th>
                            <th>Date</th>
                            <th>Montant Total</th>
                            <th>Statut</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($commandes as $c): ?>
                            <tr>
                                <td style="padding-left: 30px;" class="font-mono">#<?= str_pad($c['id'], 6, '0', STR_PAD_LEFT) ?></td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($c['client_nom'] ?? 'Client supprimé') ?></td>
                                <td><?= (new DateTime($c['date_commande']))->format('d/m/Y H:i') ?></td>
                                <td style="font-weight: 700;"><?= number_format($c['montant_total'], 2, ',', ' ') ?> €</td>
                                <td>
                                    <span class="status-badge status-<?= strtolower($c['statut']) ?>">
                                        <?= ucfirst(str_replace('_', ' ', $c['statut'])) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="commande_detail.php?id=<?= $c['id'] ?>" class="btn-small btn-outline">
                                        <i class="fa-solid fa-eye"></i> Gérer
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

</body>
</html>