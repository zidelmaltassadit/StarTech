<?php
// admin/produit_delete.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// SÉCURITÉ MAXIMALE : Seuls les super-admins peuvent supprimer
if (!is_logged_in() || strtolower($_SESSION['user_role']) !== 'admin') {
    die("Accès refusé. Seul l'administrateur principal peut supprimer des produits.");
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    try {
        // On vérifie d'abord si le produit est utilisé dans des commandes
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM details_commande WHERE produit_id = ?");
        $stmt_check->execute([$id]);
        if ($stmt_check->fetchColumn() > 0) {
            // S'il est déjà commandé, on ne le supprime pas, on le désactive
            $stmt = $pdo->prepare("UPDATE produits SET statut = 'inactif' WHERE id = ?");
            $stmt->execute([$id]);
            $msg = "Le produit ne peut pas être supprimé car il fait partie de commandes existantes. Il a été marqué comme 'Inactif'.";
        } else {
            // Sinon, on peut le supprimer physiquement
            // (Optionnel : on pourrait aussi supprimer l'image du serveur ici)
            $stmt = $pdo->prepare("DELETE FROM produits WHERE id = ?");
            $stmt->execute([$id]);
            $msg = "Produit supprimé définitivement.";
        }
    } catch (PDOException $e) {
        $msg = "Erreur lors de la suppression : " . $e->getMessage();
    }
} else {
    $msg = "ID produit invalide.";
}

// Retour à la liste
header("Location: produits.php?msg=" . urlencode($msg));
exit;