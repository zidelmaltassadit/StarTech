<?php
// Inclure les fichiers de configuration et de sécurité
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_once '../includes/facturation_functions.php'; // Ce fichier sera créé ensuite

// --- SÉCURITÉ : Exige l'accès administrateur
require_admin();

$message = '';
$factures = [];
$commandes_a_facturer = [];

// ==============================================
// 1. GESTION DES ACTIONS POST
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'generer_facture') {
            $commande_id = intval($_POST['commande_id'] ?? 0);
            if ($commande_id > 0) {
                // Fonction à créer dans facturation_functions.php
                $facture_id = generer_facture_depuis_commande($pdo, $commande_id);
                $message = "<div class='alert alert-success'>Facture #{$facture_id} générée avec succès pour la commande #{$commande_id}.</div>";
            }
        } elseif ($action === 'enregistrer_paiement') {
            $facture_id = intval($_POST['facture_id'] ?? 0);
            $montant_paye = floatval($_POST['montant_paye'] ?? 0);
            $mode_paiement = $_POST['mode_paiement'] ?? 'Virement';

            if ($facture_id > 0 && $montant_paye > 0) {
                // Fonction à créer dans facturation_functions.php
                enregistrer_paiement_facture($pdo, $facture_id, $montant_paye, $mode_paiement);
                $message = "<div class='alert alert-success'>Paiement de {$montant_paye} € enregistré pour la Facture #{$facture_id}.</div>";
            }
        }
    } catch (Exception $e) {
        $message = "<div class='alert alert-danger'>Erreur : " . $e->getMessage() . "</div>";
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Erreur BD : " . $e->getMessage() . "</div>";
    }
}

// ==============================================
// 2. LECTURE : COMMANDES PRÊTES À ÊTRE FACTURÉES
// Statut = 'livre' (ou 'expediee' selon votre flux) et non encore facturée
// ==============================================
try {
    $sql_a_facturer = "
        SELECT 
            c.id, c.date_commande, c.total_ttc, cl.nom AS client_nom
        FROM 
            commandes c
        JOIN 
            clients cl ON c.client_id = cl.id
        WHERE 
            c.statut IN ('livre', 'expediee') AND c.statut_facturation = 'non_facture'
        ORDER BY 
            c.date_commande ASC
    ";
    $stmt_a_facturer = $pdo->query($sql_a_facturer);
    $commandes_a_facturer = $stmt_a_facturer->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur lors du chargement des commandes à facturer : " . $e->getMessage() . "</div>";
}

// ==============================================
// 3. LECTURE : FACTURES EXISTANTES
// ==============================================
try {
    $sql_factures = "
        SELECT 
            f.id, f.date_facture, f.total_ttc, f.statut_paiement, c.id AS commande_id, cl.nom AS client_nom
        FROM 
            factures f
        JOIN
            commandes c ON f.commande_id = c.id
        JOIN 
            clients cl ON c.client_id = cl.id
        ORDER BY 
            f.date_facture DESC
        LIMIT 20
    ";
    $stmt_factures = $pdo->query($sql_factures);
    $factures = $stmt_factures->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Note : Cette erreur surviendra TANT QUE la table 'factures' n'est pas créée.
    $message .= "<div class='alert alert-warning'>Table 'factures' non trouvée ou erreur de chargement : " . $e->getMessage() . "</div>";
    $factures = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Facturation</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        /* Styles spécifiques pour Facturation */
        .status-paiement-payee { background-color: #27ae60; }
        .status-paiement-partielle { background-color: #f39c12; }
        .status-paiement-impayee { background-color: #e74c3c; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>💵 Gestion de la Facturation</h1>
        
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="card mb-4">
            <h2>Commandes Prêtes à Facturer (<?= count($commandes_a_facturer) ?>)</h2>
            <?php if (!empty($commandes_a_facturer)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Commande</th>
                            <th>Client</th>
                            <th>Date</th>
                            <th>Montant TTC</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($commandes_a_facturer as $cmd): ?>
                        <tr>
                            <td><a href="commande_detail.php?id=<?= $cmd['id'] ?>">#<?= htmlspecialchars($cmd['id']) ?></a></td>
                            <td><?= htmlspecialchars($cmd['client_nom']) ?></td>
                            <td><?= date('d/m/Y', strtotime($cmd['date_commande'])) ?></td>
                            <td class="text-right"><?= number_format($cmd['total_ttc'], 2, ',', ' ') ?> €</td>
                            <td>
                                <form method="POST" action="facturation.php" style="display:inline-block;">
                                    <input type="hidden" name="action" value="generer_facture">
                                    <input type="hidden" name="commande_id" value="<?= $cmd['id'] ?>">
                                    <button type="submit" class="btn btn-primary btn-small">Générer Facture</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Toutes les commandes livrées sont facturées ou aucune commande n'est encore livrée.</p>
            <?php endif; ?>
        </div>

        <div class="card mb-4">
            <h2>Factures Émises (Dernières 20)</h2>
            <?php if (!empty($factures)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Facture</th>
                            <th>Commande Source</th>
                            <th>Client</th>
                            <th>Date Facture</th>
                            <th>Montant TTC</th>
                            <th>Statut Paiement</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($factures as $f): ?>
                        <tr>
                            <td>#<?= htmlspecialchars($f['id']) ?></td>
                            <td><a href="commande_detail.php?id=<?= $f['commande_id'] ?>">#<?= htmlspecialchars($f['commande_id']) ?></a></td>
                            <td><?= htmlspecialchars($f['client_nom']) ?></td>
                            <td><?= date('d/m/Y', strtotime($f['date_facture'])) ?></td>
                            <td class="text-right"><?= number_format($f['total_ttc'], 2, ',', ' ') ?> €</td>
                            <td><span class="status-badge status-paiement-<?= strtolower($f['statut_paiement']) ?>"><?= ucfirst($f['statut_paiement']) ?></span></td>
                            <td>
                                <a href="facture_pdf.php?id=<?= $f['id'] ?>" class="btn btn-secondary btn-small">Voir/PDF</a>
                                <?php if ($f['statut_paiement'] !== 'Payee'): ?>
                                    <button class="btn btn-success btn-small" onclick="document.getElementById('paiement_form_<?= $f['id'] ?>').style.display='block'">Payer</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr id="paiement_form_<?= $f['id'] ?>" style="display: none;">
                            <td colspan="7">
                                <form method="POST" action="facturation.php" class="row-group" style="padding: 10px;">
                                    <input type="hidden" name="action" value="enregistrer_paiement">
                                    <input type="hidden" name="facture_id" value="<?= $f['id'] ?>">
                                    <div style="flex: 1;">
                                        <input type="number" step="0.01" name="montant_paye" placeholder="Montant Payé" required>
                                    </div>
                                    <div style="flex: 1;">
                                        <select name="mode_paiement">
                                            <option value="Virement">Virement</option>
                                            <option value="Chèque">Chèque</option>
                                            <option value="Carte">Carte Bancaire</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-success">Valider Paiement</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucune facture émise pour le moment.</p>
            <?php endif; ?>
        </div>
        
    </div>
</body>
</html>