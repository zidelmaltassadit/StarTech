<?php
// admin/devis_vers_commande.php
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Exige l'accès administrateur
require_admin();

$devis_id = intval($_GET['devis_id'] ?? 0);
$message = '';

if ($devis_id <= 0) {
    $message = "<div class='alert alert-danger'>ID de devis manquant.</div>";
    // Redirection vers la liste des devis si l'ID est invalide
    header("Location: devis.php?message=" . urlencode($message));
    exit;
}

$pdo->beginTransaction();
try {
    // 1. Récupérer le devis
    $sql_devis = "SELECT * FROM devis WHERE id = ?";
    $stmt_devis = $pdo->prepare($sql_devis);
    $stmt_devis->execute([$devis_id]);
    $devis = $stmt_devis->fetch(PDO::FETCH_ASSOC);

    if (!$devis) {
        throw new Exception("Le devis #{$devis_id} n'existe pas.");
    }

    if ($devis['statut'] !== 'accepte') {
        throw new Exception("Le devis #{$devis_id} n'a pas le statut 'accepte' et ne peut pas être converti.");
    }

    // 2. Créer l'en-tête de la commande
    $sql_insert_cmd = "
        INSERT INTO commandes (client_id, date_commande, total_ht, total_ttc, statut, statut_facturation) 
        VALUES (?, NOW(), ?, ?, 'en_attente', 'non_facturee')
    ";
    $stmt_insert_cmd = $pdo->prepare($sql_insert_cmd);
    $stmt_insert_cmd->execute([
        $devis['client_id'],
        $devis['total_ht'],
        $devis['total_ttc']
    ]);
    $nouvelle_commande_id = $pdo->lastInsertId();

    // 3. Récupérer les détails du devis
    $sql_details = "SELECT produit_id, quantite, prix_unitaire_ht, total_ligne_ht FROM devis_details WHERE devis_id = ?";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([$devis_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($details)) {
        throw new Exception("Le devis #{$devis_id} ne contient aucune ligne de produit.");
    }

    // 4. Insérer les détails dans la nouvelle commande
    $sql_insert_detail = "
        INSERT INTO commande_details (commande_id, produit_id, quantite, prix_unitaire_ht, total_ligne_ht)
        VALUES (?, ?, ?, ?, ?)
    ";
    $stmt_insert_detail = $pdo->prepare($sql_insert_detail);
    
    foreach ($details as $detail) {
        $stmt_insert_detail->execute([
            $nouvelle_commande_id,
            $detail['produit_id'],
            $detail['quantite'],
            $detail['prix_unitaire_ht'],
            $detail['total_ligne_ht']
        ]);
    }
    
    // 5. Mettre à jour le statut du devis
    $sql_update_devis = "UPDATE devis SET statut = 'converti' WHERE id = ?";
    $pdo->prepare($sql_update_devis)->execute([$devis_id]);

    $pdo->commit();
    
    $message = "<div class='alert alert-success'>Le devis **#{$devis_id}** a été converti avec succès en **Commande #{$nouvelle_commande_id}**. Vous êtes redirigé.</div>";
    
    // Redirection vers le détail de la nouvelle commande pour la suite du traitement
    header("Location: commandes.php?statut=en_attente&message=" . urlencode($message));
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    $message = "<div class='alert alert-danger'>Erreur lors de la conversion du devis : " . $e->getMessage() . "</div>";
    header("Location: devis.php?message=" . urlencode($message));
    exit;
}

// Fallback pour le HTML (ne devrait pas être atteint)
?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><title>Conversion en cours...</title></head><body>
    <div class="container"><?php echo $message; ?></div>
</body></html>