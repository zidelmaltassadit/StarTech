<?php
// Inclure les fichiers de configuration
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Exige l'accès administrateur
require_admin();

$message = '';
$action = $_GET['action'] ?? 'read';
$commande_achat_a_modifier = null;

// ==============================================
// 1. RÉCUPÉRATION DES DONNÉES POUR LES MENUS DÉROULANTS (CRUD)
// ==============================================
try {
    // Récupérer les fournisseurs
    $sql_fournisseurs = "SELECT id, nom_societe FROM fournisseurs ORDER BY nom_societe ASC";
    $stmt_four = $pdo->query($sql_fournisseurs);
    $fournisseurs_list = $stmt_four->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des fournisseurs : " . $e->getMessage() . "</div>";
    $fournisseurs_list = [];
}

// ==============================================
// 2. GESTION DES REQUÊTES POST
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fournisseur_id = intval($_POST['fournisseur_id'] ?? 0);
    $date_prevue = trim($_POST['date_prevue'] ?? '');
    $statut = trim($_POST['statut'] ?? 'en_cours');
    $commande_id = $_POST['id'] ?? null;
    $total_ht = floatval($_POST['total_ht'] ?? 0.00);


    if (isset($_POST['add'])) {
        // --- C: Création (Ajouter une nouvelle commande d'achat)
        if ($fournisseur_id === 0) {
            $message = "<div class='alert alert-danger'>Veuillez sélectionner un fournisseur.</div>";
        } else {
            try {
                $sql = "INSERT INTO commandes_achat (fournisseur_id, date_commande, date_livraison_prevue, total_ht, statut) 
                        VALUES (:four_id, NOW(), :date_p, :total, :statut)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':four_id' => $fournisseur_id,
                    ':date_p' => $date_prevue,
                    ':total' => $total_ht,
                    ':statut' => 'en_cours' // Toujours démarrer une nouvelle commande en 'en_cours'
                ]);
                $new_id = $pdo->lastInsertId();
                $message = "<div class='alert alert-success'>Commande d'achat #{$new_id} créée avec succès. Vous devez maintenant ajouter des articles à cette commande.</div>";
                // On redirige vers l'édition pour ajouter des articles (étape suivante)
                header("Location: achat_detail.php?id={$new_id}"); 
                exit; 
            } catch (PDOException $e) {
                $message = "<div class='alert alert-danger'>Erreur base de données lors de la création : " . $e->getMessage() . "</div>";
            }
        }
    } elseif (isset($_POST['update_status']) && $commande_id) {
        // --- U: Mise à jour du statut
        try {
            $sql = "UPDATE commandes_achat SET statut = :statut, total_ht = :total WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':statut' => $statut, 
                ':total' => $total_ht, 
                ':id' => $commande_id
            ]);
            $message = "<div class='alert alert-success'>Statut de la commande d'achat #{$commande_id} mis à jour à **{$statut}**.</div>";
            $action = 'read';
        } catch (PDOException $e) {
            $message = "<div class='alert alert-danger'>Erreur lors de la mise à jour : " . $e->getMessage() . "</div>";
        }
    } elseif (isset($_POST['receive_stock']) && $commande_id) {
        // --- LOGISTIQUE CRITIQUE : Réception de Stock (met à jour le stock)
        // NOTE: Pour simplifier, on suppose que la commande entière est reçue ici.
        // La gestion ligne par ligne sera faite dans achat_detail.php (étape future)
        try {
            $pdo->beginTransaction();

            // 1. Mettre à jour le statut de la commande à 'reçue'
            $sql_update = "UPDATE commandes_achat SET statut = 'reçue', date_reception_reelle = NOW() WHERE id = :id AND statut != 'reçue'";
            $stmt_update = $pdo->prepare($sql_update);
            $stmt_update->execute([':id' => $commande_id]);
            
            if ($stmt_update->rowCount() > 0) {
                // 2. Mettre à jour le stock des produits liés à cette commande
                $sql_items = "SELECT produit_id, quantite, prix_unitaire_ht FROM lignes_commande_achat WHERE commande_achat_id = :id";
                $stmt_items = $pdo->prepare($sql_items);
                $stmt_items->execute([':id' => $commande_id]);
                $items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

                foreach ($items as $item) {
                    // Calcul du nouveau prix achat moyen (simplifié : on prend le prix de la commande)
                    $sql_stock = "UPDATE produits SET quantite_stock = quantite_stock + :qty, prix_achat_moyen = :pa WHERE id = :prod_id";
                    $stmt_stock = $pdo->prepare($sql_stock);
                    $stmt_stock->execute([
                        ':qty' => $item['quantite'], 
                        ':pa' => $item['prix_unitaire_ht'], // Le vrai P.A.M est plus complexe (FIFO, LIFO, CMUP)
                        ':prod_id' => $item['produit_id']
                    ]);
                }
                
                $pdo->commit();
                $message = "<div class='alert alert-success'>Commande d'achat #{$commande_id} reçue. **Le stock a été mis à jour** pour {$stmt_update->rowCount()} articles.</div>";
            } else {
                // Si rowCount est 0, c'est que la commande était déjà reçue
                 $message = "<div class='alert alert-warning'>Commande d'achat #{$commande_id} déjà marquée comme reçue.</div>";
            }
            $action = 'read';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Erreur critique lors de la réception du stock : " . $e->getMessage() . "</div>";
        }
    }
}

// ==============================================
// 3. LECTURE : RÉCUPÉRATION DES COMMANDES D'ACHAT
// ==============================================
$commandes_achat = [];
$statuts_achat = [
    'en_cours', 
    'expediee', 
    'reçue', 
    'facturée',
    'annulee'
];

try {
    $sql_achats = "
        SELECT 
            ca.*, f.nom_societe AS fournisseur_nom
        FROM 
            commandes_achat ca
        JOIN 
            fournisseurs f ON ca.fournisseur_id = f.id
        ORDER BY 
            ca.date_commande DESC
    ";
    $stmt_achats = $pdo->query($sql_achats);
    $commandes_achat = $stmt_achats->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des commandes d'achat : " . $e->getMessage() . "</div>";
    $commandes_achat = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Achats</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>🧾 Gestion des Commandes d'Achat</h1>
        
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="card mb-4">
            <h2>➕ Créer une Nouvelle Commande d'Achat</h2>
            <form action="achats.php" method="POST">
                <div class="form-group row-group">
                    <div>
                        <label for="fournisseur_id">Fournisseur <span class="required">*</span> :</label>
                        <select id="fournisseur_id" name="fournisseur_id" required class="form-control-full">
                            <option value="">-- Sélectionner --</option>
                            <?php foreach ($fournisseurs_list as $four): ?>
                                <option value="<?= $four['id'] ?>"><?= htmlspecialchars($four['nom_societe']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($fournisseurs_list)): ?><p class="required">⚠ Aucun fournisseur trouvé. Ajoutez-en un d'abord.</p><?php endif; ?>
                    </div>
                    <div>
                        <label for="date_prevue">Date de Livraison Prévue :</label>
                        <input type="date" id="date_prevue" name="date_prevue" value="<?= date('Y-m-d', strtotime('+7 days')) ?>">
                    </div>
                </div>

                <p class="alert alert-warning">NOTE : Les articles et le montant final seront ajoutés à l'étape suivante (Détails).</p>
                <button type="submit" name="add" class="btn btn-success">▶️ Créer la Commande (et Ajouter les Articles)</button>
            </form>
        </div>
        
        <h2>Liste des Commandes d'Achat (<?= count($commandes_achat) ?>)</h2>
        
        <?php if (!empty($commandes_achat)): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Fournisseur</th>
                        <th>Date Commande</th>
                        <th>Livraison Prévue</th>
                        <th>Total HT</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($commandes_achat as $ca): ?>
                    <tr>
                        <td>#<?= htmlspecialchars($ca['id']) ?></td>
                        <td><?= htmlspecialchars($ca['fournisseur_nom']) ?></td>
                        <td><?= date('d/m/Y', strtotime($ca['date_commande'])) ?></td>
                        <td><?= date('d/m/Y', strtotime($ca['date_livraison_prevue'])) ?></td>
                        <td><?= number_format($ca['total_ht'], 2) ?> €</td>
                        <td><span class="status-badge status-achat-<?= str_replace('ç', 'c', $ca['statut']) ?>"><?= ucfirst($ca['statut']) ?></span></td>
                        <td>
                            <?php if ($ca['statut'] === 'expediee' || $ca['statut'] === 'en_cours'): ?>
                            <form method="POST" action="achats.php" style="display:inline-block;" onsubmit="return confirm('Confirmez la réception ? Cela mettra à jour le stock des produits !');">
                                <input type="hidden" name="id" value="<?= $ca['id'] ?>">
                                <button type="submit" name="receive_stock" class="btn btn-success btn-small">📦 Recevoir le Stock</button>
                            </form>
                            <?php endif; ?>
                            
                            <a href="achat_detail.php?id=<?= $ca['id'] ?>" class="btn btn-secondary btn-small">Détails/Articles</a>
                            
                            <form method="POST" action="achats.php" style="display:inline-flex; gap: 5px; margin-left: 5px;">
                                <input type="hidden" name="id" value="<?= $ca['id'] ?>">
                                <input type="hidden" name="total_ht" value="<?= $ca['total_ht'] ?>">
                                <select name="statut" required class="form-control-small">
                                    <?php foreach ($statuts_achat as $s): ?>
                                        <option value="<?= $s ?>" <?= ($ca['statut'] == $s) ? 'selected' : '' ?>>
                                            <?= ucfirst($s) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-primary btn-small">MàJ</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="alert alert-warning">Aucune commande d'achat n'a été trouvée.</p>
        <?php endif; ?>

    </div>
</body>
</html>