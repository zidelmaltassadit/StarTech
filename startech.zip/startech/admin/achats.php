<?php
// admin/achats.php (VERSION INTELLIGENTE AVEC ALERTES STOCK)
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
$allowed = ['admin', 'administrateur', 'logistique', 'achats'];
if (!in_array(strtolower($_SESSION['user_role']), $allowed)) { die("Accès refusé."); }

// ==============================================================================
// 2. NOUVEAU : RÉCUPÉRATION DES ALERTES DE STOCK (PRODUITS À COMMANDER)
// ==============================================================================

// A. La requête qui trouve les produits sous le seuil
$sql_alertes = "SELECT p.*, u.id as fourn_id, u.nom as fourn_nom, c.nom as cat_nom
                FROM produits p
                JOIN utilisateurs u ON p.fournisseur_id = u.id
                LEFT JOIN categories c ON p.categorie_id = c.id
                WHERE p.quantite_stock <= p.seuil_alerte 
                AND p.statut = 'actif'
                ORDER BY u.nom ASC, p.nom ASC";
$alertes_brutes = $pdo->query($sql_alertes)->fetchAll(PDO::FETCH_ASSOC);

// B. On regroupe les alertes par fournisseur pour l'affichage
$alertes_par_fournisseur = [];
foreach ($alertes_brutes as $prod) {
    $f_id = $prod['fourn_id'];
    if (!isset($alertes_par_fournisseur[$f_id])) {
        $alertes_par_fournisseur[$f_id] = [
            'nom_fournisseur' => $prod['fourn_nom'],
            'produits' => []
        ];
    }
    $alertes_par_fournisseur[$f_id]['produits'][] = $prod;
}
$nb_fournisseurs_alerte = count($alertes_par_fournisseur);


// ==============================================================================
// 3. RÉCUPÉRATION DE L'HISTORIQUE DES COMMANDES D'ACHAT (Comme avant)
// ==============================================================================
$sql_history = "SELECT ca.*, u.nom as fournisseur_nom,
               (SELECT COUNT(*) FROM details_commande_achat WHERE commande_achat_id = ca.id) as nb_produits
        FROM commandes_achat ca
        LEFT JOIN utilisateurs u ON ca.fournisseur_id = u.id
        ORDER BY ca.date_commande DESC";
$achats_history = $pdo->query($sql_history)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Achats - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Style pour la nouvelle section d'alerte */
        .alert-section { background: #FFF0E6; border: 1px solid #FFD8BE; border-radius: 18px; padding: 25px; margin-bottom: 40px; }
        .alert-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; color: #FF3B30; }
        .alert-header h2 { font-size: 1.3rem; margin: 0; display: flex; align-items: center; gap: 10px; }
        
        .supplier-alert-card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border-left: 4px solid #FF9F43; }
        .alert-product-list { margin: 15px 0; padding-left: 20px; }
        .alert-product-list li { margin-bottom: 8px; color: var(--text-primary); }
        .stock-critical { color: #FF3B30; font-weight: 700; }
        .threshold-info { color: var(--text-secondary); font-size: 0.9rem; }
    </style>
</head>
<body class="admin-body">

    <div class="admin-layout grid-layout">
        <?php include 'admin_sidebar.php'; ?>

        <main class="main-content">
            
            <header class="top-bar">
                <h1>Commandes d'Achat & Réapprovisionnement</h1>
                <a href="achat_form.php" class="btn btn-primary" style="display:flex; align-items:center; gap:10px;">
                    <i class="fa-solid fa-plus"></i> Nouvelle Commande Achat
                </a>
            </header>

            <?php if ($nb_fournisseurs_alerte > 0): ?>
            <section class="alert-section animate-pop-in">
                <div class="alert-header">
                    <h2><i class="fa-solid fa-triangle-exclamation"></i> Ruptures de stock imminentes !</h2>
                    <span class="badge-role" style="background:#FF3B30; color:white;"><?= $nb_fournisseurs_alerte ?> fournisseurs concernés</span>
                </div>
                <p style="margin-bottom: 25px; color: #FF3B30; font-weight: 500;">Des produits sont passés sous leur seuil d'alerte. Il est temps de commander.</p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px;">
                    <?php foreach($alertes_par_fournisseur as $fourn_id => $data): ?>
                        <div class="supplier-alert-card">
                            <h3 style="font-size: 1.1rem; margin-bottom: 15px; display: flex; justify-content: space-between;">
                                <span>Chez : <strong><?= htmlspecialchars($data['nom_fournisseur']) ?></strong></span>
                                <a href="achat_form.php?preselect=<?= $fourn_id ?>" class="btn-small btn-primary" style="font-size: 0.85rem; background-color: #FF9F43;">
                                    <i class="fa-solid fa-cart-plus"></i> Préparer la commande
                                </a>
                            </h3>
                            <ul class="alert-product-list">
                                <?php foreach($data['produits'] as $p): ?>
                                    <li>
                                        <strong><?= htmlspecialchars($p['nom']) ?></strong>
                                        <br>
                                        Stock actuel : <span class="stock-critical"><?= $p['quantite_stock'] ?></span>
                                        <span class="threshold-info">(Seuil : <?= $p['seuil_alerte'] ?>)</span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>
            <div class="section-header" style="margin-top: 50px;">
                 <h2><i class="fa-solid fa-clock-rotate-left"></i> Historique des commandes</h2>
            </div>
            <div class="card" style="padding: 0; overflow: hidden;">
                <table class="apple-table">
                    <thead>
                        <tr>
                            <th style="padding-left: 30px;">N° Cmd Achat</th>
                            <th>Fournisseur</th>
                            <th>Date Commande</th>
                            <th>Nb Produits</th>
                            <th>Montant Total HT</th>
                            <th>Statut</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($achats_history)): ?>
                            <tr><td colspan="7" style="text-align:center; color:#86868b; padding: 30px;">Aucune commande d'achat passée pour le moment.</td></tr>
                        <?php else: ?>
                            <?php foreach($achats_history as $a): ?>
                                <?php 
                                    $status_class = 'status-en_attente';
                                    if($a['statut'] == 'receptionnee') $status_class = 'status-livree';
                                    if($a['statut'] == 'annulee') $status_class = 'status-annulee';
                                ?>
                                <tr>
                                    <td style="padding-left: 30px;" class="font-mono">#ACH-<?= str_pad($a['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                    <td style="font-weight: 600;"><?= htmlspecialchars($a['fournisseur_nom']) ?></td>
                                    <td><?= (new DateTime($a['date_commande']))->format('d/m/Y') ?></td>
                                    <td><?= $a['nb_produits'] ?> articles</td>
                                    <td style="font-weight: 700;"><?= number_format($a['montant_total'], 2, ',', ' ') ?> €</td>
                                    <td><span class="status-badge <?= $status_class ?>"><?= ucfirst($a['statut']) ?></span></td>
                                    <td><a href="achat_detail.php?id=<?= $a['id'] ?>" class="btn-small btn-outline"><i class="fa-solid fa-eye"></i> Gérer</a></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

</body>
</html>