<?php
// admin/clients.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
$allowed = ['admin', 'administrateur', 'commercial', 'support'];
if (!in_array(strtolower($_SESSION['user_role']), $allowed)) { die("Accès refusé."); }

// 2. RÉCUPÉRATION DES CLIENTS
$sql = "SELECT * FROM clients ORDER BY nom ASC";
$clients = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Clients - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="admin-body">

    <div class="admin-layout grid-layout">
        <?php include 'admin_sidebar.php'; ?>

        <main class="main-content">
            
            <header class="top-bar">
                <h1>Base Clients</h1>
            </header>

            <div class="card" style="padding: 0; overflow: hidden;">
                <table class="apple-table">
                    <thead>
                        <tr>
                            <th style="padding-left: 30px;">ID</th>
                            <th>Nom Complet</th>
                            <th>Email</th>
                            <th>Adresse de Livraison</th>
                            <th>Inscrit le</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($clients as $cl): ?>
                            <tr>
                                <td style="padding-left: 30px;" class="font-mono">#<?= $cl['id'] ?></td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($cl['nom']) ?></td>
                                <td><a href="mailto:<?= htmlspecialchars($cl['email']) ?>"><?= htmlspecialchars($cl['email']) ?></a></td>
                                <td><small><?= nl2br(htmlspecialchars(substr($cl['adresse_livraison'] ?? '', 0, 50))) ?>...</small></td>
                                <td><?= isset($cl['date_creation']) ? (new DateTime($cl['date_creation']))->format('d/m/Y') : '-' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

</body>
</html>