<?php
// FICHIER : admin/nom_de_la_page.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...
$message = '';
$client_a_modifier = null;
// ... (le reste de votre code reste inchangé)

// ==============================================
// 1. GESTION DES ACTIONS POST (AJOUT/MODIFICATION/SUPPRESSION)
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Nettoyage des données
    $nom = htmlspecialchars(trim($_POST['nom'] ?? ''));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''));
    $telephone = htmlspecialchars(trim($_POST['telephone'] ?? ''));
    $adresse = htmlspecialchars(trim($_POST['adresse'] ?? ''));
    $ville = htmlspecialchars(trim($_POST['ville'] ?? ''));
    $code_postal = htmlspecialchars(trim($_POST['code_postal'] ?? ''));

    try {
        if ($action === 'ajouter') {
            if (empty($nom) || empty($email)) {
                throw new Exception("Le nom et l'email sont obligatoires.");
            }

            $sql = "INSERT INTO clients (nom, email, telephone, adresse, ville, code_postal, date_creation) 
                    VALUES (:nom, :email, :telephone, :adresse, :ville, :code_postal, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nom' => $nom,
                ':email' => $email,
                ':telephone' => $telephone,
                ':adresse' => $adresse,
                ':ville' => $ville,
                ':code_postal' => $code_postal
            ]);
            $message = "<div class='alert alert-success'>Client **{$nom}** ajouté avec succès.</div>";
            
        } elseif ($action === 'modifier') {
            $client_id = intval($_POST['id'] ?? 0);
            if ($client_id <= 0 || empty($nom) || empty($email)) {
                throw new Exception("ID client, nom ou email manquant pour la modification.");
            }

            $sql = "UPDATE clients SET nom = :nom, email = :email, telephone = :telephone, 
                    adresse = :adresse, ville = :ville, code_postal = :code_postal 
                    WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $client_id,
                ':nom' => $nom,
                ':email' => $email,
                ':telephone' => $telephone,
                ':adresse' => $adresse,
                ':ville' => $ville,
                ':code_postal' => $code_postal
            ]);
            $message = "<div class='alert alert-success'>Client **{$nom}** mis à jour avec succès.</div>";

        } elseif ($action === 'supprimer') {
            $client_id = intval($_POST['id'] ?? 0);
            if ($client_id <= 0) {
                throw new Exception("ID client manquant pour la suppression.");
            }

            $sql = "DELETE FROM clients WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':id' => $client_id]);
            $message = "<div class='alert alert-success'>Client ID **{$client_id}** supprimé.</div>";
        }

    } catch (Exception $e) {
        $message = "<div class='alert alert-danger'>Erreur : " . $e->getMessage() . "</div>";
    } catch (PDOException $e) {
        // Gérer les erreurs de clé étrangère (si le client a des commandes)
        if (strpos($e->getMessage(), 'Foreign key constraint fails') !== false) {
             $message = "<div class='alert alert-danger'>Erreur : Impossible de supprimer ce client car il est associé à des commandes existantes.</div>";
        } else {
             $message = "<div class='alert alert-danger'>Erreur base de données : " . $e->getMessage() . "</div>";
        }
    }
}

// ==============================================
// 2. GESTION DU MODE MODIFICATION (GET)
// ==============================================
if (isset($_GET['action']) && $_GET['action'] === 'edit') {
    $client_id = intval($_GET['id'] ?? 0);
    if ($client_id > 0) {
        try {
            $sql = "SELECT * FROM clients WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':id' => $client_id]);
            $client_a_modifier = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$client_a_modifier) {
                $message = "<div class='alert alert-warning'>Client non trouvé.</div>";
            }
        } catch (PDOException $e) {
            $message = "<div class='alert alert-danger'>Erreur de chargement du client : " . $e->getMessage() . "</div>";
        }
    }
}

// ==============================================
// 3. LECTURE : RÉCUPÉRATION DE LA LISTE DES CLIENTS
// ==============================================
try {
    $sql = "SELECT id, nom, email, telephone, ville, date_creation FROM clients ORDER BY nom ASC";
    $stmt = $pdo->query($sql);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement des clients : " . $e->getMessage() . "</div>";
    $clients = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion Clients</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>👤 Gestion des Clients</h1>
        
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="card mb-4">
            <h2><?= $client_a_modifier ? 'Modifier le Client #' . $client_a_modifier['id'] : 'Ajouter un Nouveau Client' ?></h2>
            <form action="clients.php" method="POST">
                
                <?php if ($client_a_modifier): ?>
                    <input type="hidden" name="action" value="modifier">
                    <input type="hidden" name="id" value="<?= $client_a_modifier['id'] ?>">
                <?php else: ?>
                    <input type="hidden" name="action" value="ajouter">
                <?php endif; ?>

                <div class="row-group">
                    <div>
                        <label for="nom">Nom du Client / Société <span class="required">*</span></label>
                        <input type="text" id="nom" name="nom" required 
                               value="<?= htmlspecialchars($client_a_modifier['nom'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="email">Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" required 
                               value="<?= htmlspecialchars($client_a_modifier['email'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="telephone">Téléphone</label>
                        <input type="text" id="telephone" name="telephone" 
                               value="<?= htmlspecialchars($client_a_modifier['telephone'] ?? '') ?>">
                    </div>
                </div>

                <div class="row-group">
                    <div style="flex: 2;">
                        <label for="adresse">Adresse complète</label>
                        <input type="text" id="adresse" name="adresse" 
                               value="<?= htmlspecialchars($client_a_modifier['adresse'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="ville">Ville</label>
                        <input type="text" id="ville" name="ville" 
                               value="<?= htmlspecialchars($client_a_modifier['ville'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="code_postal">Code Postal</label>
                        <input type="text" id="code_postal" name="code_postal" 
                               value="<?= htmlspecialchars($client_a_modifier['code_postal'] ?? '') ?>">
                    </div>
                </div>

                <button type="submit" class="btn btn-success">
                    <?= $client_a_modifier ? '💾 Enregistrer les Modifications' : '➕ Ajouter le Client' ?>
                </button>
                
                <?php if ($client_a_modifier): ?>
                    <a href="clients.php" class="btn btn-secondary">Annuler</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="card">
            <h2>Liste des Clients (<?= count($clients) ?>)</h2>
            <?php if (!empty($clients)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom / Société</th>
                            <th>Email</th>
                            <th>Téléphone</th>
                            <th>Ville</th>
                            <th>Membre depuis</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clients as $client): ?>
                        <tr>
                            <td>#<?= htmlspecialchars($client['id']) ?></td>
                            <td>**<?= htmlspecialchars($client['nom']) ?>**</td>
                            <td><?= htmlspecialchars($client['email']) ?></td>
                            <td><?= htmlspecialchars($client['telephone']) ?></td>
                            <td><?= htmlspecialchars($client['ville']) ?></td>
                            <td><?= date('d/m/Y', strtotime($client['date_creation'])) ?></td>
                            <td class="text-center">
                                <a href="clients.php?action=edit&id=<?= $client['id'] ?>" class="btn btn-edit btn-small">Modifier</a>
                                <form method="POST" action="clients.php" style="display:inline;" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce client ?');">
                                    <input type="hidden" name="action" value="supprimer">
                                    <input type="hidden" name="id" value="<?= $client['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucun client enregistré pour le moment.</p>
            <?php endif; ?>
        </div>
        
    </div>
</body>
</html>