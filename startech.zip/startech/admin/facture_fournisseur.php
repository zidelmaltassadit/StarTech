<?php
// admin/factures_fournisseur.php
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_once '../includes/facturation_fournisseur_functions.php';

require_admin();

$message = '';
const TVA_RATE = 0.20;

// ==============================================
// 0. PRÉ-CHARGEMENT : Fournisseurs et Commandes Achat
// ==============================================
try {
    // Récupérer les fournisseurs
    $sql_fournisseurs = "SELECT id, nom_entreprise FROM fournisseurs ORDER BY nom_entreprise ASC";
    $fournisseurs = $pdo->query($sql_fournisseurs)->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les commandes d'achat qui n'ont pas encore été facturées (pour la création)
    $sql_commandes = "
        SELECT ca.id, ca.total_ttc, f.nom_entreprise 
        FROM commandes_achat ca
        JOIN fournisseurs f ON ca.fournisseur_id = f.id
        LEFT JOIN factures_fournisseur ff ON ff.commande_achat_id = ca.id
        WHERE ff.id IS NULL AND ca.statut NOT IN ('brouillon', 'annulee')
        ORDER BY ca.id DESC";
    $commandes_non_facturees = $pdo->query($sql_commandes)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur de chargement des données de base : " . $e->getMessage() . "</div>";
}

// ==============================================
// 1. GESTION DES ACTIONS (POST) : Création / Paiement
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'ajouter_facture') {
            $commande_achat_id = intval($_POST['commande_achat_id'] ?? 0);
            $fournisseur_id = intval($_POST['fournisseur_id'] ?? 0);
            $reference = trim($_POST['reference_facture'] ?? '');
            $date_facture = $_POST['date_facture'] ?? date('Y-m-d');
            $date_echeance = $_POST['date_echeance'] ?? NULL;
            $total_ht = floatval($_POST['total_ht'] ?? 0);
            $total_ttc = $total_ht * (1 + TVA_RATE); // Assurez-vous que le calcul est cohérent
            
            if (empty($reference) || $fournisseur_id <= 0 || $total_ht <= 0) {
                throw new Exception("Référence, fournisseur ou montant HT manquant ou invalide.");
            }

            // Insertion de la facture
            $sql = "INSERT INTO factures_fournisseur 
                    (commande_achat_id, fournisseur_id, reference_facture, date_facture, date_echeance, total_ht, total_ttc, statut_paiement) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'en_attente')";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $commande_achat_id > 0 ? $commande_achat_id : NULL, 
                $fournisseur_id, 
                $reference, 
                $date_facture, 
                $date_echeance, 
                $total_ht, 
                $total_ttc
            ]);
            $facture_id = $pdo->lastInsertId();
            $message = "<div class='alert alert-success'>Facture Fournisseur **#{$facture_id}** (Ref: {$reference}) enregistrée.</div>";

        } elseif ($action === 'enregistrer_paiement') {
            $facture_id = intval($_POST['facture_id'] ?? 0);
            $montant = floatval($_POST['montant_paiement'] ?? 0);

            if ($facture_id <= 0 || $montant <= 0) {
                throw new Exception("ID de facture ou montant de paiement invalide.");
            }

            $nouveau_statut = enregistrer_paiement_facture_fournisseur($pdo, $facture_id, $montant);
            $message = "<div class='alert alert-success'>Paiement de **" . number_format($montant, 2, ',', ' ') . " €** enregistré pour la facture #{$facture_id}. Nouveau statut : " . ucfirst(str_replace('_', ' ', $nouveau_statut)) . ".</div>";

        } else {
            throw new Exception("Action POST non reconnue.");
        }
        
    } catch (Exception $e) {
        $message = "<div class='alert alert-danger'>Erreur : " . $e->getMessage() . "</div>";
    }
}

// ==============================================
// 2. LECTURE : Récupérer toutes les Factures Fournisseur
// ==============================================
$factures_list = [];
try {
    $sql_select = "
        SELECT ff.*, f.nom_entreprise, ca.id AS commande_id
        FROM factures_fournisseur ff
        JOIN fournisseurs f ON ff.fournisseur_id = f.id
        LEFT JOIN commandes_achat ca ON ff.commande_achat_id = ca.id
        ORDER BY ff.date_facture DESC, ff.id DESC";
    $factures_list = $pdo->query($sql_select)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur lors du chargement des factures fournisseur : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Factures Fournisseur</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
        .status-badge { padding: 3px 8px; border-radius: 4px; font-weight: bold; }
        .status-en_attente { background-color: #ffc107; color: #333; }
        .status-partiellement_payee { background-color: #007bff; color: #fff; }
        .status-payee { background-color: #28a745; color: #fff; }
        .status-en_retard { background-color: #dc3545; color: #fff; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>💸 Gestion des Factures Fournisseur</h1>
        
        <?php echo $message; ?>
        
        <div class="card mb-4">
            <h2>➕ Enregistrer une Facture Fournisseur</h2>
            <form action="factures_fournisseur.php" method="POST">
                <input type="hidden" name="action" value="ajouter_facture">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="fournisseur_id">Fournisseur <span class="required">*</span> :</label>
                        <select id="fournisseur_id" name="fournisseur_id" required onchange="updateFactureForm(this.value)">
                            <option value="">-- Sélectionner un fournisseur --</option>
                            <?php foreach ($fournisseurs as $f): ?>
                                <option value="<?= $f['id'] ?>">
                                    <?= htmlspecialchars($f['nom_entreprise']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="commande_achat_id">Basé sur Commande Achat (Optionnel) :</label>
                        <select id="commande_achat_id" name="commande_achat_id" onchange="loadCommandeData(this.value)">
                            <option value="">-- Sélectionner une Commande --</option>
                            <?php foreach ($commandes_non_facturees as $ca): ?>
                                <option value="<?= $ca['id'] ?>" data-ht="<?= $ca['total_ttc'] / (1 + TVA_RATE) ?>">
                                    #<?= $ca['id'] ?> (<?= htmlspecialchars($ca['nom_entreprise']) ?> - <?= number_format($ca['total_ttc'], 2, ',', ' ') ?> € TTC)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="reference_facture">Référence Facture Fournisseur <span class="required">*</span> :</label>
                        <input type="text" id="reference_facture" name="reference_facture" required>
                    </div>

                    <div class="form-group">
                        <label for="date_facture">Date Facture :</label>
                        <input type="date" id="date_facture" name="date_facture" value="<?= date('Y-m-d') ?>">
                    </div>

                    <div class="form-group">
                        <label for="total_ht">Montant HT <span class="required">*</span> :</label>
                        <input type="number" step="0.01" min="0.01" id="total_ht" name="total_ht" required>
                    </div>

                    <div class="form-group">
                        <label for="date_echeance">Date d'échéance (Paiement) :</label>
                        <input type="date" id="date_echeance" name="date_echeance">
                    </div>
                </div>

                <div class="form-group full-width" style="margin-top: 20px;">
                    <button type="submit" class="btn btn-success btn-large">💾 Enregistrer la Facture</button>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>Comptes Fournisseur (<?= count($factures_list) ?> Factures)</h2>
            <?php if (!empty($factures_list)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Référence</th>
                            <th>Fournisseur</th>
                            <th>Date Facture / Échéance</th>
                            <th>Total TTC</th>
                            <th>Solde Dû</th>
                            <th>Statut Paiement</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($factures_list as $ff): 
                            $solde_du = $ff['total_ttc'] - $ff['montant_paye'];
                            $montant_max_paiement = max(0, round($solde_du, 2));
                        ?>
                        <tr>
                            <td>#<?= htmlspecialchars($ff['id']) ?></td>
                            <td>**<?= htmlspecialchars($ff['reference_facture']) ?>** (CA #<?= $ff['commande_id'] ?? '-' ?>)</td>
                            <td><?= htmlspecialchars($ff['nom_entreprise']) ?></td>
                            <td><?= date('d/m/Y', strtotime($ff['date_facture'])) ?> / 
                                <span style="font-weight: bold; color: <?= ($solde_du > 0 && strtotime($ff['date_echeance']) < time()) ? '#dc3545' : 'inherit' ?>;">
                                    <?= !empty($ff['date_echeance']) ? date('d/m/Y', strtotime($ff['date_echeance'])) : 'N/A' ?>
                                </span>
                            </td>
                            <td class="text-right"><?= number_format($ff['total_ttc'], 2, ',', ' ') ?> €</td>
                            <td class="text-right" style="font-weight: bold; color: <?= $solde_du > 0 ? '#dc3545' : '#28a745' ?>">
                                <?= number_format($solde_du, 2, ',', ' ') ?> €
                            </td>
                            <td><span class="status-badge status-<?= strtolower($ff['statut_paiement']) ?>"><?= ucfirst(str_replace('_', ' ', $ff['statut_paiement'])) ?></span></td>
                            <td>
                                <?php if ($solde_du > 0): ?>
                                    <button class="btn btn-primary btn-small" onclick="showPaiementForm(<?= $ff['id'] ?>, <?= $montant_max_paiement ?>)">Payer</button>
                                <?php else: ?>
                                    <span class="btn btn-secondary btn-small">Soldée</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr id="paiement_form_<?= $ff['id'] ?>" style="display: none;">
                            <td colspan="8">
                                <form method="POST" action="factures_fournisseur.php" style="padding: 10px; background: #f8f9fa;">
                                    <input type="hidden" name="action" value="enregistrer_paiement">
                                    <input type="hidden" name="facture_id" value="<?= $ff['id'] ?>">
                                    <p><strong>Facture #<?= $ff['id'] ?> - Solde Dû : <?= number_format($solde_du, 2, ',', ' ') ?> €</strong></p>
                                    <div style="display: flex; gap: 10px; align-items: center;">
                                        <label for="montant_paiement_<?= $ff['id'] ?>">Montant du Paiement :</label>
                                        <input type="number" step="0.01" min="0.01" max="<?= $montant_max_paiement ?>" 
                                            id="montant_paiement_<?= $ff['id'] ?>" name="montant_paiement" 
                                            value="<?= $montant_max_paiement ?>" required style="width: 120px;">
                                        <button type="submit" class="btn btn-success btn-small">Enregistrer</button>
                                        <button type="button" class="btn btn-secondary btn-small" onclick="hidePaiementForm(<?= $ff['id'] ?>)">Annuler</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucune facture fournisseur n'est enregistrée.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        const TVA_RATE_JS = 0.20;
        
        function updateFactureForm(fournisseurId) {
            // Optionnel : peut être utilisé pour filtrer la liste des commandes achat (commande_achat_id)
            // afin de n'afficher que celles pour le fournisseur sélectionné.
            console.log("Fournisseur sélectionné : " + fournisseurId);
            // Pour l'instant, on n'applique pas de filtre dynamique pour simplifier.
        }

        function loadCommandeData(commandeId) {
            const select = document.getElementById('commande_achat_id');
            const selectedOption = select.options[select.selectedIndex];
            
            if (commandeId) {
                const totalTTC = parseFloat(selectedOption.getAttribute('data-ht')) || 0;
                
                // Calculer le HT à partir du TTC (car la colonne data-ht a été mal nommée dans le PHP : elle contient le total TTC !)
                // Si la colonne data-ht contient bien le HT, utilisez-le directement.
                // Assumons que 'data-ht' contient le total HT de la commande (même si l'ID est trompeur)
                const totalHT = parseFloat(selectedOption.getAttribute('data-ht')); 
                
                if (totalHT > 0) {
                    document.getElementById('total_ht').value = totalHT.toFixed(2);
                    // Déclenchez l'événement change/input si vous aviez un champ TTC calculé.
                }
            } else {
                document.getElementById('total_ht').value = 0.00.toFixed(2);
            }
        }
        
        function showPaiementForm(factureId, montantMax) {
            document.querySelectorAll('tr[id^="paiement_form_"]').forEach(row => {
                row.style.display = 'none'; // Cacher les autres formulaires
            });
            const formRow = document.getElementById('paiement_form_' + factureId);
            if (formRow) {
                formRow.style.display = 'table-row';
                // Mettre à jour et mettre le focus sur le champ de paiement
                const input = document.getElementById('montant_paiement_' + factureId);
                input.value = montantMax.toFixed(2);
                input.focus();
            }
        }
        
        function hidePaiementForm(factureId) {
            const formRow = document.getElementById('paiement_form_' + factureId);
            if (formRow) {
                formRow.style.display = 'none';
            }
        }

        window.onload = function() {
             // Si un message a été passé via l'URL après une redirection (success/error)
             const urlParams = new URLSearchParams(window.location.search);
             const urlMessage = urlParams.get('message');
             if (urlMessage) {
                 // Afficher le message (déjà fait par le PHP)
                 // Retirer le message de l'URL pour éviter la re-soumission si l'utilisateur rafraîchit
                 const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
                 history.replaceState({}, document.title, newUrl);
             }
        };

    </script>
</body>
</html>