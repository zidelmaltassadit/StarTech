<?php
// FICHIER : admin/nom_de_la_page.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...
$message = '';
$fournisseur_a_modifier = null;
$action = $_GET['action'] ?? 'read'; // Action par défaut : affichage (read)

// ==============================================
// 1. GESTION DES REQUÊTES POST (AJOUT/MODIFICATION/SUPPRESSION)
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_societe = trim($_POST['nom_societe'] ?? '');
    $contact_nom = trim($_POST['contact_nom'] ?? '');
    $contact_email = trim($_POST['contact_email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $adresse = trim($_POST['adresse'] ?? '');
    $fournisseur_id = $_POST['id'] ?? null;

    if (empty($nom_societe) || empty($contact_email)) {
        $message = "<div class='alert alert-danger'>Le nom de la société et l'email de contact sont obligatoires.</div>";
    } else {
        if (isset($_POST['add'])) {
            // --- C: Création (Ajouter un fournisseur)
            try {
                $sql = "INSERT INTO fournisseurs (nom_societe, contact_nom, contact_email, telephone, adresse) VALUES (:nom, :c_nom, :c_email, :tel, :addr)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':nom' => $nom_societe,
                    ':c_nom' => $contact_nom,
                    ':c_email' => $contact_email,
                    ':tel' => $telephone,
                    ':addr' => $adresse
                ]);
                $message = "<div class='alert alert-success'>Fournisseur **{$nom_societe}** ajouté avec succès.</div>";
                $action = 'read'; // Retour à la vue de liste
            } catch (PDOException $e) {
                if ($e->getCode() == '23000') {
                    $message = "<div class='alert alert-danger'>Erreur : Le nom de la société ou l'email existe déjà.</div>";
                } else {
                     $message = "<div class='alert alert-danger'>Erreur base de données : " . $e->getMessage() . "</div>";
                }
            }
        } elseif (isset($_POST['update']) && $fournisseur_id) {
            // --- U: Mise à jour (Modifier un fournisseur)
            try {
                $sql = "UPDATE fournisseurs SET nom_societe = :nom, contact_nom = :c_nom, contact_email = :c_email, telephone = :tel, adresse = :addr WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':nom' => $nom_societe,
                    ':c_nom' => $contact_nom,
                    ':c_email' => $contact_email,
                    ':tel' => $telephone,
                    ':addr' => $adresse,
                    ':id' => $fournisseur_id
                ]);
                $message = "<div class='alert alert-success'>Fournisseur **{$nom_societe}** mis à jour avec succès.</div>";
                $action = 'read';
            } catch (PDOException $e) {
                $message = "<div class='alert alert-danger'>Erreur lors de la mise à jour : " . $e->getMessage() . "</div>";
            }
        } elseif (isset($_POST['delete']) && $fournisseur_id) {
            // --- D: Suppression (Supprimer un fournisseur)
             try {
                // Avant de supprimer, vérifier s'il est lié à des produits ou commandes d'achat
                // (La FK ON DELETE RESTRICT dans la DB empêche cela, mais un message d'erreur est plus clair)
                $sql = "DELETE FROM fournisseurs WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':id' => $fournisseur_id]);
                $message = "<div class='alert alert-warning'>Fournisseur supprimé avec succès.</div>";
                $action = 'read';
            } catch (PDOException $e) {
                if ($e->getCode() == '23000') {
                    $message = "<div class='alert alert-danger'>Impossible de supprimer ce fournisseur car il est lié à des **produits** ou des **commandes d'achat**.</div>";
                } else {
                    $message = "<div class='alert alert-danger'>Erreur lors de la suppression : " . $e->getMessage() . "</div>";
                }
            }
        }
    }
}

// ==============================================
// 2. GESTION DES REQUÊTES GET (AFFICHAGE ET PRÉ-REMPLISSAGE POUR MODIFICATION)
// ==============================================

// --- U: Pré-remplissage pour modification
if ($action === 'edit' && isset($_GET['id'])) {
    try {
        $sql = "SELECT * FROM fournisseurs WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $_GET['id']]);
        $fournisseur_a_modifier = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$fournisseur_a_modifier) {
            $message = "<div class='alert alert-warning'>Fournisseur non trouvé.</div>";
            $action = 'read';
        }
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Erreur de récupération des données : " . $e->getMessage() . "</div>";
        $action = 'read';
    }
}

// --- R: Lecture (Récupérer tous les fournisseurs)
try {
    $sql_fournisseurs = "SELECT * FROM fournisseurs ORDER BY nom_societe ASC";
    $stmt_fournisseurs = $pdo->query($sql_fournisseurs);
    $fournisseurs = $stmt_fournisseurs->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur lors du chargement de la liste des fournisseurs : " . $e->getMessage() . "</div>";
    $fournisseurs = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Fournisseurs</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php include_once 'admin_header.php'; // Inclure l'en-tête de la zone admin (à créer) ?>

    <div class="container admin-container">
        <h1>🛠️ Gestion des Fournisseurs</h1>
        
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="card mb-4">
            <h2><?php echo ($action === 'edit' ? 'Modifier le Fournisseur' : 'Ajouter un Nouveau Fournisseur'); ?></h2>
            <form action="fournisseurs.php" method="POST">
                
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($fournisseur_a_modifier['id']) ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="nom_societe">Nom de la Société <span class="required">*</span> :</label>
                    <input type="text" id="nom_societe" name="nom_societe" required 
                           value="<?= htmlspecialchars($fournisseur_a_modifier['nom_societe'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="contact_email">Email de Contact <span class="required">*</span> :</label>
                    <input type="email" id="contact_email" name="contact_email" required 
                           value="<?= htmlspecialchars($fournisseur_a_modifier['contact_email'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="contact_nom">Nom du Contact :</label>
                    <input type="text" id="contact_nom" name="contact_nom" 
                           value="<?= htmlspecialchars($fournisseur_a_modifier['contact_nom'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="telephone">Téléphone :</label>
                    <input type="text" id="telephone" name="telephone" 
                           value="<?= htmlspecialchars($fournisseur_a_modifier['telephone'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="adresse">Adresse :</label>
                    <textarea id="adresse" name="adresse"><?= htmlspecialchars($fournisseur_a_modifier['adresse'] ?? '') ?></textarea>
                </div>

                <?php if ($action === 'edit'): ?>
                    <button type="submit" name="update" class="btn btn-primary">💾 Enregistrer les Modifications</button>
                    <a href="fournisseurs.php" class="btn btn-secondary">Annuler</a>
                <?php else: ?>
                    <button type="submit" name="add" class="btn btn-success">➕ Ajouter le Fournisseur</button>
                <?php endif; ?>
            </form>
        </div>
        
        <h2>Liste des Fournisseurs Actuels (<?= count($fournisseurs) ?>)</h2>
        
        <?php if (!empty($fournisseurs)): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Société</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Téléphone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($fournisseurs as $f): ?>
                    <tr>
                        <td><?= htmlspecialchars($f['id']) ?></td>
                        <td><?= htmlspecialchars($f['nom_societe']) ?></td>
                        <td><?= htmlspecialchars($f['contact_nom']) ?></td>
                        <td><?= htmlspecialchars($f['contact_email']) ?></td>
                        <td><?= htmlspecialchars($f['telephone']) ?></td>
                        <td>
                            <a href="fournisseurs.php?action=edit&id=<?= $f['id'] ?>" class="btn btn-edit">Modifier</a>
                            <form method="POST" action="fournisseurs.php" style="display:inline-block;" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce fournisseur ? Cette action est irréversible et peut être bloquée s\'il est lié à des produits.');">
                                <input type="hidden" name="id" value="<?= $f['id'] ?>">
                                <button type="submit" name="delete" class="btn btn-danger btn-small">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Aucun fournisseur n'a été enregistré pour le moment.</p>
        <?php endif; ?>

    </div>
</body>
</html>