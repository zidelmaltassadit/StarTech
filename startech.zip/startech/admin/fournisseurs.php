<?php
// admin/fournisseurs.php (VERSION CORRIGÉE AVEC BOUTON SUPPRIMER)
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
$allowed = ['admin', 'administrateur', 'logistique', 'achats'];
if (!in_array(strtolower($_SESSION['user_role']), $allowed)) { die("Accès refusé."); }

$message = '';

// --- NOUVEAU : TRAITEMENT DE LA SUPPRESSION ---
if (isset($_GET['delete'])) {
    $id_to_delete = (int)$_GET['delete'];
    try {
        // On supprime l'utilisateur.
        // Grâce à la configuration de la base de données (ON DELETE SET NULL), 
        // les produits liés ne seront pas supprimés, ils perdront juste leur fournisseur.
        $stmt_del = $pdo->prepare("DELETE FROM utilisateurs WHERE id = ? AND user_role = 'fournisseur'");
        $stmt_del->execute([$id_to_delete]);
        
        // Petite astuce : on redirige vers la même page pour "nettoyer" l'URL
        header("Location: fournisseurs.php?msg=deleted"); 
        exit;
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Erreur lors de la suppression : " . $e->getMessage() . "</div>";
    }
}

// Message de confirmation après suppression
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $message = "<div class='alert alert-success' style='color:green; margin-bottom:20px;'>Fournisseur supprimé avec succès.</div>";
}

// 2. TRAITEMENT DU FORMULAIRE D'AJOUT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_fournisseur'])) {
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    // Mot de passe par défaut : StarTech2025!
    $password = password_hash('StarTech2025!', PASSWORD_DEFAULT); 
    
    if (!empty($nom) && !empty($email)) {
        try {
            // On vérifie si l'email existe déjà
            $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ?");
            $stmt_check->execute([$email]);
            if ($stmt_check->fetchColumn() > 0) {
                 $message = "<div class='alert alert-danger' style='color:red; margin-bottom:20px;'>Cet email est déjà utilisé.</div>";
            } else {
                $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email, password_hash, user_role) VALUES (?, ?, ?, 'fournisseur')");
                $stmt->execute([$nom, $email, $password]);
                $message = "<div class='alert alert-success' style='color:green; margin-bottom:20px;'>Fournisseur ajouté avec succès. Mot de passe provisoire : <strong>StarTech2025!</strong></div>";
            }
        } catch (PDOException $e) {
            $message = "<div class='alert alert-danger' style='color:red; margin-bottom:20px;'>Erreur technique : " . $e->getMessage() . "</div>";
        }
    }
}

// 3. RÉCUPÉRATION DES FOURNISSEURS
$sql = "SELECT * FROM utilisateurs WHERE user_role = 'fournisseur' ORDER BY nom ASC";
$fournisseurs = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Fournisseurs - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="admin-body">

    <div class="admin-layout grid-layout">
        <?php include 'admin_sidebar.php'; ?>

        <main class="main-content">
            
            <header class="top-bar">
                <h1>Partenaires Fournisseurs</h1>
            </header>

            <?= $message ?>

            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
                
                <div class="card" style="padding: 0; overflow: hidden;">
                    <div class="section-header" style="padding: 25px; margin-bottom:0;">
                        <h2><i class="fa-solid fa-truck-ramp-box"></i> Liste des Fournisseurs</h2>
                    </div>
                    <table class="apple-table">
                        <thead>
                            <tr>
                                <th style="padding-left: 30px;">Nom de l'entreprise</th>
                                <th>Email de contact</th>
                                <th>Produits associés</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($fournisseurs as $f): ?>
                                <?php 
                                    // Compter les produits de ce fournisseur
                                    $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM produits WHERE fournisseur_id = ?");
                                    $stmt_count->execute([$f['id']]);
                                    $nb_prods = $stmt_count->fetchColumn();
                                ?>
                                <tr>
                                    <td style="padding-left: 30px; font-weight: 600;"><?= htmlspecialchars($f['nom']) ?></td>
                                    <td><a href="mailto:<?= htmlspecialchars($f['email']) ?>"><?= htmlspecialchars($f['email']) ?></a></td>
                                    <td><span class="badge-role" style="background:#F5F5F7; color:#1d1d1f;"><?= $nb_prods ?> produits</span></td>
                                    
                                    <td>
                                        <a href="fournisseurs.php?delete=<?= $f['id'] ?>" class="btn-small btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce fournisseur ? Ses produits seront détachés.');" title="Supprimer">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="card" style="background: #F5F5F7; border: 1px solid var(--border-color); position: sticky; top: 30px;">
                    <div class="section-header">
                        <h2><i class="fa-solid fa-user-plus"></i> Nouveau Fournisseur</h2>
                    </div>
                    <form method="post">
                        <div class="form-group">
                            <label class="form-label">Nom de l'entreprise / Contact</label>
                            <input type="text" name="nom" class="form-input" required placeholder="Ex: Logitech Pro">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email professionnel</label>
                            <input type="email" name="email" class="form-input" required placeholder="contact@fournisseur.com">
                        </div>
                        <button type="submit" name="add_fournisseur" class="btn btn-primary" style="width: 100%; padding: 12px;">
                            Créer le compte partenaire
                        </button>
                        <p style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 15px; text-align: center;">
                            Un mot de passe provisoire sera généré.
                        </p>
                    </form>
                </div>
            </div>

        </main>
    </div>

</body>
</html>