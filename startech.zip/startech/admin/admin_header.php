<?php
// Démarrer la session si elle n'est pas déjà active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Détermine la page actuelle pour l'onglet actif
$current_page = basename($_SERVER['PHP_SELF']);

// Initialisation sécurisée des variables pour l'affichage
$user_name = $_SESSION['user_name'] ?? 'Admin'; 
$user_role = $_SESSION['user_role'] ?? 'Non Défini';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech PGI - Administration</title>
    <link rel="stylesheet" href="../../assets/css/global.css"> 
</head>
<body class="admin"> 

<header class="admin-header">
    <div class="header-container">
        <div class="logo">
            <a href="dashboard.php">StarTech <strong>PGI</strong></a>
        </div>
        
        <nav class="main-nav">
            <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>">
                <span class="icon">🏠</span> Tableau de Bord
            </a>
            
            <a href="clients.php" class="<?= $current_page == 'clients.php' ? 'active' : '' ?>">
                <span class="icon">👤</span> Clients
            </a>
            
            <a href="fournisseurs.php" class="<?= $current_page == 'fournisseurs.php' ? 'active' : '' ?>">
                <span class="icon">🚚</span> Fournisseurs
            </a>
            
            <a href="produits.php" class="<?= $current_page == 'produits.php' ? 'active' : '' ?>">
                <span class="icon">📦</span> Produits & Stock
            </a>
            
            <a href="commandes_vente.php" class="<?= $current_page == 'commandes_vente.php' ? 'active' : '' ?>">
                <span class="icon">🛒</span> Ventes
            </a>
            
            <a href="achats.php" class="<?= $current_page == 'achats.php' ? 'active' : '' ?>">
                <span class="icon">🧾</span> Achats
            </a>
            
            <a href="facturation.php" class="<?= $current_page == 'facturation.php' ? 'active' : '' ?>">
                <span class="icon">💵</span> Facturation
            </a>
            
        </nav>
        
        <div class="user-info">
            <span class="user-name">👋 <?= htmlspecialchars($user_name) ?> (<?= htmlspecialchars($user_role) ?>)</span>
            
            <a href="../../logout.php" class="btn btn-danger btn-small btn-logout">Déconnexion</a>
        </div>
    </div>
</header>
<div class="container">