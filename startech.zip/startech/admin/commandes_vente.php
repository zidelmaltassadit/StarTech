<?php
// FICHIER : admin/commandes_vente.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...
$message = '';
$commandes = [];
$clients = [];
$produits = [];
$commande_a_modifier = null;
$details_commande = [];

// ==============================================
// 0. PRÉ-CHARGEMENT : Clients et Produits
// ==============================================
try {
    // Clients pour le select box
    $sql_clients = "SELECT id, nom, prenom, entreprise FROM clients ORDER BY nom ASC";
    $clients = $pdo->query($sql_clients)->fetchAll(PDO::FETCH_ASSOC);

    // Produits pour le select box
    // CORRECTION APPLIQUÉE : Suppression de la colonne 'quantite_stock' qui causait l'erreur UNKNOWN COLUMN.
    // Seuls id, nom, et prix_ht sont nécessaires ici.
    $sql_produits = "SELECT id, nom, prix_ht, unite_mesure FROM produits WHERE statut = 'actif'";
    $produits = $pdo->query($sql_produits)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Le message est affiché en haut de la page
    $message .= "<div class='alert alert-danger'>Erreur de chargement des données de base : " . $e->getMessage() . "</div>";
}

// ==============================================
// 2. GESTION DES ACTIONS (POST) : CRUD et SUPPRESSION
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    
    // --- GESTION DE LA SUPPRESSION (Doit être traité avant l'ajout/modification) ---
    if ($action === 'supprimer') {
        try {
            if ($id <= 0) throw new Exception("ID commande manquant.");
            
            $pdo->beginTransaction();
            // Suppression des détails puis de la commande
            $pdo->prepare("DELETE FROM commande_details WHERE commande_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM commandes WHERE id = ?")->execute([$id]);
            $pdo->commit();

            header("Location: commandes_vente.php?message=" . urlencode("<div class='alert alert-warning'>Commande #{$id} supprimée.</div>"));
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Erreur de suppression : " . $e->getMessage() . "</div>";
        }
    }

    // --- GESTION DE L'AJOUT/MODIFICATION ---
    if ($action === 'ajouter' || $action === 'modifier') {
        $client_id = intval($_POST['client_id'] ?? 0);
        $statut = $_POST['statut'] ?? 'brouillon';
        $date_livraison = $_POST['date_livraison'] ?? NULL;
        $lignes_produits = $_POST['produit_id'] ?? [];
        
        // Assurez-vous d'avoir au moins un client et une ligne
        if ($client_id <= 0) {
            $message = "<div class='alert alert-danger'>Veuillez sélectionner un client.</div>";
        } elseif (empty($lignes_produits)) {
            $message = "<div class='alert alert-danger'>Veuillez ajouter au moins un produit à la commande.</div>";
        } else {
            // Calcul du total global
            $total_ttc = 0;
            $total_ht = 0;
            $TVA_RATE = 0.20; // Utilisation d'une TVA fixe pour la démo

            $pdo->beginTransaction();
            try {
                // Calculer les totaux avant insertion
                $lignes_valides = [];
                foreach ($lignes_produits as $index => $produit_id) {
                    $quantite = intval($_POST['quantite'][$index] ?? 0);
                    $prix_unitaire_ht = floatval($_POST['prix_unitaire_ht'][$index] ?? 0);
                    
                    if ($produit_id > 0 && $quantite > 0 && $prix_unitaire_ht >= 0) {
                        $total_ligne_ht = $quantite * $prix_unitaire_ht;
                        $total_ligne_ttc = $total_ligne_ht * (1 + $TVA_RATE);
                        
                        $total_ht += $total_ligne_ht;
                        $total_ttc += $total_ligne_ttc;

                        $lignes_valides[] = [
                            'produit_id' => $produit_id,
                            'quantite' => $quantite,
                            'prix_unitaire_ht' => $prix_unitaire_ht,
                            'total_ligne_ht' => $total_ligne_ht
                        ];
                    }
                }

                if (empty($lignes_valides)) {
                    throw new Exception("Aucune ligne de produit valide trouvée.");
                }
                
                // --- INSERTION/MISE À JOUR DE L'EN-TÊTE ---
                if ($action === 'ajouter') {
                    $sql = "INSERT INTO commandes (client_id, statut, total_ht, total_ttc, date_livraison) 
                            VALUES (?, ?, ?, ?, ?)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$client_id, $statut, $total_ht, $total_ttc, $date_livraison]);
                    $commande_id = $pdo->lastInsertId();
                    $message = "<div class='alert alert-success'>Commande **#{$commande_id}** créée avec succès.</div>";
                } elseif ($action === 'modifier') {
                    $commande_id = $id;
                    $sql = "UPDATE commandes SET client_id = ?, statut = ?, total_ht = ?, total_ttc = ?, date_livraison = ? WHERE id = ?";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$client_id, $statut, $total_ht, $total_ttc, $date_livraison, $commande_id]);
                    
                    // Supprimer les anciennes lignes de détail avant de réinsérer
                    $pdo->prepare("DELETE FROM commande_details WHERE commande_id = ?")->execute([$commande_id]);
                    $message = "<div class='alert alert-success'>Commande **#{$commande_id}** mise à jour avec succès.</div>";
                } 
                
                // --- INSERTION DES DÉTAILS ---
                $sql_detail = "INSERT INTO commande_details (commande_id, produit_id, quantite, prix_unitaire_ht, total_ligne_ht) 
                                 VALUES (?, ?, ?, ?, ?)";
                $stmt_detail = $pdo->prepare($sql_detail);
                
                foreach ($lignes_valides as $ligne) {
                    $stmt_detail->execute([
                        $commande_id,
                        $ligne['produit_id'],
                        $ligne['quantite'],
                        $ligne['prix_unitaire_ht'],
                        $ligne['total_ligne_ht']
                    ]);
                }

                $pdo->commit();
                // Rediriger pour éviter la re-soumission du formulaire
                header("Location: commandes_vente.php?message=" . urlencode($message));
                exit;

            } catch (Exception $e) {
                $pdo->rollBack();
                $message = "<div class='alert alert-danger'>Erreur de transaction : " . $e->getMessage() . "</div>";
            }
        }
    }
}


// ==============================================
// 1. GESTION DU MODE MODIFICATION (GET)
// ==============================================
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
        // Récupérer l'en-tête de la commande
        $sql_cmd = "SELECT * FROM commandes WHERE id = ?";
        $stmt_cmd = $pdo->prepare($sql_cmd);
        $stmt_cmd->execute([$id]);
        $commande_a_modifier = $stmt_cmd->fetch(PDO::FETCH_ASSOC);

        // Récupérer les détails des lignes de commande
        $sql_details = "SELECT * FROM commande_details WHERE commande_id = ?";
        $stmt_details = $pdo->prepare($sql_details);
        $stmt_details->execute([$id]);
        $details_commande = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

        if (!$commande_a_modifier) {
            $message = "<div class='alert alert-danger'>Commande non trouvée.</div>";
        }
    }
}

// ==============================================
// 3. LECTURE : Récupérer toutes les commandes
// ==============================================
try {
    $sql_select = "
        SELECT c.*, cl.nom AS client_nom, cl.entreprise
        FROM commandes c
        JOIN clients cl ON c.client_id = cl.id
        ORDER BY c.id DESC";
    $stmt_select = $pdo->query($sql_select);
    $commandes = $stmt_select->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur lors du chargement des commandes : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Commandes de Vente</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>📦 Gestion des Commandes de Vente</h1>
        
        <?php 
        // Affiche le message après redirection GET
        if(isset($_GET['message'])) {
            echo urldecode($_GET['message']);
        } else {
            echo $message; 
        }
        ?>
        
        <div class="card mb-4">
            <h2><?= $commande_a_modifier ? 'Modifier Commande #' . $commande_a_modifier['id'] : 'Créer une Nouvelle Commande' ?></h2>
            <form action="commandes_vente.php" method="POST">
                <input type="hidden" name="action" value="<?= $commande_a_modifier ? 'modifier' : 'ajouter' ?>">
                <?php if ($commande_a_modifier): ?>
                    <input type="hidden" name="id" value="<?= $commande_a_modifier['id'] ?>">
                <?php endif; ?>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="client_id">Client <span class="required">*</span> :</label>
                        <select id="client_id" name="client_id" required>
                            <option value="">-- Sélectionner un client --</option>
                            <?php foreach ($clients as $clt): ?>
                                <option value="<?= $clt['id'] ?>"
                                    <?= (isset($commande_a_modifier['client_id']) && $commande_a_modifier['client_id'] == $clt['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($clt['nom'] . ' ' . $clt['prenom'] . (empty($clt['entreprise']) ? '' : ' (' . $clt['entreprise'] . ')')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="statut">Statut :</label>
                        <select id="statut" name="statut">
                            <?php 
                            $statuts = ['brouillon', 'en_attente', 'en_preparation', 'expediee', 'livre', 'annulee'];
                            $current_statut = $commande_a_modifier['statut'] ?? 'brouillon';
                            foreach ($statuts as $s): ?>
                                <option value="<?= $s ?>" <?= ($current_statut === $s) ? 'selected' : '' ?>>
                                    <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="date_livraison">Date de livraison prévue :</label>
                        <input type="date" id="date_livraison" name="date_livraison" 
                                value="<?= htmlspecialchars($commande_a_modifier['date_livraison'] ?? '') ?>">
                    </div>
                </div>
                
                <hr>

                <h3>Détails de la Commande</h3>
                <table class="data-table" id="detailsTable">
                    <thead>
                        <tr>
                            <th>Produit <span class="required">*</span></th>
                            <th>Quantité <span class="required">*</span></th>
                            <th>Prix U. HT</th>
                            <th>Total HT</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Afficher au moins une ligne si c'est une nouvelle commande
                        $lignes_a_afficher = empty($details_commande) ? [[]] : $details_commande;
                        
                        foreach ($lignes_a_afficher as $index => $detail): 
                            $default_product_id = $detail['produit_id'] ?? 0;
                            $default_qty = $detail['quantite'] ?? 1;
                            $default_price = $detail['prix_unitaire_ht'] ?? 0.00;
                            $total_ligne = $detail['total_ligne_ht'] ?? 0.00;
                        ?>
                        <tr class="detail-row">
                            <td>
                                <select name="produit_id[]" class="produit-select" required onchange="updateRowPrice(this)">
                                    <option value="">-- Sélectionner --</option>
                                    <?php foreach ($produits as $p): ?>
                                        <option value="<?= $p['id'] ?>" 
                                            data-prix="<?= $p['prix_ht'] ?>"
                                            <?= ($default_product_id == $p['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($p['nom'] . ' (' . number_format($p['prix_ht'] ?? 0, 2) . ' €)') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="quantite[]" value="<?= $default_qty ?>" min="1" required 
                                        class="qty-input" oninput="updateRow(this)">
                            </td>
                            <td>
                                <input type="number" step="0.01" name="prix_unitaire_ht[]" value="<?= number_format($default_price, 2, '.', '') ?>" min="0" required
                                        class="price-input" oninput="updateRow(this)">
                            </td>
                            <td class="total-ligne"><?= number_format($total_ligne, 2, ',', ' ') ?> €</td>
                            <td>
                                <button type="button" class="btn btn-danger btn-small" onclick="removeRow(this)">X</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right">Total HT :</td>
                            <td id="grandTotalHT" class="total-ht"><?= number_format($commande_a_modifier['total_ht'] ?? 0.00, 2, ',', ' ') ?> €</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="3" class="text-right">Total TTC (TVA 20%) :</td>
                            <td id="grandTotalTTC" class="total-ttc"><?= number_format($commande_a_modifier['total_ttc'] ?? 0.00, 2, ',', ' ') ?> €</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <button type="button" class="btn btn-secondary" onclick="addRow()">+ Ajouter une Ligne Produit</button>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <div class="form-group full-width" style="margin-top: 20px;">
                    <button type="submit" class="btn btn-success btn-large">
                        <?= $commande_a_modifier ? '💾 Enregistrer la Commande' : '➕ Créer la Commande' ?>
                    </button>
                    <?php if ($commande_a_modifier): ?>
                        <a href="commandes_vente.php" class="btn btn-secondary btn-large">Annuler</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        
        <div class="card">
            <h2>Historique des Commandes (<?= count($commandes) ?>)</h2>
            <?php if (!empty($commandes)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date Commande</th>
                            <th>Client</th>
                            <th>Statut</th>
                            <th>Total TTC</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($commandes as $cmd): ?>
                        <tr>
                            <td><?= htmlspecialchars($cmd['id']) ?></td>
                            <td><?= date('d/m/Y', strtotime($cmd['date_commande'])) ?></td>
                            <td>**<?= htmlspecialchars($cmd['client_nom'] . (empty($cmd['entreprise']) ? '' : ' (' . $cmd['entreprise'] . ')')) ?>**</td>
                            <td><span class="status-badge status-<?= strtolower($cmd['statut']) ?>"><?= ucfirst(str_replace('_', ' ', $cmd['statut'])) ?></span></td>
                            <td class="text-right"><?= number_format($cmd['total_ttc'], 2, ',', ' ') ?> €</td>
                            <td>
                                <a href="commandes_vente.php?action=edit&id=<?= $cmd['id'] ?>" class="btn btn-edit btn-small">Modifier</a>
                                <form method="POST" action="commandes_vente.php" style="display:inline;" onsubmit="return confirm('Voulez-vous vraiment supprimer la commande #<?= $cmd['id'] ?> ?');">
                                    <input type="hidden" name="action" value="supprimer">
                                    <input type="hidden" name="id" value="<?= $cmd['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucune commande n'est enregistrée pour le moment. Créez-en une ci-dessus.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        const TVA_RATE = 0.20;

        // Fonction pour ajouter une ligne produit
        function addRow() {
            const tableBody = document.querySelector('#detailsTable tbody');
            // Trouver la dernière ligne pour la cloner (si le tableau est non vide)
            const lastRow = tableBody.querySelector('.detail-row');
            if (!lastRow) return; // Ne pas ajouter si le tableau est vide (ne devrait pas arriver avec votre code)

            const newRow = lastRow.cloneNode(true);
            
            // Réinitialiser les valeurs de la nouvelle ligne
            newRow.querySelector('.produit-select').value = "";
            newRow.querySelector('.qty-input').value = 1;
            newRow.querySelector('.price-input').value = 0.00;
            newRow.querySelector('.total-ligne').textContent = '0,00 €';
            
            tableBody.appendChild(newRow);
            calculateGrandTotals();
        }

        // Fonction pour retirer une ligne produit
        function removeRow(button) {
            const tableBody = document.querySelector('#detailsTable tbody');
            // Empêche la suppression si c'est la seule ligne restante
            if (tableBody.querySelectorAll('.detail-row').length > 1) {
                button.closest('.detail-row').remove();
            } else {
                alert("La commande doit contenir au moins une ligne produit.");
                return;
            }
            calculateGrandTotals();
        }

        // Met à jour le prix unitaire quand on sélectionne un produit
        function updateRowPrice(select) {
            const row = select.closest('.detail-row');
            const selectedOption = select.options[select.selectedIndex];
            const priceInput = row.querySelector('.price-input');
            
            if (selectedOption.value) {
                // Assigne le prix du produit au champ d'entrée de prix
                // Utilisation de .getAttribute pour lire data-prix
                const dataPrice = selectedOption.getAttribute('data-prix');
                // S'assurer que dataPrice est un nombre avant toFixed
                priceInput.value = (parseFloat(dataPrice) || 0).toFixed(2);
            } else {
                 priceInput.value = 0.00;
            }
            updateRow(priceInput);
        }

        // Met à jour la ligne et les totaux quand une quantité ou un prix change
        function updateRow(input) {
            const row = input.closest('.detail-row');
            const qty = parseInt(row.querySelector('.qty-input').value) || 0;
            // Utilisation de parseFloat pour lire la valeur du champ de prix
            const priceHT = parseFloat(row.querySelector('.price-input').value) || 0;
            const totalHT = qty * priceHT;
            
            row.querySelector('.total-ligne').textContent = totalHT.toFixed(2).replace('.', ',') + ' €';
            calculateGrandTotals();
        }

        // Calcule le total HT et TTC de toute la commande
        function calculateGrandTotals() {
            let grandTotalHT = 0;
            
            document.querySelectorAll('#detailsTable tbody .detail-row').forEach(row => {
                const totalText = row.querySelector('.total-ligne').textContent.replace(' €', '').replace(',', '.');
                grandTotalHT += parseFloat(totalText) || 0;
            });

            const grandTotalTTC = grandTotalHT * (1 + TVA_RATE);

            document.getElementById('grandTotalHT').textContent = grandTotalHT.toFixed(2).replace('.', ',') + ' €';
            document.getElementById('grandTotalTTC').textContent = grandTotalTTC.toFixed(2).replace('.', ',') + ' €';
        }

        // Assurez-vous que les totaux sont calculés au chargement si on est en mode édition
        window.onload = function() {
            if (document.querySelector('.detail-row')) {
                 calculateGrandTotals();
            }
            
            // Écouteurs pour les changements initiaux
            document.querySelectorAll('.produit-select').forEach(select => {
                select.onchange = function() { updateRowPrice(this); };
            });
            document.querySelectorAll('.qty-input, .price-input').forEach(input => {
                input.oninput = function() { updateRow(this); };
            });
        };
    </script>
</body>
</html>