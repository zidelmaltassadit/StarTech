<?php

// --- ON RALLUME LES ERREURS ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ------------------------------

session_start();
// ... le reste du fichier ...
// admin/dashboard.php

require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';
require_once '../includes/functions.php';

// --- 1. SÉCURITÉ : VÉRIFICATION ADMIN ---
// On vérifie si on est connecté ET si on a un rôle interne
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }

// Liste des rôles autorisés dans le back-office
$allowed_roles = ['admin', 'administrateur', 'logistique', 'rh', 'production', 'commercial', 'comptabilite'];
$current_role = strtolower(trim($_SESSION['user_role']));

if (!in_array($current_role, $allowed_roles)) {
    // Si un client ou un fournisseur essaie de venir ici -> Dehors !
    $_SESSION['flash_message'] = "<div class='alert alert-danger'>Accès refusé. Espace réservé au personnel.</div>";
    header('Location: ../index.php'); exit;
}

// --- 2. RÉCUPÉRATION DES STATS (KPIs) ---

try {
    // A. Chiffre d'Affaires Total (Somme des commandes non annulées)
    $stmt = $pdo->query("SELECT SUM(montant_total) FROM commandes WHERE statut != 'annulee'");
    $ca_total = $stmt->fetchColumn() ?: 0; // Si null, vaut 0

    // B. Nombre de commandes
    $stmt = $pdo->query("SELECT COUNT(*) FROM commandes");
    $nb_commandes = $stmt->fetchColumn();

    // C. Nombre de clients
    $stmt = $pdo->query("SELECT COUNT(*) FROM clients");
    $nb_clients = $stmt->fetchColumn();

    // D. Produits en rupture (Stock faible, ex: < 5)
    $stmt = $pdo->query("SELECT COUNT(*) FROM produits WHERE quantite_stock < 5 AND statut = 'actif'");
    $nb_rupture = $stmt->fetchColumn();

    // E. Récupérer les 5 dernières commandes pour le tableau
    $sql_recent = "SELECT c.id, c.date_commande, cl.nom as client_nom, c.montant_total, c.statut 
                   FROM commandes c
                   JOIN clients cl ON c.client_id = cl.id
                   ORDER BY c.date_commande DESC LIMIT 5";
    $recent_orders = $pdo->query($sql_recent)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - StarTech PGI</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="admin-body">

    <div class="admin-layout grid-layout">
        
      <?php include 'admin_sidebar.php'; ?>

        <main class="main-content">
            
            <header class="top-bar">
                <h1>Vue d'ensemble</h1>
                <div class="date-display"><i class="fa-regular fa-calendar"></i> <?= date('d M Y') ?></div>
            </header>

            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="icon-box blue"><i class="fa-solid fa-wallet"></i></div>
                    <div class="kpi-info">
                        <h3>Chiffre d'Affaires Total</h3>
                        <p class="value"><?= number_format($ca_total, 2, ',', ' ') ?> €</p>
                    </div>
                </div>

                <div class="kpi-card">
                    <div class="icon-box purple"><i class="fa-solid fa-bag-shopping"></i></div>
                    <div class="kpi-info">
                        <h3>Total Commandes</h3>
                        <p class="value"><?= $nb_commandes ?></p>
                    </div>
                </div>

                <div class="kpi-card">
                    <div class="icon-box orange"><i class="fa-solid fa-users"></i></div>
                    <div class="kpi-info">
                        <h3>Clients Inscrits</h3>
                        <p class="value"><?= $nb_clients ?></p>
                    </div>
                </div>

                <div class="kpi-card">
                    <div class="icon-box red"><i class="fa-solid fa-triangle-exclamation"></i></div>
                    <div class="kpi-info">
                        <h3>Alertes Stock</h3>
                        <p class="value"><?= $nb_rupture ?></p>
                        <?php if($nb_rupture > 0): ?>
                            <span class="trend negative">Action requise</span>
                        <?php else: ?>
                            <span class="trend positive">Stock sain</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <section class="recent-section card">
                <div class="section-header">
                    <h2><i class="fa-solid fa-clock-rotate-left"></i> Dernières Commandes Clients</h2>
                    <a href="commandes.php" class="btn-link">Tout voir ></a>
                </div>

                <div class="table-container">
                    <table class="data-table apple-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Client</th>
                                <th>Date</th>
                                <th>Montant TTC</th>
                                <th>Statut</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($recent_orders)): ?>
                                <?php foreach($recent_orders as $order): ?>
                                <tr>
                                    <td class="font-mono">#<?= str_pad($order['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                    <td><strong><?= htmlspecialchars($order['client_nom']) ?></strong></td>
                                    <td><?= (new DateTime($order['date_commande']))->format('d/m/Y H:i') ?></td>
                                    <td style="font-weight:600;"><?= number_format($order['montant_total'], 2, ',', ' ') ?> €</td>
                                    <td><span class="status-badge status-<?= strtolower($order['statut']) ?>"><?= ucfirst($order['statut']) ?></span></td>
                                    <td><a href="commande_detail.php?id=<?= $order['id'] ?>" class="btn btn-small btn-outline">Gérer</a></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align:center; color:#86868b;">Aucune commande pour le moment.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </div>

</body>
</html>