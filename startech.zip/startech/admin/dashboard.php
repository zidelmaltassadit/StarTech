<?php
// FICHIER : admin/dashboard.php

session_start(); // Ligne 1 : Essentielle pour les sessions

// Ligne 4 : Le chemin est maintenant correct (remonte d'un dossier)
require_once '../includes/db_config.php'; 
require_once '../includes/auth_functions.php';

require_admin();

// ... le reste de votre code
$message = '';
$stats = [];
$commandes_recentes = [];
$achats_encours = [];
$alertes_stock = [];

try {
    // ==============================================
    // 1. STATISTIQUES CLÉS (KPIs)
    // ==============================================
    
    // 1.1 Commandes Vente
    $stats['total_commandes_vente'] = $pdo->query("SELECT COUNT(id) FROM commandes")->fetchColumn();
    $stats['commandes_en_attente'] = $pdo->query("SELECT COUNT(id) FROM commandes WHERE statut IN ('en_attente_paiement', 'en_cours_traitement', 'en_attente')")->fetchColumn();

    // 1.2 Commandes Achat
    $stats['achats_en_cours'] = $pdo->query("SELECT COUNT(id) FROM commandes_achat WHERE statut = 'en_cours'")->fetchColumn();

    // 1.3 Produits et Stock
    $stats['produits_actifs'] = $pdo->query("SELECT COUNT(id) FROM produits WHERE quantite_stock > 0")->fetchColumn();
    
    $stats['valeur_stock_ht'] = $pdo->query("SELECT SUM(quantite_stock * prix_achat_moyen) FROM produits")->fetchColumn();
    
    $stats['produits_alerte'] = $pdo->query("SELECT COUNT(id) FROM produits WHERE quantite_stock <= seuil_alerte")->fetchColumn();

    // 1.4 Chiffre d'Affaires (Simplifié : Total des commandes terminées/facturées)
    $stats['chiffre_affaire_ht'] = $pdo->query("SELECT SUM(total_ht) FROM commandes WHERE statut IN ('livree', 'facture', 'livré')")->fetchColumn();

    // ==============================================
    // 2. DONNÉES DÉTAILLÉES
    // ==============================================
    
    // 2.1 Commandes Vente Récentes (TOP 5)
    $sql_ventes = "
        SELECT
            c.id, c.date_commande, c.statut, c.total_ttc, cl.nom AS client_nom
        FROM
            commandes c
        JOIN
            clients cl ON c.client_id = cl.id
        ORDER BY
            c.date_commande DESC
        LIMIT 5
    ";
    $stmt_ventes = $pdo->query($sql_ventes);
    $commandes_recentes = $stmt_ventes->fetchAll(PDO::FETCH_ASSOC);

    // 2.2 Commandes Achat en Cours (TOP 5)
    $sql_achats = "
        SELECT
            ca.id, ca.date_commande, ca.statut, ca.date_livraison_prevue, f.nom AS fournisseur_nom
        FROM
            commandes_achat ca
        JOIN
            fournisseurs f ON ca.fournisseur_id = f.id
        WHERE
            ca.statut IN ('en_cours', 'en_attente_livraison')
        ORDER BY
            ca.date_commande DESC
        LIMIT 5
    ";
    $stmt_achats = $pdo->query($sql_achats);
    $achats_encours = $stmt_achats->fetchAll(PDO::FETCH_ASSOC);

    // 2.3 Alertes de Stock (TOP 5)
    $sql_stock_alertes = "
        SELECT
            id, nom, quantite_stock, seuil_alerte
        FROM
            produits
        WHERE
            quantite_stock <= seuil_alerte AND quantite_stock > 0
        ORDER BY
            quantite_stock ASC
        LIMIT 5
    ";
    $stmt_alertes = $pdo->query($sql_stock_alertes);
    $alertes_stock = $stmt_alertes->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur base de données : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css"> 
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>🏠 Tableau de Bord PGI StarTech</h1>
        
        <?php echo $message; // Affichage des messages de statut ?>

        <div class="kpi-grid mb-4">
             <div class="kpi-card bg-primary">
                 <h3>Chiffre d'Affaires HT (Facturé)</h3>
                 <p class="kpi-value"><?= number_format($stats['chiffre_affaire_ht'] ?? 0, 2, ',', ' ') ?> €</p>
                 <a href="facturation.php" class="kpi-link">Voir les Factures &rarr;</a>
             </div>

             <div class="kpi-card bg-info">
                 <h3>Ventes en Attente</h3>
                 <p class="kpi-value"><?= $stats['commandes_en_attente'] ?? 0 ?></p>
                 <a href="commandes_vente.php" class="kpi-link">Gérer les Commandes Vente &rarr;</a>
             </div>

             <div class="kpi-card bg-warning">
                 <h3>Achats en Cours</h3>
                 <p class="kpi-value"><?= $stats['achats_en_cours'] ?? 0 ?></p>
                 <a href="achats.php" class="kpi-link">Suivre les Commandes Achat &rarr;</a>
             </div>

             <div class="kpi-card bg-success">
                 <h3>Produits en Stock</h3>
                 <p class="kpi-value"><?= $stats['produits_actifs'] ?? 0 ?></p>
                 <a href="produits.php" class="kpi-link">Gérer le Stock &rarr;</a>
             </div>
            
             <div class="kpi-card bg-danger">
                 <h3>Alertes Stock</h3>
                 <p class="kpi-value"><?= $stats['produits_alerte'] ?? 0 ?></p>
                 <a href="produits.php?filter=alert" class="kpi-link">Voir les Produits à Réappro &rarr;</a>
             </div>
            
        </div>

        <div class="data-row-container mb-4">

            <div class="card data-column">
                <h2>📈 Commandes Vente Récentes</h2>
                <?php if (!empty($commandes_recentes)): ?>
                    <table class="data-table small-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Client</th>
                                <th>Date</th>
                                <th>Montant TTC</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($commandes_recentes as $cmd): ?>
                            <tr>
                                <td><a href="commande_detail.php?id=<?= $cmd['id'] ?>">#<?= htmlspecialchars($cmd['id']) ?></a></td>
                                <td><?= htmlspecialchars($cmd['client_nom']) ?></td>
                                <td><?= date('d/m/Y', strtotime($cmd['date_commande'])) ?></td>
                                <td class="text-right"><?= number_format($cmd['total_ttc'], 2, ',', ' ') ?> €</td>
                                <td><span class="status-badge status-<?= $cmd['statut'] ?>"><?= ucfirst(str_replace('_', ' ', $cmd['statut'])) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="alert alert-info">Aucune commande de vente récente.</p>
                <?php endif; ?>
                <a href="commandes_vente.php" class="btn btn-secondary btn-small mt-2">Toutes les Commandes Vente &rarr;</a>
            </div>
            
            <div class="card data-column">
                <h2>📦 Achats en Attente de Réception</h2>
                <?php if (!empty($achats_encours)): ?>
                    <table class="data-table small-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Fournisseur</th>
                                <th>Date Création</th>
                                <th>Livraison Prévue</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($achats_encours as $achat): ?>
                            <tr>
                                <td><a href="achat_detail.php?id=<?= $achat['id'] ?>">#<?= htmlspecialchars($achat['id']) ?></a></td>
                                <td><?= htmlspecialchars($achat['fournisseur_nom']) ?></td>
                                <td><?= date('d/m/Y', strtotime($achat['date_commande'])) ?></td> 
                                <td class="text-center text-warning"><?= date('d/m/Y', strtotime($achat['date_livraison_prevue'])) ?></td>
                                <td><span class="status-badge status-<?= $achat['statut'] ?>"><?= ucfirst(str_replace('_', ' ', $achat['statut'])) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="alert alert-success">Aucune commande d'achat en cours ou en attente.</p>
                <?php endif; ?>
                <a href="achats.php" class="btn btn-secondary btn-small mt-2">Toutes les Commandes Achat &rarr;</a>
            </div>

        </div>

        <div class="card mb-4">
            <h2>🚨 Alertes Stock Critiques</h2>
            <?php if (!empty($alertes_stock)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Produit</th>
                            <th>Stock Actuel</th>
                            <th>Seuil d'Alerte</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alertes_stock as $produit): ?>
                        <tr class="alert-row">
                            <td>#<?= htmlspecialchars($produit['id']) ?></td>
                            <td><a href="produit_detail.php?id=<?= $produit['id'] ?>"><?= htmlspecialchars($produit['nom']) ?></a></td>
                            <td class="text-center text-danger"><?= htmlspecialchars($produit['quantite_stock']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($produit['seuil_alerte']) ?></td>
                            <td>
                                <a href="achat_detail.php?add_product=<?= $produit['id'] ?>" class="btn btn-warning btn-small">Créer Achat</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-success">Aucune alerte de stock en cours. Stock OK !</p>
            <?php endif; ?>
        </div>
        
    </div>

</body>
</html>