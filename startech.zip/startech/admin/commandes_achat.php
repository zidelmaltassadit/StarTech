<?php
// FICHIER : admin/nom_de_la_page.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...
$message = '';
$commandes = [];
$fournisseurs = [];
$produits = [];
$commande_a_modifier = null;
$details_commande = [];

// Taux de TVA (simplifié)
const TVA_RATE = 0.20; 

// ==============================================
// 0. PRÉ-CHARGEMENT : Fournisseurs et Produits
// ==============================================
try {
    // Fournisseurs pour le select box
    $sql_fournisseurs = "SELECT id, nom_entreprise FROM fournisseurs ORDER BY nom_entreprise ASC";
    $fournisseurs = $pdo->query($sql_fournisseurs)->fetchAll(PDO::FETCH_ASSOC);

    // Produits pour le select box (nous n'utilisons pas le prix de vente ici)
    $sql_produits = "SELECT id, nom, prix_ht, stock FROM produits ORDER BY nom ASC";
    $produits = $pdo->query($sql_produits)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur de chargement des données de base : " . $e->getMessage() . "</div>";
}

// ==============================================
// 1. GESTION DU MODE MODIFICATION (GET)
// ==============================================
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
        // Récupérer l'en-tête de la commande
        $sql_cmd = "SELECT * FROM commandes_achat WHERE id = ?";
        $stmt_cmd = $pdo->prepare($sql_cmd);
        $stmt_cmd->execute([$id]);
        $commande_a_modifier = $stmt_cmd->fetch(PDO::FETCH_ASSOC);

        // Récupérer les détails des lignes de commande
        $sql_details = "SELECT * FROM commande_achat_details WHERE commande_achat_id = ?";
        $stmt_details = $pdo->prepare($sql_details);
        $stmt_details->execute([$id]);
        $details_commande = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

        if (!$commande_a_modifier) {
            $message = "<div class='alert alert-danger'>Commande d'achat non trouvée.</div>";
        }
    }
}

// ==============================================
// 2. GESTION DES ACTIONS (POST) : CRUD
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $fournisseur_id = intval($_POST['fournisseur_id'] ?? 0);
    $statut = $_POST['statut'] ?? 'brouillon';
    $statut_paiement = $_POST['statut_paiement'] ?? 'en_attente';
    $date_reception_prevue = $_POST['date_reception_prevue'] ?? NULL;
    $lignes_produits = $_POST['produit_id'] ?? [];
    
    // Assurez-vous d'avoir au moins un fournisseur et une ligne
    if ($fournisseur_id <= 0) {
        $message = "<div class='alert alert-danger'>Veuillez sélectionner un fournisseur.</div>";
    } elseif (empty($lignes_produits)) {
        $message = "<div class='alert alert-danger'>Veuillez ajouter au moins un produit à la commande.</div>";
    } else {

        $pdo->beginTransaction();
        try {
            $total_ttc = 0;
            $total_ht = 0;
            $lignes_valides = [];

            // Calcul et validation des lignes de détail
            foreach ($lignes_produits as $index => $produit_id) {
                $quantite = intval($_POST['quantite'][$index] ?? 0);
                $prix_unitaire_achat_ht = floatval($_POST['prix_unitaire_achat_ht'][$index] ?? 0);
                
                if ($produit_id > 0 && $quantite > 0 && $prix_unitaire_achat_ht >= 0) {
                    $total_ligne_ht = $quantite * $prix_unitaire_achat_ht;
                    $total_ligne_ttc = $total_ligne_ht * (1 + TVA_RATE);
                    
                    $total_ht += $total_ligne_ht;
                    $total_ttc += $total_ligne_ttc;

                    $lignes_valides[] = [
                        'produit_id' => $produit_id,
                        'quantite' => $quantite,
                        'prix_unitaire_achat_ht' => $prix_unitaire_achat_ht,
                        'total_ligne_ht' => $total_ligne_ht
                    ];
                }
            }

            if (empty($lignes_valides)) {
                throw new Exception("Aucune ligne de produit valide trouvée.");
            }
            
            // --- INSERTION/MISE À JOUR DE L'EN-TÊTE ---
            if ($action === 'ajouter') {
                $sql = "INSERT INTO commandes_achat (fournisseur_id, statut, statut_paiement, total_ht, total_ttc, date_reception_prevue) 
                        VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$fournisseur_id, $statut, $statut_paiement, $total_ht, $total_ttc, $date_reception_prevue]);
                $commande_id = $pdo->lastInsertId();
                $message = "<div class='alert alert-success'>Commande d'achat **#{$commande_id}** créée avec succès.</div>";
            } elseif ($action === 'modifier') {
                $commande_id = $id;
                $sql = "UPDATE commandes_achat SET fournisseur_id = ?, statut = ?, statut_paiement = ?, total_ht = ?, total_ttc = ?, date_reception_prevue = ? WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$fournisseur_id, $statut, $statut_paiement, $total_ht, $total_ttc, $date_reception_prevue, $commande_id]);
                
                // Supprimer les anciennes lignes de détail avant de réinsérer
                $pdo->prepare("DELETE FROM commande_achat_details WHERE commande_achat_id = ?")->execute([$commande_id]);
                $message = "<div class='alert alert-success'>Commande d'achat **#{$commande_id}** mise à jour avec succès.</div>";
            } else {
                throw new Exception("Action non reconnue.");
            }
            
            // --- INSERTION DES DÉTAILS ---
            $sql_detail = "INSERT INTO commande_achat_details (commande_achat_id, produit_id, quantite, prix_unitaire_achat_ht, total_ligne_ht) 
                           VALUES (?, ?, ?, ?, ?)";
            $stmt_detail = $pdo->prepare($sql_detail);
            
            foreach ($lignes_valides as $ligne) {
                $stmt_detail->execute([
                    $commande_id,
                    $ligne['produit_id'],
                    $ligne['quantite'],
                    $ligne['prix_unitaire_achat_ht'],
                    $ligne['total_ligne_ht']
                ]);
            }

            $pdo->commit();
            // Rediriger pour éviter la re-soumission du formulaire
            header("Location: commandes_achat.php?message=" . urlencode($message));
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Erreur de transaction : " . $e->getMessage() . "</div>";
        }
    }
}


// ==============================================
// 3. LECTURE : Récupérer toutes les commandes d'achat
// ==============================================
try {
    $sql_select = "
        SELECT ca.*, f.nom_entreprise
        FROM commandes_achat ca
        JOIN fournisseurs f ON ca.fournisseur_id = f.id
        ORDER BY ca.id DESC";
    $stmt_select = $pdo->query($sql_select);
    $commandes = $stmt_select->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur lors du chargement des commandes d'achat : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Commandes d'Achat</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        .form-grid-three { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .data-table tfoot .text-right { font-weight: bold; }
        .status-badge { padding: 3px 8px; border-radius: 4px; font-weight: bold; }
        .status-brouillon { background-color: #ffc107; color: #333; }
        .status-envoyee { background-color: #007bff; color: #fff; }
        .status-recue { background-color: #28a745; color: #fff; }
        .status-annulee { background-color: #dc3545; color: #fff; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>🛒 Gestion des Commandes d'Achat</h1>
        
        <?php 
        if(isset($_GET['message'])) {
            echo urldecode($_GET['message']);
        } else {
            echo $message; 
        }
        ?>
        
        <div class="card mb-4">
            <h2><?= $commande_a_modifier ? 'Modifier Commande d\'Achat #' . $commande_a_modifier['id'] : 'Créer une Nouvelle Commande d\'Achat' ?></h2>
            <form action="commandes_achat.php" method="POST">
                <input type="hidden" name="action" value="<?= $commande_a_modifier ? 'modifier' : 'ajouter' ?>">
                <?php if ($commande_a_modifier): ?>
                    <input type="hidden" name="id" value="<?= $commande_a_modifier['id'] ?>">
                <?php endif; ?>

                <div class="form-grid-three">
                    <div class="form-group">
                        <label for="fournisseur_id">Fournisseur <span class="required">*</span> :</label>
                        <select id="fournisseur_id" name="fournisseur_id" required>
                            <option value="">-- Sélectionner un fournisseur --</option>
                            <?php foreach ($fournisseurs as $f): ?>
                                <option value="<?= $f['id'] ?>"
                                    <?= (isset($commande_a_modifier['fournisseur_id']) && $commande_a_modifier['fournisseur_id'] == $f['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f['nom_entreprise']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="statut">Statut :</label>
                        <select id="statut" name="statut">
                            <?php 
                            $statuts = ['brouillon', 'envoyee', 'partiellement_recue', 'recue', 'annulee'];
                            $current_statut = $commande_a_modifier['statut'] ?? 'brouillon';
                            foreach ($statuts as $s): ?>
                                <option value="<?= $s ?>" <?= ($current_statut === $s) ? 'selected' : '' ?>>
                                    <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="date_reception_prevue">Date de réception prévue :</label>
                        <input type="date" id="date_reception_prevue" name="date_reception_prevue" 
                               value="<?= htmlspecialchars($commande_a_modifier['date_reception_prevue'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="statut_paiement">Statut Paiement :</label>
                        <select id="statut_paiement" name="statut_paiement">
                            <?php 
                            $statuts_paie = ['en_attente', 'paye', 'partiellement_paye'];
                            $current_statut_paie = $commande_a_modifier['statut_paiement'] ?? 'en_attente';
                            foreach ($statuts_paie as $s): ?>
                                <option value="<?= $s ?>" <?= ($current_statut_paie === $s) ? 'selected' : '' ?>>
                                    <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <hr>

                <h3>Détails de la Commande</h3>
                <table class="data-table" id="detailsTable">
                    <thead>
                        <tr>
                            <th>Produit <span class="required">*</span></th>
                            <th>Quantité Commandée <span class="required">*</span></th>
                            <th>Prix U. Achat HT</th>
                            <th>Total HT</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Afficher au moins une ligne si c'est une nouvelle commande
                        $lignes_a_afficher = empty($details_commande) ? [[]] : $details_commande;
                        
                        foreach ($lignes_a_afficher as $index => $detail): 
                            $default_product_id = $detail['produit_id'] ?? 0;
                            $default_qty = $detail['quantite'] ?? 1;
                            // Utilisation d'une colonne générique "prix_ht" pour initialiser l'achat si c'est une nouvelle ligne
                            $default_price = $detail['prix_unitaire_achat_ht'] ?? 0.00;
                            $total_ligne = $detail['total_ligne_ht'] ?? 0.00;
                        ?>
                        <tr class="detail-row">
                            <td>
                                <select name="produit_id[]" class="produit-select" required>
                                    <option value="">-- Sélectionner --</option>
                                    <?php foreach ($produits as $p): ?>
                                        <option value="<?= $p['id'] ?>" 
                                                <?= ($default_product_id == $p['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($p['nom']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="quantite[]" value="<?= $default_qty ?>" min="1" required 
                                       class="qty-input" oninput="updateRow(this)">
                            </td>
                            <td>
                                <input type="number" step="0.01" name="prix_unitaire_achat_ht[]" value="<?= number_format($default_price, 2, '.', '') ?>" min="0" required
                                       class="price-input" oninput="updateRow(this)">
                            </td>
                            <td class="total-ligne"><?= number_format($total_ligne, 2, ',', ' ') ?> €</td>
                            <td>
                                <button type="button" class="btn btn-danger btn-small" onclick="removeRow(this)">X</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right">Total HT :</td>
                            <td id="grandTotalHT" class="total-ht text-right"><?= number_format($commande_a_modifier['total_ht'] ?? 0.00, 2, ',', ' ') ?> €</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="3" class="text-right">Total TTC (TVA 20%) :</td>
                            <td id="grandTotalTTC" class="total-ttc text-right"><?= number_format($commande_a_modifier['total_ttc'] ?? 0.00, 2, ',', ' ') ?> €</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <button type="button" class="btn btn-secondary" onclick="addRow()">+ Ajouter une Ligne Produit</button>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <div class="form-group full-width" style="margin-top: 20px;">
                    <button type="submit" class="btn btn-success btn-large">
                        <?= $commande_a_modifier ? '💾 Enregistrer la Commande d\'Achat' : '➕ Créer la Commande d\'Achat' ?>
                    </button>
                    <?php if ($commande_a_modifier): ?>
                        <a href="commandes_achat.php" class="btn btn-secondary btn-large">Annuler</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        
        <div class="card">
            <h2>Historique des Commandes d'Achat (<?= count($commandes) ?>)</h2>
            <?php if (!empty($commandes)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date Commande</th>
                            <th>Fournisseur</th>
                            <th>Statut</th>
                            <th>Total TTC</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($commandes as $cmd): ?>
                        <tr>
                            <td><?= htmlspecialchars($cmd['id']) ?></td>
                            <td><?= date('d/m/Y', strtotime($cmd['date_commande'])) ?></td>
                            <td>**<?= htmlspecialchars($cmd['nom_entreprise']) ?>**</td>
                            <td><span class="status-badge status-<?= strtolower($cmd['statut']) ?>"><?= ucfirst(str_replace('_', ' ', $cmd['statut'])) ?></span></td>
                            <td class="text-right"><?= number_format($cmd['total_ttc'], 2, ',', ' ') ?> €</td>
                            <td>
                                <a href="commandes_achat.php?action=edit&id=<?= $cmd['id'] ?>" class="btn btn-edit btn-small">Modifier</a>
                                <form method="POST" action="commandes_achat.php" style="display:inline;" onsubmit="return confirm('Voulez-vous vraiment supprimer la commande d\'achat #<?= $cmd['id'] ?> ?');">
                                    <input type="hidden" name="action" value="supprimer">
                                    <input type="hidden" name="id" value="<?= $cmd['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucune commande d'achat n'est enregistrée pour le moment. Créez-en une ci-dessus.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        const TVA_RATE_JS = 0.20;

        function addRow() {
            const tableBody = document.querySelector('#detailsTable tbody');
            const rowCount = tableBody.querySelectorAll('.detail-row').length;
            
            // Si c'est la première ligne (pour le clonage), on prend la première, sinon on crée une ligne vide pour éviter les problèmes de duplication de 'selected'
            const firstRow = tableBody.querySelector('.detail-row');
            if (firstRow) {
                const newRow = firstRow.cloneNode(true);
            
                // Réinitialiser les valeurs de la nouvelle ligne
                newRow.querySelector('.produit-select').value = "";
                newRow.querySelector('.qty-input').value = 1;
                newRow.querySelector('.price-input').value = 0.00;
                newRow.querySelector('.total-ligne').textContent = '0,00 €';
            
                tableBody.appendChild(newRow);
            } else {
                 // Si le tableau est vide, le code de clonage est plus complexe. Pour l'instant, assurez-vous qu'une première ligne est toujours là.
                 alert("Le tableau de détail est vide. Rechargez la page ou ajoutez manuellement le HTML de base.");
                 return;
            }
            calculateGrandTotals();
        }

        function removeRow(button) {
            const tableBody = document.querySelector('#detailsTable tbody');
            if (tableBody.querySelectorAll('.detail-row').length > 1) {
                button.closest('.detail-row').remove();
            } else {
                alert("La commande doit contenir au moins une ligne produit.");
                return;
            }
            calculateGrandTotals();
        }

        function updateRow(input) {
            const row = input.closest('.detail-row');
            const qty = parseInt(row.querySelector('.qty-input').value) || 0;
            const priceHT = parseFloat(row.querySelector('.price-input').value) || 0;
            const totalHT = qty * priceHT;
            
            row.querySelector('.total-ligne').textContent = totalHT.toFixed(2).replace('.', ',') + ' €';
            calculateGrandTotals();
        }

        function calculateGrandTotals() {
            let grandTotalHT = 0;
            
            document.querySelectorAll('#detailsTable tbody .detail-row').forEach(row => {
                const totalText = row.querySelector('.total-ligne').textContent.replace(' €', '').replace(',', '.');
                grandTotalHT += parseFloat(totalText) || 0;
            });

            const grandTotalTTC = grandTotalHT * (1 + TVA_RATE_JS);

            document.getElementById('grandTotalHT').textContent = grandTotalHT.toFixed(2).replace('.', ',') + ' €';
            document.getElementById('grandTotalTTC').textContent = grandTotalTTC.toFixed(2).replace('.', ',') + ' €';
        }

        window.onload = function() {
            if (document.querySelector('.detail-row')) {
                 calculateGrandTotals();
            }
        };

        // GESTION DE LA SUPPRESSION (POST)
        <?php 
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'supprimer') {
            try {
                $id = intval($_POST['id'] ?? 0);
                if ($id <= 0) throw new Exception("ID commande manquant.");
                
                $pdo->beginTransaction();
                // Suppression des détails puis de la commande d'achat
                $pdo->prepare("DELETE FROM commande_achat_details WHERE commande_achat_id = ?")->execute([$id]);
                $pdo->prepare("DELETE FROM commandes_achat WHERE id = ?")->execute([$id]);
                $pdo->commit();

                header("Location: commandes_achat.php?message=" . urlencode("<div class='alert alert-warning'>Commande d'achat #{$id} supprimée.</div>"));
                exit;

            } catch (Exception $e) {
                $pdo->rollBack();
                $message = "<div class='alert alert-danger'>Erreur de suppression : " . $e->getMessage() . "</div>";
            }
        }
        ?>
    </script>
</body>
</html>