<?php
// FICHIER : admin/nom_de_la_page.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...

// Le reste du code de votre page commence ici...
// ...
$message = '';
$devis_list = [];
$clients = [];
$produits = [];
$devis_a_modifier = null;
$details_devis = [];

// Taux de TVA (simplifié)
const TVA_RATE = 0.20; 

// ==============================================
// 0. PRÉ-CHARGEMENT : Clients et Produits
// ==============================================
try {
    // Clients pour le select box
    $sql_clients = "SELECT id, nom, prenom, entreprise FROM clients ORDER BY nom ASC";
    $clients = $pdo->query($sql_clients)->fetchAll(PDO::FETCH_ASSOC);

    // Produits pour le select box
    $sql_produits = "SELECT id, nom, prix_ht, stock FROM produits ORDER BY nom ASC";
    $produits = $pdo->query($sql_produits)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur de chargement des données de base : " . $e->getMessage() . "</div>";
}

// ==============================================
// 1. GESTION DU MODE MODIFICATION (GET)
// ==============================================
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($id > 0) {
        // Récupérer l'en-tête du devis
        $sql_dvs = "SELECT * FROM devis WHERE id = ?";
        $stmt_dvs = $pdo->prepare($sql_dvs);
        $stmt_dvs->execute([$id]);
        $devis_a_modifier = $stmt_dvs->fetch(PDO::FETCH_ASSOC);

        // Récupérer les détails des lignes de devis
        $sql_details = "SELECT * FROM devis_details WHERE devis_id = ?";
        $stmt_details = $pdo->prepare($sql_details);
        $stmt_details->execute([$id]);
        $details_devis = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

        if (!$devis_a_modifier) {
            $message = "<div class='alert alert-danger'>Devis non trouvé.</div>";
        }
    }
}

// ==============================================
// 2. GESTION DES ACTIONS (POST) : CRUD
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $client_id = intval($_POST['client_id'] ?? 0);
    $statut = $_POST['statut'] ?? 'brouillon';
    $date_validite = $_POST['date_validite'] ?? NULL;
    $lignes_produits = $_POST['produit_id'] ?? [];
    
    // Assurez-vous d'avoir au moins un client et une ligne
    if ($client_id <= 0) {
        $message = "<div class='alert alert-danger'>Veuillez sélectionner un client.</div>";
    } elseif (empty($lignes_produits)) {
        $message = "<div class='alert alert-danger'>Veuillez ajouter au moins un produit au devis.</div>";
    } else {

        $pdo->beginTransaction();
        try {
            $total_ttc = 0;
            $total_ht = 0;
            $lignes_valides = [];

            // Calcul et validation des lignes de détail
            foreach ($lignes_produits as $index => $produit_id) {
                $quantite = intval($_POST['quantite'][$index] ?? 0);
                $prix_unitaire_ht = floatval($_POST['prix_unitaire_ht'][$index] ?? 0);
                
                if ($produit_id > 0 && $quantite > 0 && $prix_unitaire_ht >= 0) {
                    $total_ligne_ht = $quantite * $prix_unitaire_ht;
                    $total_ligne_ttc = $total_ligne_ht * (1 + TVA_RATE);
                    
                    $total_ht += $total_ligne_ht;
                    $total_ttc += $total_ligne_ttc;

                    $lignes_valides[] = [
                        'produit_id' => $produit_id,
                        'quantite' => $quantite,
                        'prix_unitaire_ht' => $prix_unitaire_ht,
                        'total_ligne_ht' => $total_ligne_ht
                    ];
                }
            }

            if (empty($lignes_valides)) {
                throw new Exception("Aucune ligne de produit valide trouvée.");
            }
            
            // --- INSERTION/MISE À JOUR DE L'EN-TÊTE ---
            if ($action === 'ajouter') {
                $sql = "INSERT INTO devis (client_id, statut, total_ht, total_ttc, date_validite) 
                        VALUES (?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$client_id, $statut, $total_ht, $total_ttc, $date_validite]);
                $devis_id = $pdo->lastInsertId();
                $message = "<div class='alert alert-success'>Devis **#{$devis_id}** créé avec succès.</div>";
            } elseif ($action === 'modifier') {
                $devis_id = $id;
                $sql = "UPDATE devis SET client_id = ?, statut = ?, total_ht = ?, total_ttc = ?, date_validite = ? WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$client_id, $statut, $total_ht, $total_ttc, $date_validite, $devis_id]);
                
                // Supprimer les anciennes lignes de détail avant de réinsérer
                $pdo->prepare("DELETE FROM devis_details WHERE devis_id = ?")->execute([$devis_id]);
                $message = "<div class='alert alert-success'>Devis **#{$devis_id}** mis à jour avec succès.</div>";
            } elseif ($action === 'supprimer') {
                 // Géré en bas via la redirection après suppression
            } else {
                throw new Exception("Action non reconnue.");
            }
            
            // --- INSERTION DES DÉTAILS ---
            if ($action === 'ajouter' || $action === 'modifier') {
                $sql_detail = "INSERT INTO devis_details (devis_id, produit_id, quantite, prix_unitaire_ht, total_ligne_ht) 
                            VALUES (?, ?, ?, ?, ?)";
                $stmt_detail = $pdo->prepare($sql_detail);
                
                foreach ($lignes_valides as $ligne) {
                    $stmt_detail->execute([
                        $devis_id,
                        $ligne['produit_id'],
                        $ligne['quantite'],
                        $ligne['prix_unitaire_ht'],
                        $ligne['total_ligne_ht']
                    ]);
                }
            }
            
            $pdo->commit();
            // Rediriger pour éviter la re-soumission du formulaire
            header("Location: devis.php?message=" . urlencode($message));
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Erreur de transaction : " . $e->getMessage() . "</div>";
        }
    }
}


// ==============================================
// 3. LECTURE : Récupérer tous les devis
// ==============================================
try {
    $sql_select = "
        SELECT d.*, cl.nom AS client_nom, cl.entreprise
        FROM devis d
        JOIN clients cl ON d.client_id = cl.id
        ORDER BY d.id DESC";
    $stmt_select = $pdo->query($sql_select);
    $devis_list = $stmt_select->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur lors du chargement des devis : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Gestion des Devis</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        .status-badge.status-brouillon { background-color: #ffc107; color: #333; }
        .status-badge.status-envoye { background-color: #007bff; color: #fff; }
        .status-badge.status-accepte { background-color: #28a745; color: #fff; }
        .status-badge.status-refuse { background-color: #dc3545; color: #fff; }
        .status-badge.status-converti { background-color: #6f42c1; color: #fff; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>📝 Gestion des Devis Clients</h1>
        
        <?php 
        // Affiche le message après redirection GET
        if(isset($_GET['message'])) {
            echo urldecode($_GET['message']);
        } else {
            echo $message; 
        }
        ?>
        
        <div class="card mb-4">
            <h2><?= $devis_a_modifier ? 'Modifier Devis #' . $devis_a_modifier['id'] : 'Créer un Nouveau Devis' ?></h2>
            <form action="devis.php" method="POST">
                <input type="hidden" name="action" value="<?= $devis_a_modifier ? 'modifier' : 'ajouter' ?>">
                <?php if ($devis_a_modifier): ?>
                    <input type="hidden" name="id" value="<?= $devis_a_modifier['id'] ?>">
                <?php endif; ?>

                <div class="form-grid">
                    <div class="form-group">
                        <label for="client_id">Client <span class="required">*</span> :</label>
                        <select id="client_id" name="client_id" required>
                            <option value="">-- Sélectionner un client --</option>
                            <?php foreach ($clients as $clt): ?>
                                <option value="<?= $clt['id'] ?>"
                                    <?= (isset($devis_a_modifier['client_id']) && $devis_a_modifier['client_id'] == $clt['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($clt['nom'] . ' ' . $clt['prenom'] . (empty($clt['entreprise']) ? '' : ' (' . $clt['entreprise'] . ')')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="statut">Statut :</label>
                        <select id="statut" name="statut">
                            <?php 
                            $statuts = ['brouillon', 'envoye', 'accepte', 'refuse', 'converti'];
                            $current_statut = $devis_a_modifier['statut'] ?? 'brouillon';
                            foreach ($statuts as $s): ?>
                                <option value="<?= $s ?>" <?= ($current_statut === $s) ? 'selected' : '' ?>>
                                    <?= ucfirst(str_replace('_', ' ', $s)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="date_validite">Date de validité :</label>
                        <input type="date" id="date_validite" name="date_validite" 
                               value="<?= htmlspecialchars($devis_a_modifier['date_validite'] ?? '') ?>">
                    </div>
                </div>
                
                <hr>

                <h3>Détails du Devis</h3>
                <table class="data-table" id="detailsTable">
                    <thead>
                        <tr>
                            <th>Produit <span class="required">*</span></th>
                            <th>Quantité <span class="required">*</span></th>
                            <th>Prix U. HT</th>
                            <th>Total HT</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $lignes_a_afficher = empty($details_devis) ? [[]] : $details_devis;
                        
                        foreach ($lignes_a_afficher as $index => $detail): 
                            $default_product_id = $detail['produit_id'] ?? 0;
                            $default_qty = $detail['quantite'] ?? 1;
                            $default_price = $detail['prix_unitaire_ht'] ?? 0.00;
                            $total_ligne = $detail['total_ligne_ht'] ?? 0.00;
                        ?>
                        <tr class="detail-row">
                            <td>
                                <select name="produit_id[]" class="produit-select" required onchange="updateRowPrice(this)">
                                    <option value="">-- Sélectionner --</option>
                                    <?php foreach ($produits as $p): ?>
                                        <option value="<?= $p['id'] ?>" 
                                                data-prix="<?= $p['prix_ht'] ?>"
                                                <?= ($default_product_id == $p['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($p['nom'] . ' (' . number_format($p['prix_ht'], 2) . ' €)') ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="quantite[]" value="<?= $default_qty ?>" min="1" required 
                                       class="qty-input" oninput="updateRow(this)">
                            </td>
                            <td>
                                <input type="number" step="0.01" name="prix_unitaire_ht[]" value="<?= number_format($default_price, 2, '.', '') ?>" min="0" required
                                       class="price-input" oninput="updateRow(this)">
                            </td>
                            <td class="total-ligne text-right"><?= number_format($total_ligne, 2, ',', ' ') ?> €</td>
                            <td>
                                <button type="button" class="btn btn-danger btn-small" onclick="removeRow(this)">X</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right">Total HT :</td>
                            <td id="grandTotalHT" class="total-ht text-right"><?= number_format($devis_a_modifier['total_ht'] ?? 0.00, 2, ',', ' ') ?> €</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="3" class="text-right">Total TTC (TVA 20%) :</td>
                            <td id="grandTotalTTC" class="total-ttc text-right"><?= number_format($devis_a_modifier['total_ttc'] ?? 0.00, 2, ',', ' ') ?> €</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <button type="button" class="btn btn-secondary" onclick="addRow()">+ Ajouter une Ligne Produit</button>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <div class="form-group full-width" style="margin-top: 20px;">
                    <button type="submit" class="btn btn-success btn-large">
                        <?= $devis_a_modifier ? '💾 Enregistrer le Devis' : '➕ Créer le Devis' ?>
                    </button>
                    <?php if ($devis_a_modifier): ?>
                        <a href="devis.php" class="btn btn-secondary btn-large">Annuler</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        
        <div class="card">
            <h2>Historique des Devis (<?= count($devis_list) ?>)</h2>
            <?php if (!empty($devis_list)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date Devis</th>
                            <th>Client</th>
                            <th>Validité</th>
                            <th>Statut</th>
                            <th>Total TTC</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($devis_list as $d): ?>
                        <tr>
                            <td><?= htmlspecialchars($d['id']) ?></td>
                            <td><?= date('d/m/Y', strtotime($d['date_devis'])) ?></td>
                            <td>**<?= htmlspecialchars($d['client_nom'] . (empty($d['entreprise']) ? '' : ' (' . $d['entreprise'] . ')')) ?>**</td>
                            <td><?= !empty($d['date_validite']) ? date('d/m/Y', strtotime($d['date_validite'])) : 'N/A' ?></td>
                            <td><span class="status-badge status-<?= strtolower($d['statut']) ?>"><?= ucfirst(str_replace('_', ' ', $d['statut'])) ?></span></td>
                            <td class="text-right"><?= number_format($d['total_ttc'], 2, ',', ' ') ?> €</td>
                            <td>
                                <a href="devis.php?action=edit&id=<?= $d['id'] ?>" class="btn btn-edit btn-small">Modifier</a>
                                <?php if ($d['statut'] === 'accepte'): ?>
                                    <a href="convertir_commande.php?devis_id=<?= $d['id'] ?>" class="btn btn-info btn-small">Convertir</a>
                                <?php endif; ?>
                                <form method="POST" action="devis.php" style="display:inline;" onsubmit="return confirm('Voulez-vous vraiment supprimer le devis #<?= $d['id'] ?> ?');">
                                    <input type="hidden" name="action" value="supprimer">
                                    <input type="hidden" name="id" value="<?= $d['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-info">Aucun devis n'est enregistré pour le moment. Créez-en un ci-dessus.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        const TVA_RATE_JS = 0.20;

        // Fonction pour ajouter une ligne produit (copié de commandes_vente.php)
        function addRow() {
            const tableBody = document.querySelector('#detailsTable tbody');
            const newRow = tableBody.querySelector('.detail-row').cloneNode(true);
            
            newRow.querySelector('.produit-select').value = "";
            newRow.querySelector('.qty-input').value = 1;
            newRow.querySelector('.price-input').value = 0.00;
            newRow.querySelector('.total-ligne').textContent = '0,00 €';
            
            tableBody.appendChild(newRow);
            calculateGrandTotals();
        }

        // Fonction pour retirer une ligne produit
        function removeRow(button) {
            const tableBody = document.querySelector('#detailsTable tbody');
            if (tableBody.querySelectorAll('.detail-row').length > 1) {
                button.closest('.detail-row').remove();
            } else {
                alert("Le devis doit contenir au moins une ligne produit.");
                return;
            }
            calculateGrandTotals();
        }

        // Met à jour le prix unitaire quand on sélectionne un produit
        function updateRowPrice(select) {
            const row = select.closest('.detail-row');
            const selectedOption = select.options[select.selectedIndex];
            const priceInput = row.querySelector('.price-input');
            
            if (selectedOption.value) {
                // Assigne le prix du produit au champ d'entrée de prix
                priceInput.value = parseFloat(selectedOption.getAttribute('data-prix')).toFixed(2);
            } else {
                 priceInput.value = 0.00;
            }
            updateRow(priceInput);
        }

        // Met à jour la ligne et les totaux quand une quantité ou un prix change
        function updateRow(input) {
            const row = input.closest('.detail-row');
            const qty = parseInt(row.querySelector('.qty-input').value) || 0;
            const priceHT = parseFloat(row.querySelector('.price-input').value) || 0;
            const totalHT = qty * priceHT;
            
            row.querySelector('.total-ligne').textContent = totalHT.toFixed(2).replace('.', ',') + ' €';
            calculateGrandTotals();
        }

        // Calcule le total HT et TTC de toute la commande
        function calculateGrandTotals() {
            let grandTotalHT = 0;
            
            document.querySelectorAll('#detailsTable tbody .detail-row').forEach(row => {
                const totalText = row.querySelector('.total-ligne').textContent.replace(' €', '').replace(',', '.');
                grandTotalHT += parseFloat(totalText) || 0;
            });

            const grandTotalTTC = grandTotalHT * (1 + TVA_RATE_JS);

            document.getElementById('grandTotalHT').textContent = grandTotalHT.toFixed(2).replace('.', ',') + ' €';
            document.getElementById('grandTotalTTC').textContent = grandTotalTTC.toFixed(2).replace('.', ',') + ' €';
        }

        // Assurez-vous que les totaux sont calculés au chargement si on est en mode édition
        window.onload = function() {
            if (document.querySelector('.detail-row')) {
                 calculateGrandTotals();
            }
        };

        // GESTION DE LA SUPPRESSION (POST)
        <?php 
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'supprimer') {
            try {
                $id = intval($_POST['id'] ?? 0);
                if ($id <= 0) throw new Exception("ID devis manquant.");
                
                $pdo->beginTransaction();
                // Suppression des détails puis du devis
                $pdo->prepare("DELETE FROM devis_details WHERE devis_id = ?")->execute([$id]);
                $pdo->prepare("DELETE FROM devis WHERE id = ?")->execute([$id]);
                $pdo->commit();

                header("Location: devis.php?message=" . urlencode("<div class='alert alert-warning'>Devis #{$id} supprimé.</div>"));
                exit;

            } catch (Exception $e) {
                $pdo->rollBack();
                $message = "<div class='alert alert-danger'>Erreur de suppression : " . $e->getMessage() . "</div>";
            }
        }
        ?>
    </script>
</body>
</html>