<?php
// ==========================================================
// FICHIER : admin/fournisseur_dashboard.php
// ESPACE DÉDIÉ AUX FOURNISSEURS (Accès Restreint)
// ==========================================================
session_start();

// Inclure les fichiers de configuration
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- SÉCURITÉ : Exige l'accès FOURNISSEUR
require_fournisseur(); 

$message = '';
$alertes_stock = [];

try {
    // Le fournisseur n'a accès qu'à la liste des produits qu'il doit réapprovisionner.

    // 1. Récupération des Alertes de Stock (Tous fournisseurs)
    $sql_stock_alertes = "
        SELECT
            p.id, p.nom, p.quantite_stock, p.seuil_alerte, f.nom AS fournisseur_nom, f.id AS fournisseur_id
        FROM
            produits p
        JOIN
            fournisseurs f ON p.fournisseur_id = f.id
        WHERE
            p.quantite_stock <= p.seuil_alerte 
        ORDER BY
            p.quantite_stock ASC
    ";
    
    $stmt_alertes = $pdo->query($sql_stock_alertes);
    $tous_alertes = $stmt_alertes->fetchAll(PDO::FETCH_ASSOC);

    // 2. Filtrage pour n'afficher que les alertes du fournisseur connecté
    // Assurez-vous que l'ID du fournisseur est stocké dans $_SESSION['fournisseur_id'] lors de la connexion
    // Nous utiliserons l'ID de l'utilisateur connecté s'il est un fournisseur.
    $fournisseur_id_connecte = $_SESSION['user_id'] ?? null; 

    // Filtrer si l'ID fournisseur est disponible
    if ($fournisseur_id_connecte) {
        // Dans une architecture PGI, l'utilisateur Fournisseur (table 'utilisateurs') 
        // doit avoir une colonne liée à l'ID de la table 'fournisseurs'.
        // Pour cet exemple, nous allons utiliser l'ID de l'utilisateur comme référence à l'ID fournisseur pour le filtre.
        
        $alertes_stock = array_filter($tous_alertes, function($produit) use ($fournisseur_id_connecte) {
            // NOTE: Ceci suppose que l'ID de l'utilisateur connecté correspond au fournisseur_id du produit.
            return $produit['fournisseur_id'] == $fournisseur_id_connecte;
        });
    } else {
         // Si l'ID n'est pas trouvé (erreur de session), on ne montre rien.
         $alertes_stock = [];
    }

} catch (PDOException $e) {
    $message = "<div class='alert alert-danger'>Erreur base de données : Impossible de charger les alertes de stock.</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Espace Fournisseur</title>
    <link rel="stylesheet" href="../assets/css/style.css"> 
    <link rel="stylesheet" href="../assets/css/admin_style.css">
</head>
<body>

    <?php require_once 'admin_header.php'; ?> 

    <div class="container admin-container">
        <h1>🚚 Espace Fournisseur : Alertes Stock</h1>
        
        <?php echo $message; ?>
        
        <p class="alert alert-info">
            Bienvenue **<?= htmlspecialchars($_SESSION['user_name'] ?? 'Fournisseur') ?>**. Vous voyez ici uniquement les produits pour lesquels le stock est bas et que vous êtes chargé de réapprovisionner.
        </p>

        <div class="card mb-4">
            <h2>🚨 Produits à Réapprovisionner</h2>
            <?php if (!empty($alertes_stock)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Produit</th>
                            <th>Nom du Produit</th>
                            <th>Stock Actuel</th>
                            <th>Seuil d'Alerte</th>
                            <th>Quantité à Commander (Suggestion)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alertes_stock as $produit): ?>
                        <tr class="alert-row">
                            <td>#<?= htmlspecialchars($produit['id']) ?></td>
                            <td><?= htmlspecialchars($produit['nom']) ?></td>
                            <td class="text-center text-danger">
                                **<?= htmlspecialchars($produit['quantite_stock']) ?>**
                            </td>
                            <td class="text-center"><?= htmlspecialchars($produit['seuil_alerte']) ?></td>
                            <td class="text-center text-primary">
                                **<?= $produit['seuil_alerte'] * 5 ?>**
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="alert alert-success">Aucun de vos produits n'est actuellement sous le seuil d'alerte. Stock OK !</p>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>