<?php
// FICHIER : admin/fournisseur_dashboard.php

// 🚨 INCLURE L'EN-TÊTE SÉCURISÉ POUR LE FOURNISSEUR 🚨
// Cette étape inclut la session, la configuration DB, les fonctions, ET la vérification du rôle.
require_once 'fournisseur_header.php'; 

// Le fichier fournisseur_header.php a déjà vérifié le rôle et stocké l'ID de l'utilisateur.

// Récupérer l'ID de l'utilisateur connecté
$user_id = $_SESSION['user_id'] ?? null;
$alert_threshold = 10; // Seuil par défaut si non spécifié dans la BDD

// Définition de variables d'affichage
$produits = [];
$message = '';
$low_stock_count = 0;

try {
    // 1. Trouver l'ID du fournisseur lié à ce compte utilisateur (colonne fournisseur_id de la table clients)
    // C'est l'étape CRITIQUE pour lier l'utilisateur à l'entité fournisseur.
    $sql_fournisseur_link = "SELECT fournisseur_id FROM clients WHERE id = :user_id";
    $stmt_f_link = $pdo->prepare($sql_fournisseur_link);
    $stmt_f_link->execute([':user_id' => $user_id]);
    $fournisseur_data = $stmt_f_link->fetch(PDO::FETCH_ASSOC);

    if (!$fournisseur_data || !$fournisseur_data['fournisseur_id']) {
        throw new Exception("Ce compte utilisateur n'est pas lié à un fournisseur.");
    }

    $fournisseur_id = $fournisseur_data['fournisseur_id'];

    // 2. Requête pour récupérer UNIQUEMENT les produits de CE fournisseur qui sont sous le seuil
    // C'est plus EFFICACE et SÉCURISÉ que de filtrer après la requête (WHERE p.fournisseur_id = :fournisseur_id)
    $sql_produits = "
        SELECT 
            p.id, p.nom, p.sku, 
            p.stock_actuel,
            p.seuil_min_stock 
        FROM produits p
        WHERE 
            p.fournisseur_id = :fournisseur_id 
        AND 
            p.stock_actuel <= p.seuil_min_stock
        ORDER BY 
            p.stock_actuel ASC
    ";

    $stmt_produits = $pdo->prepare($sql_produits);
    $stmt_produits->execute([':fournisseur_id' => $fournisseur_id]);
    $produits = $stmt_produits->fetchAll(PDO::FETCH_ASSOC);
    $low_stock_count = count($produits);

} catch (Exception $e) {
    $message = "<div class='alert-danger'>Erreur : " . htmlspecialchars($e->getMessage()) . "</div>";
    // Si la connexion à la DB échoue
} catch (PDOException $e) {
    $message = "<div class='alert-danger'>Erreur base de données : Impossible de charger les produits.</div>";
}
?>

<div class="card stock-card">
    <div class="card-header">
        <h1>État des Stocks</h1>
        <button onclick="window.location.reload();" class="btn-secondary btn-small">Actualiser</button>
    </div>
    
    <?php echo $message; ?>

    <?php if ($low_stock_count > 0): ?>
        <div class="alert-danger" style="margin-bottom: 15px; text-align: center;">
            <strong>🔔 ATTENTION :</strong> <?= $low_stock_count ?> produit(s) nécessitent votre intervention.
        </div>
    <?php endif; ?>

    <?php if (empty($produits)): ?>
        <p class="alert alert-success" style="border-left: 5px solid #2ecc71;">
            Aucun de vos produits n'est actuellement sous le seuil d'alerte. Stock OK !
        </p>
    <?php else: ?>
        
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>RÉF</th>
                        <th>PRODUIT</th>
                        <th>STOCK ACTUEL</th>
                        <th>SEUIL ALERTE</th>
                        <th>STATUT</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($produits as $produit): 
                        // Déterminer le seuil (seuil_min_stock est utilisé)
                        $seuil = $produit['seuil_min_stock'];
                        
                        // Déterminer la classe de la ligne
                        $row_class = 'alert-row-danger';
                        $status_text = 'RUPTURE PROCHE'; // Puisque le filtre SQL ne montre que ceux-là
                        $action_text = 'Réapprovisionner';
                    ?>
                    <tr class="<?= $row_class ?>">
                        <td><?= htmlspecialchars($produit['sku']) ?></td>
                        <td><?= htmlspecialchars($produit['nom']) ?></td>
                        <td><strong style="color: #e74c3c;"><?= (int)$produit['stock_actuel'] ?></strong></td>
                        <td><?= (int)$seuil ?></td>
                        <td>
                            <span class="status-badge status-low"><?= $status_text ?></span>
                        </td>
                        <td>
                            <a href="reappro.php?produit_id=<?= $produit['id'] ?>" class="btn-action-reappro"><?= $action_text ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php 
// Fermer la div .container ouverte dans fournisseur_header.php
echo "</div>"; 
?>
</body>
</html>