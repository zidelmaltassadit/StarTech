<?php
// admin/produit_form.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 1. SÉCURITÉ
if (!is_logged_in()) { header('Location: ../public/login.php?role=admin'); exit; }
// Seuls les admins et la logistique/production peuvent modifier le catalogue
if (!in_array(strtolower($_SESSION['user_role']), ['admin', 'administrateur', 'logistique', 'production'])) { die("Accès refusé."); }

// 2. INITIALISATION (Mode Création par défaut)
$mode = 'creation';
$titre_page = "Nouveau Produit";
$produit = [
    'id' => '', 'nom' => '', 'description' => '', 'prix_vente' => '', 'prix_achat' => '',
    'quantite_stock' => '0', 'seuil_alerte' => '10', 'image' => '', 'categorie_id' => '', 'fournisseur_id' => '', 'statut' => 'actif'
];
$errors = [];

// 3. SI MODE MODIFICATION (ID dans l'URL)
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $mode = 'modification';
    $titre_page = "Modifier le produit #" . $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM produits WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $produit_db = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$produit_db) { die("Produit introuvable."); }
    $produit = array_merge($produit, $produit_db); // On fusionne pour garder les clés par défaut
}

// 4. RÉCUPÉRATION DES LISTES (Catégories et Fournisseurs) pour les menus déroulants
$categories = $pdo->query("SELECT id, nom FROM categories ORDER BY nom ASC")->fetchAll(PDO::FETCH_KEY_PAIR);
// On suppose que les fournisseurs ont le rôle 'fournisseur' dans la table utilisateurs
$fournisseurs = $pdo->query("SELECT id, nom FROM utilisateurs WHERE user_role = 'fournisseur' ORDER BY nom ASC")->fetchAll(PDO::FETCH_KEY_PAIR);


// 5. TRAITEMENT DU FORMULAIRE (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données
    $data = [
        'nom' => trim($_POST['nom']),
        'description' => trim($_POST['description']),
        'prix_vente' => (float)$_POST['prix_vente'],
        'prix_achat' => (float)$_POST['prix_achat'],
        'quantite_stock' => (int)$_POST['quantite_stock'],
        'seuil_alerte' => (int)$_POST['seuil_alerte'],
        'categorie_id' => !empty($_POST['categorie_id']) ? $_POST['categorie_id'] : null,
        'fournisseur_id' => !empty($_POST['fournisseur_id']) ? $_POST['fournisseur_id'] : null,
        'statut' => $_POST['statut'],
        'image' => $_POST['image_actuelle'] // Par défaut, on garde l'image actuelle
    ];

    // Validation basique
    if (empty($data['nom'])) { $errors[] = "Le nom du produit est obligatoire."; }
    if ($data['prix_vente'] <= 0) { $errors[] = "Le prix de vente doit être supérieur à 0."; }

    // GESTION DE L'IMAGE (Upload)
    if (isset($_FILES['image_upload']) && $_FILES['image_upload']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../assets/images/produits/';
        $tmp_name = $_FILES['image_upload']['tmp_name'];
        $name = basename($_FILES['image_upload']['name']);
        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($extension, $allowed_ext)) {
            // On crée un nom unique pour éviter les écrasements
            $new_filename = uniqid('prod_') . '.' . $extension;
            if (move_uploaded_file($tmp_name, $upload_dir . $new_filename)) {
                $data['image'] = $new_filename; // On met à jour le nom de l'image
            } else {
                $errors[] = "Erreur lors du téléchargement de l'image.";
            }
        } else {
            $errors[] = "Format d'image non autorisé (JPG, PNG, WEBP uniquement).";
        }
    }

    // ENREGISTREMENT EN BASE SI PAS D'ERREURS
    if (empty($errors)) {
        try {
            if ($mode === 'creation') {
                // INSERTION
                $sql = "INSERT INTO produits (nom, description, prix_vente, prix_achat, quantite_stock, seuil_alerte, image, categorie_id, fournisseur_id, statut) 
                        VALUES (:nom, :description, :prix_vente, :prix_achat, :quantite_stock, :seuil_alerte, :image, :categorie_id, :fournisseur_id, :statut)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($data);
                $msg = "Produit créé avec succès.";
            } else {
                // MISE À JOUR
                $data['id'] = $_POST['produit_id']; // On ajoute l'ID pour le WHERE
                $sql = "UPDATE produits SET nom=:nom, description=:description, prix_vente=:prix_vente, prix_achat=:prix_achat, 
                        quantite_stock=:quantite_stock, seuil_alerte=:seuil_alerte, image=:image, categorie_id=:categorie_id, 
                        fournisseur_id=:fournisseur_id, statut=:statut WHERE id=:id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($data);
                $msg = "Produit modifié avec succès.";
            }
            // Redirection vers la liste avec message de succès
            header("Location: produits.php?msg=" . urlencode($msg));
            exit;

        } catch (PDOException $e) {
            $errors[] = "Erreur SQL : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $titre_page ?> - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Style pour le formulaire */
        .form-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-weight: 600; margin-bottom: 8px; color: var(--text-primary); }
        .form-input, .form-select, .form-textarea {
            width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 12px; font-size: 1rem;
            transition: border-color 0.2s;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus { border-color: var(--accent-blue); outline: none; }
        .form-textarea { resize: vertical; height: 120px; }
        .img-preview { width: 100%; height: 200px; object-fit: contain; background: #F5F5F7; border-radius: 12px; margin-top: 10px; border: 1px solid var(--border-color); }
    </style>
</head>
<body class="admin-body">
    
    <div class="main-content" style="padding-top: 40px;">
        <a href="produits.php" style="display:inline-flex; align-items:center; gap:10px; margin-bottom:30px; font-weight:600;">
            <i class="fa-solid fa-arrow-left"></i> Retour à la liste
        </a>
        <header class="top-bar"><h1><?= $titre_page ?></h1></header>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" style="background:#FFF2F2; color:var(--accent-red); padding:20px; border-radius:15px; margin-bottom:30px;">
                <ul style="margin:0; padding-left:20px;">
                    <?php foreach($errors as $error): ?><li><?= htmlspecialchars($error) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="form-layout">
            <input type="hidden" name="produit_id" value="<?= $produit['id'] ?>">
            <input type="hidden" name="image_actuelle" value="<?= $produit['image'] ?>">

            <div class="card">
                <div class="section-header"><h2>Informations Produit</h2></div>
                
                <div class="form-group">
                    <label class="form-label">Nom du produit <span style="color:var(--accent-red)">*</span></label>
                    <input type="text" name="nom" class="form-input" required value="<?= htmlspecialchars($produit['nom']) ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-textarea"><?= htmlspecialchars($produit['description']) ?></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label class="form-label">Catégorie</label>
                        <select name="categorie_id" class="form-select">
                            <option value="">-- Sélectionner --</option>
                            <?php foreach($categories as $id => $nom): ?>
                                <option value="<?= $id ?>" <?= $produit['categorie_id'] == $id ? 'selected' : '' ?>><?= htmlspecialchars($nom) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Fournisseur Principal</label>
                        <select name="fournisseur_id" class="form-select">
                            <option value="">-- Aucun --</option>
                            <?php foreach($fournisseurs as $id => $nom): ?>
                                <option value="<?= $id ?>" <?= $produit['fournisseur_id'] == $id ? 'selected' : '' ?>><?= htmlspecialchars($nom) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="right-col-form">
                
                <div class="card">
                    <div class="section-header"><h2>Tarifs</h2></div>
                    <div class="form-group">
                        <label class="form-label">Prix de Vente TTC (€) <span style="color:var(--accent-red)">*</span></label>
                        <input type="number" step="0.01" name="prix_vente" class="form-input" required value="<?= $produit['prix_vente'] ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Prix d'Achat HT (€)</label>
                        <input type="number" step="0.01" name="prix_achat" class="form-input" value="<?= $produit['prix_achat'] ?>">
                        <small style="color:var(--text-secondary)">Visible uniquement par l'admin.</small>
                    </div>
                </div>

                <div class="card">
                    <div class="section-header"><h2>Stock & Statut</h2></div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label class="form-label">Stock Actuel</label>
                            <input type="number" name="quantite_stock" class="form-input" required value="<?= $produit['quantite_stock'] ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Seuil d'alerte</label>
                            <input type="number" name="seuil_alerte" class="form-input" required value="<?= $produit['seuil_alerte'] ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Statut sur le site</label>
                        <select name="statut" class="form-select">
                            <option value="actif" <?= $produit['statut'] == 'actif' ? 'selected' : '' ?>>Actif (Visible)</option>
                            <option value="inactif" <?= $produit['statut'] == 'inactif' ? 'selected' : '' ?>>Inactif (Caché)</option>
                        </select>
                    </div>
                </div>

                <div class="card">
                    <div class="section-header"><h2>Image du produit</h2></div>
                    <?php $img_url = !empty($produit['image']) ? (strpos($produit['image'], 'http') === 0 ? $produit['image'] : "/startech/assets/images/produits/" . $produit['image']) : 'https://dummyimage.com/300x200/eee/aaa&text=Pas+d+image'; ?>
                    <img src="<?= htmlspecialchars($img_url) ?>" class="img-preview" id="preview">
                    
                    <div class="form-group" style="margin-top: 15px;">
                        <label class="form-label" for="image_upload" style="cursor: pointer; background: #E8F2FF; color: var(--accent-blue); padding: 10px; border-radius: 10px; text-align: center; display: block; font-weight: 600;">
                            <i class="fa-solid fa-upload"></i> Choisir une nouvelle image
                        </label>
                        <input type="file" id="image_upload" name="image_upload" accept="image/png, image/jpeg, image/webp" style="display: none;" onchange="previewImage(event)">
                        <small style="color:var(--text-secondary); display:block; margin-top:5px; text-align:center;">JPG, PNG ou WEBP. Max 2 Mo.</small>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem; margin-top: 20px;">
                    <i class="fa-solid fa-floppy-disk"></i> Enregistrer le produit
                </button>

            </div>
        </form>
    </div>

    <script>
        // Petit script JS pour prévisualiser l'image avant l'upload
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('preview');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>

</body>
</html>