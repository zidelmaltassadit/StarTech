<?php
// ==========================================================
// FICHIER : login.php
// THEME : Apple Premium
// ==========================================================
session_start(); 

require_once 'includes/db_config.php';
require_once 'includes/auth_functions.php';

// Si l'utilisateur est déjà connecté, le rediriger
if (is_logged_in()) {
    if (is_admin()) {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: index.php'); 
    }
    exit;
}

$error_message = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $session_name_key = 'user_name'; 

    if (empty($email) || empty($password)) {
        $error_message = "Veuillez remplir tous les champs.";
    } else {
        try {
            $sql = "SELECT id, nom, mot_de_passe, role FROM utilisateurs WHERE email = :email";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['mot_de_passe'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION[$session_name_key] = $user['nom'];
                $_SESSION['user_role'] = $user['role'];

                if (in_array($user['role'], ['admin', 'logistique', 'production', 'rh'])) {
                    header('Location: admin/dashboard.php');
                } else {
                    header('Location: index.php');
                }
                exit;

            } else {
                $error_message = "Email ou mot de passe incorrect.";
            }
        } catch (PDOException $e) {
            $error_message = "Erreur connexion base de données.";
        } catch (Exception $e) {
             $error_message = "Une erreur inattendue est survenue.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - StarTech</title>
    <link rel="stylesheet" href="assets/css/style.css"> 
</head>
<body>

    <main class="login-wrapper">
        <div class="login-card">
            <h1>StarTech ID</h1>
            <h2>Connexion à votre espace</h2>

            <?php 
            // Messages Flash
            if (isset($_SESSION['flash_message'])) {
                echo "<div class='alert alert-success'>" . $_SESSION['flash_message'] . "</div>";
                unset($_SESSION['flash_message']);
            }

            // Erreurs
            if ($error_message) {
                echo "<div class='alert alert-danger' style='color: #FF3B30; background: rgba(255,59,48,0.1); padding: 10px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem;'>$error_message</div>";
            } 
            ?>

            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="email">Adresse Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="exemple@startech.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>

                <button type="submit" class="btn btn-full">Se connecter</button>
            </form>

            <div class="auth-links">
                <p>Pas encore de compte ? <a href="register.php">Créer un StarTech ID</a></p>
            </div>
        </div>
    </main>

</body>
</html>