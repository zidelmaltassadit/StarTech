<?php
// ===============================================
// AFFICHAGE DES ERREURS POUR LE DÉBOGAGE (IMPORTANT)
// Ces lignes vont afficher les erreurs PHP/DB qui bloquent votre site
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ===============================================

/**
 * Fichier de configuration de la connexion à la base de données (PDO)
 */

// --- VARIABLES DE CONNEXION (Plus faciles à utiliser avec PDO) ---
$db_host = 'localhost';             // L'adresse du serveur (souvent localhost)
$db_name = 'startech_db';           // 🚨 VÉRIFIEZ L'ORTHOGRAPHE EXACTE DANS phpMyAdmin !
$db_username = 'root';              // Votre utilisateur MySQL
$db_password = 'mysql';             // 🚨 VÉRIFIEZ LE MOT DE PASSE (Voir Point 2)

$pdo = null;

try {
    // Créez l'objet PDO
    $pdo = new PDO("mysql:host=" . $db_host . ";dbname=" . $db_name, $db_username, $db_password);
    
    // Configurez les attributs de la connexion
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8"); // Utilisation correcte pour l'encodage
    
} catch(PDOException $e) {
    // Ceci s'affiche si la connexion échoue (mauvais mot de passe, DB inexistante, etc.)
    die("ERREUR FATALE DE CONNEXION DB: " . $e->getMessage() . " - Vérifiez votre db_config.php.");
}

?>