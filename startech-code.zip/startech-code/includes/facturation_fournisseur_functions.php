<?php
// includes/facturation_fournisseur_functions.php

/**
 * Enregistre un paiement pour une facture fournisseur donnée.
 * * @param PDO $pdo
 * @param int $facture_id
 * @param float $montant_paiement
 * @throws Exception Si la facture est introuvable ou si le montant dépasse le solde dû.
 */
function enregistrer_paiement_facture_fournisseur(PDO $pdo, int $facture_id, float $montant_paiement)
{
    if ($montant_paiement <= 0) {
        throw new Exception("Le montant du paiement doit être positif.");
    }
    
    $pdo->beginTransaction();
    try {
        // 1. Verrouiller la facture et récupérer les infos
        $sql_select = "SELECT total_ttc, montant_paye FROM factures_fournisseur WHERE id = ? FOR UPDATE";
        $stmt_select = $pdo->prepare($sql_select);
        $stmt_select->execute([$facture_id]);
        $facture = $stmt_select->fetch(PDO::FETCH_ASSOC);

        if (!$facture) {
            throw new Exception("Facture Fournisseur #{$facture_id} non trouvée.");
        }

        $total_ttc = (float) $facture['total_ttc'];
        $montant_paye_actuel = (float) $facture['montant_paye'];
        $solde_du = $total_ttc - $montant_paye_actuel;

        if ($montant_paiement > $solde_du) {
            throw new Exception("Le paiement de " . number_format($montant_paiement, 2) . " € dépasse le solde dû (" . number_format($solde_du, 2) . " €).");
        }

        // 2. Calculer le nouveau montant payé et le statut
        $nouveau_montant_paye = $montant_paye_actuel + $montant_paiement;
        
        if (abs($nouveau_montant_paye - $total_ttc) < 0.01) { // Tolérance de flottant
            $nouveau_statut = 'payee';
        } elseif ($nouveau_montant_paye > 0) {
            $nouveau_statut = 'partiellement_payee';
        } else {
            $nouveau_statut = 'en_attente';
        }

        // 3. Mettre à jour la facture
        $sql_update = "UPDATE factures_fournisseur SET montant_paye = ?, statut_paiement = ? WHERE id = ?";
        $pdo->prepare($sql_update)->execute([$nouveau_montant_paye, $nouveau_statut, $facture_id]);

        // Optionnel : Enregistrer le mouvement de trésorerie (non implémenté ici)
        // Vous ajouteriez ici une ligne dans une table 'mouvements_tresorerie'.
        
        $pdo->commit();
        return $nouveau_statut;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}