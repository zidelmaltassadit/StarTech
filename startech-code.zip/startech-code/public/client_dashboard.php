<?php
// public/client_dashboard.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 
require_once '../includes/functions.php'; 

// --- SÉCURITÉ : Exiger la connexion client
if (!is_logged_in()) {
    // Redirection si l'utilisateur n'est pas connecté. (Bloc corrigé)
    $_SESSION['flash_message'] = "<div class='alert-warning'>Veuillez vous connecter pour accéder à votre tableau de bord.</div>";
    header('Location: login.php');
    exit();
}
// Fin du bloc de sécurité. Le reste du script s'exécute si l'utilisateur est connecté.

$client_id = $_SESSION['user_id'] ?? null;
$client_info = [];
$commandes = [];
// Récupère le message flash s'il existe (e.g., après une modification de profil)
$message = $_SESSION['flash_message'] ?? '';
unset($_SESSION['flash_message']);


// --- Initialisation et Récupération des données
if ($client_id) {
    // SÉCURITÉ : Assurer que l'ID est un entier pour la requête SQL
    $client_id = (int)$client_id;
    
    try {
        // 1. Récupérer les informations du client (Nom, Prénom, Email, Téléphone, etc.)
        $sql_client = "SELECT nom, prenom, email, telephone, entreprise, adresse_livraison_defaut, adresse_facturation_defaut FROM clients WHERE id = :id";
        $stmt_client = $pdo->prepare($sql_client);
        $stmt_client->execute([':id' => $client_id]);
        $client_info = $stmt_client->fetch(PDO::FETCH_ASSOC);

        // SÉCURITÉ : Déconnexion forcée si l'ID est valide mais l'utilisateur n'existe plus en BDD
        if (!$client_info) {
             session_unset();
             session_destroy();
             $_SESSION['flash_message'] = "<div class='alert-danger'>Erreur de session. Client introuvable.</div>";
             header('Location: login.php');
             exit();
        }
        
        // 2. Récupérer l'historique des commandes du client
        $sql_commandes = "SELECT id, date_commande, statut, total_ttc 
                             FROM commandes 
                             WHERE client_id = :client_id 
                             ORDER BY date_commande DESC";
        $stmt_commandes = $pdo->prepare($sql_commandes);
        $stmt_commandes->execute([':client_id' => $client_id]);
        $commandes = $stmt_commandes->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        // 🚨 IMPORTANT : AFFICHE LE MESSAGE D'ERREUR SQL DÉTAILLÉ POUR DÉBOGUER !
        $message = "<div class='alert-danger'>Erreur de base de données DÉTAILLÉE : " . $e->getMessage() . "</div>";
    }
} else {
    // Cas où is_logged_in() est vrai mais l'ID a disparu de la session (très rare)
    session_unset();
    session_destroy();
    $_SESSION['flash_message'] = "<div class='alert-danger'>ID client manquant. Veuillez vous reconnecter.</div>";
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Mon Compte Client</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>
    <header class="public-header">
        <div class="container">
            <h1>StarTech - Mon Compte</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (<?= count($_SESSION['panier'] ?? []) ?>)</a>
                <a href="logout.php">Déconnexion</a> 
            </nav>
        </div>
    </header>

    <div class="container public-content">
        <h2>👋 Bienvenue, <?= htmlspecialchars($client_info['prenom'] ?? 'Client') ?></h2>
        
        <?= $message; ?>
        
        <div class="dashboard-layout"> 
            
            <div class="info-card card">
                <h3>👤 Mes Informations & Adresses</h3>
                <p><strong>Nom & Prénom :</strong> <?= htmlspecialchars($client_info['nom'] ?? '') ?> <?= htmlspecialchars($client_info['prenom'] ?? '') ?></p>
                <p><strong>Email :</strong> <?= htmlspecialchars($client_info['email'] ?? '') ?></p>
                
                <?php if (!empty($client_info['telephone'])): ?>
                    <p><strong>Téléphone :</strong> <?= htmlspecialchars($client_info['telephone']) ?></p>
                <?php endif; ?>

                <?php if (!empty($client_info['entreprise'])): ?>
                    <p><strong>Entreprise :</strong> <?= htmlspecialchars($client_info['entreprise']) ?></p>
                <?php endif; ?>
                
                <hr>

                <h4>Adresses par Défaut</h4>
                <p><strong>Livraison :</strong> <?= nl2br(htmlspecialchars($client_info['adresse_livraison_defaut'] ?? 'Non définie')) ?></p>
                <p><strong>Facturation :</strong> <?= nl2br(htmlspecialchars($client_info['adresse_facturation_defaut'] ?? 'Non définie')) ?></p>
                
                <a href="edit_profile.php" class="btn btn-secondary mt-3">Modifier Mes Infos & Adresses</a>
            </div>

            <div class="historique-card card">
                <h3>📦 Historique de mes Commandes (<?= count($commandes) ?>)</h3>

                <?php if (!empty($commandes)): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Date</th>
                                <th>Statut</th>
                                <th class="text-right">Total TTC</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            foreach ($commandes as $cmd): ?>
                                <tr>
                                    <td>#<?= htmlspecialchars($cmd['id']) ?></td>
                                    <td><?= (new DateTime($cmd['date_commande']))->format('d/m/Y') ?></td>
                                    <td><?= format_statut($cmd['statut']) ?></td> 
                                    <td class="text-right"><strong><?= format_montant($cmd['total_ttc']) ?></strong></td>
                                    <td>
                                        <a href="detail_commande.php?id=<?= $cmd['id'] ?>" class="btn btn-info btn-small">Détail</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="alert alert-info">Vous n'avez pas encore passé de commande.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>