<?php
// FICHIER : public/register.php

session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 

$message = $_SESSION['flash_message'] ?? '';
unset($_SESSION['flash_message']);
$errors = [];

// Valeurs par défaut pour conserver les données si le formulaire échoue
$prenom = $_POST['prenom'] ?? '';
$nom = $_POST['nom'] ?? '';
$email = $_POST['email'] ?? '';
// 🚨 NOUVEAU : Champ Code Fournisseur
$code_fournisseur = $_POST['code_fournisseur'] ?? ''; 
$role_initial = 'client'; // Rôle par défaut

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Récupération des données POST
    $password = $_POST['password'] ?? '';
    
    // 2. Validation de base
    if (empty($prenom)) { $errors[] = "Le prénom est obligatoire."; }
    if (empty($nom)) { $errors[] = "Le nom est obligatoire."; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = "Le format de l'email est invalide."; }
    if (strlen($password) < 6) { $errors[] = "Le mot de passe doit contenir au moins 6 caractères."; }

    if (empty($errors)) {
        try {
            // VÉRIFICATION DE L'EMAIL DANS LA TABLE DES COMPTES (users)
            // (Nous utiliserons clients pour l'exemple, mais c'est mieux d'utiliser une table users)
            $sql_check = "SELECT id, user_role FROM clients WHERE email = :email"; // Assurez-vous d'avoir la colonne user_role dans clients
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([':email' => $email]);
            
            if ($stmt_check->rowCount() > 0) {
                $errors[] = "Cet email est déjà utilisé. Veuillez vous connecter ou utiliser un autre email.";
            } else {
                
                // 🚨 LOGIQUE FOURNISSEUR 🚨
                $fournisseur_id = null; // ID du fournisseur dans la table 'fournisseurs'
                if (!empty($code_fournisseur)) {
                    // Vérifier si le Code Fournisseur est valide
                    $sql_fournisseur = "SELECT id FROM fournisseurs WHERE code_acces = :code"; 
                    $stmt_fournisseur = $pdo->prepare($sql_fournisseur);
                    $stmt_fournisseur->execute([':code' => $code_fournisseur]);
                    $fournisseur_data = $stmt_fournisseur->fetch(PDO::FETCH_ASSOC);

                    if ($fournisseur_data) {
                        $role_initial = 'fournisseur';
                        $fournisseur_id = $fournisseur_data['id'];
                    } else {
                        // Le code est saisi mais invalide
                        $errors[] = "Le Code Fournisseur est invalide.";
                    }
                }
            }

            // Si aucune erreur de validation ou de code fournisseur
            if (empty($errors)) {
                
                // 3. Insertion dans la base de données (Table clients, avec rôle et ID fournisseur si applicable)
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // Mise à jour de la requête pour inclure le rôle et l'ID fournisseur
                $sql_insert = "INSERT INTO clients (prenom, nom, email, password_hash, user_role, fournisseur_id)
                               VALUES (:prenom, :nom, :email, :password_hash, :user_role, :fournisseur_id)";
                
                $stmt_insert = $pdo->prepare($sql_insert);
                $stmt_insert->execute([
                    ':prenom' => $prenom,
                    ':nom' => $nom,
                    ':email' => $email,
                    ':password_hash' => $password_hash,
                    ':user_role' => $role_initial, // 'client' ou 'fournisseur'
                    ':fournisseur_id' => $fournisseur_id // NULL ou l'ID si c'est un fournisseur
                ]);

                // Inscription réussie : Rediriger vers la connexion
                $_SESSION['flash_message'] = "<div class='alert-success'>✅ Votre compte a été créé en tant que **" . strtoupper($role_initial) . "** ! Vous pouvez vous connecter.</div>";
                header('Location: login.php');
                exit();
            }

        } catch (PDOException $e) {
            $message = "<div class='alert-danger'>Erreur de base de données : impossible de créer le compte. <br><strong>Détails :</strong> " . $e->getMessage() . "</div>";
        }
    }
    
    // Si des erreurs existent (validation ou BDD), les afficher
    if (!empty($errors)) {
        $message = "<div class='alert-warning'>" . implode('<br>', $errors) . "</div>";
    }
}
?>