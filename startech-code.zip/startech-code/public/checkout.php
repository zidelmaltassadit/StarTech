<?php
// public/checkout.php
session_start();
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// --- Vérifications Essentielles ---

// 1. Exiger la connexion client
if (!is_logged_in()) {
    // Redirection vers la page de connexion si l'utilisateur n'est pas authentifié
    $_SESSION['redirect_to'] = 'checkout.php';
    header('Location: login.php');
    exit();
}

// Assurez-vous d'avoir l'ID du client dans la session. 
// Cela dépend de comment votre fonction login.php l'a configuré.
$client_id = $_SESSION['user_id'] ?? null;

if (!$client_id) {
    die("Erreur de session: ID client non trouvé.");
}

// 2. Vérifier que le panier n'est pas vide
if (empty($_SESSION['panier'])) {
    header('Location: panier.php');
    exit();
}

// --- Logique de Traitement de la Commande (Transaction) ---

$total_ht_commande = 0;
$taux_tva = 0.20; // Utiliser un taux de TVA fixe pour cet exemple
$message_status = '';

try {
    // 1. Démarrer une transaction
    $pdo->beginTransaction();

    // 2. Vérifier le stock en temps réel et calculer le total
    foreach ($_SESSION['panier'] as $item) {
        $stmt_stock = $pdo->prepare("SELECT quantite_stock, prix_vente_ht FROM produits WHERE id = ?");
        $stmt_stock->execute([$item['id']]);
        $produit_db = $stmt_stock->fetch(PDO::FETCH_ASSOC);

        // Si le produit n'existe plus ou si le stock est insuffisant
        if (!$produit_db || $produit_db['quantite_stock'] < $item['quantite']) {
            $pdo->rollBack();
            $message_status = "Stock insuffisant pour le produit : " . htmlspecialchars($item['nom']) . ". Commande annulée.";
            unset($_SESSION['panier']);
            throw new Exception($message_status);
        }
        // Utiliser le prix actuel de la BDD, pas le prix potentiellement ancien du panier
        $total_ht_commande += $produit_db['prix_vente_ht'] * $item['quantite'];
    }
    
    // 3. Créer l'enregistrement de la Commande dans la table 'commandes'
    $total_ht_arrondi = round($total_ht_commande, 2);
    $sql_commande = "INSERT INTO commandes (client_id, date_commande, statut, total_ht) 
                     VALUES (:client_id, NOW(), 'en_attente_paiement', :total_ht)";
    
    $stmt_commande = $pdo->prepare($sql_commande);
    $stmt_commande->execute([
        ':client_id' => $client_id,
        ':total_ht' => $total_ht_arrondi
    ]);
    $commande_id = $pdo->lastInsertId();

    // 4. Insérer les Lignes de Commande et décrémenter le Stock
    $sql_ligne = "INSERT INTO lignes_commande (commande_id, produit_id, quantite, prix_unitaire_ht) 
                  VALUES (?, ?, ?, ?)";
    $sql_stock_update = "UPDATE produits SET quantite_stock = quantite_stock - ? WHERE id = ?";
    
    $stmt_ligne = $pdo->prepare($sql_ligne);
    $stmt_stock = $pdo->prepare($sql_stock_update);
    
    foreach ($_SESSION['panier'] as $item) {
        $stmt_ligne->execute([
            $commande_id, 
            $item['id'], 
            $item['quantite'], 
            $produit_db['prix_vente_ht'] // Prix venant de la BDD (sécurisé)
        ]);
        
        $stmt_stock->execute([
            $item['quantite'], 
            $item['id']
        ]);
    }

    // 5. Valider la transaction
    $pdo->commit();
    
    // 6. Vider le panier
    unset($_SESSION['panier']);
    $message_status = "<div class='alert-success'>✅ Commande #{$commande_id} passée avec succès ! Vous pouvez la consulter dans votre historique.</div>";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // Si l'erreur n'a pas été définie par nous-mêmes (stock), utiliser un message générique.
    if (empty($message_status)) {
        $message_status = "<div class='alert-danger'>❌ Une erreur s'est produite lors de la validation de la commande. Veuillez réessayer.</div>";
    }
}

// --- Affichage de la confirmation ---
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech - Confirmation de Commande</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/front_style.css">
</head>
<body>

    <header class="public-header">
        <div class="container">
            <h1>StarTech - Boutique</h1>
            <nav>
                <a href="catalogue.php">Catalogue</a>
                <a href="panier.php">Panier (0)</a>
                <a href="client_dashboard.php">Mon Compte</a>
            </nav>
        </div>
    </header>

    <div class="container public-content">
        <h2>Finalisation de la Commande</h2>
        
        <?= $message_status; ?>
        
        <?php if (isset($commande_id)): ?>
            <p>Votre numéro de commande est : <strong>#<?= $commande_id ?></strong>.</p>
            <p>Le statut initial est **En attente de paiement**. Veuillez vous rendre sur votre compte pour les options de paiement.</p>
        <?php endif; ?>
        
        <p><a href="catalogue.php" class="btn btn-secondary">Continuer mes achats</a></p>
        <p><a href="client_dashboard.php" class="btn btn-primary">Voir mes commandes</a></p>
        
    </div>
</body>
</html>