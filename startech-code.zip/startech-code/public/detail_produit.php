<?php
// public/detail_produit.php
session_start();
require_once '../includes/db_config.php';

// Données du produit (Prix de base = 1599)
$base_price = 1599.00;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MacBook Air 15" - Acheter - StarTech</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="product-page-body">

    <header>
        <div class="container" style="display:flex; justify-content:space-between; align-items:center;">
            <a href="../index.php" class="logo-text">StarTech</a>
            <div class="nav-icons">
                <a href="panier.php"><i class="fa-solid fa-bag-shopping"></i> Panier</a>
            </div>
        </div>
    </header>

    <main class="container product-detail-container">
        
        <div class="product-gallery sticky-gallery">
            <div class="badge-new">Nouveau</div>
            <img src="https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=1000&auto=format&fit=crop" alt="MacBook" class="main-product-img">
        </div>

        <div class="product-config">
            
            <h1 class="product-title">MacBook Air 15"</h1>
            <p class="product-subtitle">Puce M2. Une immensité de talent.</p>
            
            <div class="price-tag" id="displayed-price">1 599,00 €</div>

            <form action="panier_ajout.php" method="POST">
                <input type="hidden" name="product_id" value="1">
                <div class="config-section">
                    <h3 class="config-label">Mémoire unifiée (RAM)</h3>
                    <div class="radio-group">
                        
                        <label class="radio-card selected">
                            <input type="radio" name="ram" value="8go" data-price="0" checked onchange="calculateTotal(this)">
                            <div class="card-content">
                                <span class="spec-name">8 Go</span>
                                <span class="spec-price">Inclus</span>
                            </div>
                        </label>

                        <label class="radio-card">
                            <input type="radio" name="ram" value="16go" data-price="230" onchange="calculateTotal(this)">
                            <div class="card-content">
                                <span class="spec-name">16 Go</span>
                                <span class="spec-price">+ 230,00 €</span>
                            </div>
                        </label>
                        
                        <label class="radio-card">
                            <input type="radio" name="ram" value="24go" data-price="460" onchange="calculateTotal(this)">
                            <div class="card-content">
                                <span class="spec-name">24 Go</span>
                                <span class="spec-price">+ 460,00 €</span>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="config-section">
                    <h3 class="config-label">Stockage (SSD)</h3>
                    <div class="radio-group">
                        
                        <label class="radio-card selected">
                            <input type="radio" name="ssd" value="512go" data-price="0" checked onchange="calculateTotal(this)">
                            <div class="card-content">
                                <span class="spec-name">512 Go SSD</span>
                                <span class="spec-price">Inclus</span>
                            </div>
                        </label>

                        <label class="radio-card">
                            <input type="radio" name="ssd" value="1to" data-price="230" onchange="calculateTotal(this)">
                            <div class="card-content">
                                <span class="spec-name">1 To SSD</span>
                                <span class="spec-price">+ 230,00 €</span>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="action-area">
                    <button type="submit" class="btn btn-primary btn-block">Ajouter au Panier</button>
                    <p class="shipping-info"><i class="fa-solid fa-box-open"></i> Livraison gratuite : Demain</p>
                </div>
            </form>
        </div>
    </main>

    <script>
        // Prix de base PHP injecté dans JS
        const basePrice = <?= $base_price ?>;

        function calculateTotal(element) {
            // 1. Gestion visuelle (Bordure bleue)
            // Trouver le groupe du bouton cliqué
            const group = element.closest('.radio-group');
            // Enlever 'selected' partout dans ce groupe
            group.querySelectorAll('.radio-card').forEach(card => card.classList.remove('selected'));
            // Ajouter 'selected' sur celui cliqué
            element.closest('.radio-card').classList.add('selected');

            // 2. Calcul mathématique
            let currentTotal = basePrice;

            // Récupérer la RAM choisie
            const selectedRam = document.querySelector('input[name="ram"]:checked');
            if (selectedRam) {
                currentTotal += parseInt(selectedRam.getAttribute('data-price'));
            }

            // Récupérer le SSD choisi
            const selectedSsd = document.querySelector('input[name="ssd"]:checked');
            if (selectedSsd) {
                currentTotal += parseInt(selectedSsd.getAttribute('data-price'));
            }

            // 3. Mise à jour de l'affichage (Format monétaire fr-FR)
            const formattedPrice = new Intl.NumberFormat('fr-FR', { 
                style: 'currency', 
                currency: 'EUR' 
            }).format(currentTotal);

            document.getElementById('displayed-price').innerText = formattedPrice;
        }
    </script>

</body>
</html>