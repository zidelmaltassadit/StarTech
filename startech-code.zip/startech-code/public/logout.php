<?php
// =UCHIER : public/logout.php
// Script pour déconnecter complètement l'utilisateur et le renvoyer à l'accueil.

// Démarrer la session (OBLIGATOIRE pour pouvoir la détruire !)
session_start();

// 1. Vider le tableau de session (supprime toutes les variables de session)
$_SESSION = array();

// 2. Détruire le cookie de session (si existant)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. Détruire la session côté serveur
session_destroy();

// 4. Rediriger vers la page principale (index.php)
// Le ../ remonte au dossier parent (/startech/) pour trouver index.php
header('Location: ../index.php');
exit;

?>