<?php
// FICHIER : admin/nom_de_la_page.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...
$message = '';
$commandes_en_cours = [];

// ==============================================
// 1. GESTION DES REQUÊTES POST (ENREGISTREMENT DE LA RÉCEPTION)
// ==============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['receptionner'])) {
    $commande_id = intval($_POST['commande_id'] ?? 0);
    $quantites_recues = $_POST['quantite_recue'] ?? [];
    
    if ($commande_id <= 0 || empty($quantites_recues)) {
        $message = "<div class='alert alert-danger'>Données de réception invalides ou manquantes.</div>";
    } else {
        $pdo->beginTransaction();
        try {
            $est_complete = true;
            $nouvelles_quantites_recues = 0;
            $ancienne_quantite_recue = 0;
            
            // 1. Traiter chaque ligne de détail
            foreach ($quantites_recues as $detail_id => $nouvelle_quantite_recue) {
                $detail_id = intval($detail_id);
                $nouvelle_quantite_recue = intval($nouvelle_quantite_recue);

                if ($detail_id > 0 && $nouvelle_quantite_recue > 0) {
                    
                    // A. Récupérer les données de la ligne actuelle (quantité commandée et déjà reçue)
                    $sql_check = "SELECT produit_id, quantite, quantite_recue FROM commande_achat_details WHERE id = ?";
                    $stmt_check = $pdo->prepare($sql_check);
                    $stmt_check->execute([$detail_id]);
                    $detail = $stmt_check->fetch(PDO::FETCH_ASSOC);

                    if (!$detail) continue; 
                    
                    $ancienne_quantite_recue = $detail['quantite_recue'];
                    $quantite_commandee = $detail['quantite'];
                    $produit_id = $detail['produit_id'];

                    // Calculer la quantité NETTE à ajouter au stock (éviter de mettre à jour le stock si on a déjà tout reçu)
                    $quantite_a_ajouter = $nouvelle_quantite_recue; 
                    
                    // Vérification de dépassement de la commande
                    if (($ancienne_quantite_recue + $quantite_a_ajouter) > $quantite_commandee) {
                         throw new Exception("Erreur: La quantité totale reçue pour le détail #{$detail_id} ({$ancienne_quantite_recue} reçus + {$quantite_a_ajouter} à ajouter) dépasse la quantité commandée ({$quantite_commandee}).");
                    }

                    // B. Mettre à jour la quantité reçue dans la ligne de détail
                    $sql_update_detail = "UPDATE commande_achat_details SET quantite_recue = quantite_recue + ? WHERE id = ?";
                    $stmt_update_detail = $pdo->prepare($sql_update_detail);
                    $stmt_update_detail->execute([$quantite_a_ajouter, $detail_id]);

                    // C. Mettre à jour le stock du produit
                    $sql_update_stock = "UPDATE produits SET stock = stock + ? WHERE id = ?";
                    $stmt_update_stock = $pdo->prepare($sql_update_stock);
                    $stmt_update_stock->execute([$quantite_a_ajouter, $produit_id]);
                    
                    // D. Vérifier si la commande est toujours incomplète
                    if (($ancienne_quantite_recue + $quantite_a_ajouter) < $quantite_commandee) {
                        $est_complete = false;
                    }
                }
            }
            
            // 2. Mettre à jour le statut de la commande
            $nouveau_statut = 'partiellement_recue';
            if ($est_complete) {
                $nouveau_statut = 'recue';
            } elseif (array_sum($quantites_recues) > 0) {
                 // Si on a reçu quelque chose, et ce n'est pas complet, c'est partiel.
                 $nouveau_statut = 'partiellement_recue';
            } else {
                 // Si rien n'a été reçu, le statut reste le même (envoyee)
                 // Dans une réception partielle, on ne fait rien si le statut était déjà plus avancé
            }
            
            if ($nouveau_statut !== 'partiellement_recue' && $nouveau_statut !== 'recue') {
                 // S'assurer qu'on n'écrase pas un statut d'envoi
                 // Pour la démo, on ne met à jour que si c'est partiel ou complet
            } else {
                 $sql_update_cmd = "UPDATE commandes_achat SET statut = ?, date_mise_a_jour = NOW() WHERE id = ?";
                 $pdo->prepare($sql_update_cmd)->execute([$nouveau_statut, $commande_id]);
            }
            
            $pdo->commit();
            $message = "<div class='alert alert-success'>Réception enregistrée pour la commande **#{$commande_id}**. Statut mis à jour à **" . ucfirst(str_replace('_', ' ', $nouveau_statut)) . "** et stock ajusté.</div>";
            
            // Redirection pour nettoyer le POST
            header("Location: reception_stock.php?message=" . urlencode($message));
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Erreur de transaction lors de la réception : " . $e->getMessage() . "</div>";
        }
    }
}

// ==============================================
// 2. LECTURE : Récupérer les commandes en attente
// ==============================================
try {
    // On sélectionne toutes les commandes qui ne sont pas encore complètement reçues ou annulées
    $sql_select = "
        SELECT ca.id, ca.date_commande, ca.statut, f.nom_entreprise
        FROM commandes_achat ca
        JOIN fournisseurs f ON ca.fournisseur_id = f.id
        WHERE ca.statut IN ('envoyee', 'partiellement_recue', 'brouillon') 
        ORDER BY ca.date_commande ASC";
    $stmt_select = $pdo->query($sql_select);
    $commandes_en_cours = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message .= "<div class='alert alert-danger'>Erreur lors du chargement des commandes d'achat : " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PGI StarTech - Réception de Stock</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        .details-table td { background-color: #fff; }
        .details-table th, .details-table td { padding: 8px; border: 1px solid #ddd; }
        .details-table th { background-color: #f2f2f2; }
    </style>
</head>
<body>

    <?php require_once 'admin_header.php'; ?>

    <div class="container admin-container">
        <h1>📦 Gestion des Réceptions de Stock</h1>
        
        <?php 
        if(isset($_GET['message'])) {
            echo urldecode($_GET['message']);
        } else {
            echo $message; 
        }
        ?>
        
        <div class="card">
            <h2>Commandes d'Achat en Attente (<?= count($commandes_en_cours) ?>)</h2>
            
            <?php if (!empty($commandes_en_cours)): ?>
                
                <?php foreach ($commandes_en_cours as $cmd): 
                    // 3. Récupérer les détails pour chaque commande
                    $sql_details = "
                        SELECT 
                            cad.*, p.nom AS produit_nom, p.reference AS produit_ref
                        FROM 
                            commande_achat_details cad
                        JOIN 
                            produits p ON cad.produit_id = p.id
                        WHERE cad.commande_achat_id = ?
                        HAVING cad.quantite > cad.quantite_recue
                        ORDER BY p.nom ASC
                    ";
                    $stmt_details = $pdo->prepare($sql_details);
                    $stmt_details->execute([$cmd['id']]);
                    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

                    // Afficher uniquement si au moins une ligne est encore à recevoir
                    if (empty($details)) continue;
                ?>
                <div class="card mb-4">
                    <h3>Commande #<?= $cmd['id'] ?> (<?= htmlspecialchars($cmd['nom_entreprise']) ?>)</h3>
                    <p>Statut: <span class="status-badge status-<?= strtolower($cmd['statut']) ?>"><?= ucfirst(str_replace('_', ' ', $cmd['statut'])) ?></span> | Passée le: <?= date('d/m/Y', strtotime($cmd['date_commande'])) ?></p>

                    <form method="POST" action="reception_stock.php">
                        <input type="hidden" name="commande_id" value="<?= $cmd['id'] ?>">
                        <input type="hidden" name="receptionner" value="1">

                        <table class="details-table" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Référence</th>
                                    <th>Produit</th>
                                    <th>Qté Commandée</th>
                                    <th>Qté Déjà Reçue</th>
                                    <th>Qté à Recevoir (Max: Restant)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($details as $d): 
                                    $a_recevoir = $d['quantite'] - $d['quantite_recue'];
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($d['produit_ref']) ?></td>
                                    <td>**<?= htmlspecialchars($d['produit_nom']) ?>**</td>
                                    <td><?= $d['quantite'] ?></td>
                                    <td><?= $d['quantite_recue'] ?></td>
                                    <td>
                                        <input type="number" 
                                               name="quantite_recue[<?= $d['id'] ?>]" 
                                               value="0" 
                                               min="0" 
                                               max="<?= $a_recevoir ?>"
                                               style="width: 80px;"
                                               class="form-control-small">
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div style="text-align: right; margin-top: 15px;">
                            <button type="submit" class="btn btn-success">Valider la Réception (Ajouter au Stock)</button>
                        </div>
                    </form>
                </div>
                <?php endforeach; ?>
                
            <?php else: ?>
                <p class="alert alert-info">Aucune commande d'achat n'est en cours de réception (ou n'est marquée comme envoyée).</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>