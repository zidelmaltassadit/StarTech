<?php
// FICHIER : admin/nom_de_la_page.php

// 1. Démarrer la session (Doit être la toute première instruction)
session_start(); 

// 2. Inclure les fichiers (Corriger le chemin : "../" au lieu de ".../")
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php';

// 3. Appliquer la sécurité
require_admin(); 

// Le reste du code de votre page commence ici...
// ...

$facture_id = intval($_GET['id'] ?? 0);

if ($facture_id === 0) {
    die("Erreur: ID de facture manquant.");
}

try {
    // ==============================================
    // 1. RÉCUPÉRATION DES DONNÉES DE LA FACTURE
    // ==============================================
    $sql_facture = "
        SELECT 
            f.*, c.date_commande, cl.nom AS client_nom, cl.adresse, cl.ville, cl.code_postal, cl.email
        FROM 
            factures f
        JOIN 
            commandes cmd ON f.commande_id = cmd.id
        JOIN 
            clients cl ON cmd.client_id = cl.id
        WHERE 
            f.id = :id
    ";
    $stmt_facture = $pdo->prepare($sql_facture);
    $stmt_facture->execute([':id' => $facture_id]);
    $facture = $stmt_facture->fetch(PDO::FETCH_ASSOC);

    if (!$facture) {
        die("Facture #{$facture_id} non trouvée.");
    }

    // 2. RÉCUPÉRATION DES DÉTAILS DE LA FACTURE
    $sql_details = "
        SELECT 
            fd.quantite, fd.prix_unitaire_ht, fd.total_ligne_ht, p.nom AS produit_nom
        FROM 
            facture_details fd
        JOIN 
            produits p ON fd.produit_id = p.id
        WHERE 
            fd.facture_id = :id
    ";
    $stmt_details = $pdo->prepare($sql_details);
    $stmt_details->execute([':id' => $facture_id]);
    $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);

    // ==============================================
    // 3. GÉNÉRATION DU PDF (LOGIQUE ADAPTÉE À LA BIBLIOTHÈQUE)
    // ==============================================

    // --- LOGIQUE FPDF/TCPDF SIMULÉE ---
    
    // Header HTTP pour forcer le téléchargement ou l'affichage
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="Facture_StarTech_' . $facture_id . '.pdf"');
    
    // Ici, vous instanciez et configurez votre objet PDF
    // Exemple FPDF : $pdf = new FPDF(); $pdf->AddPage();
    
    // Pour l'exercice, nous allons générer un contenu très simplifié pour illustrer la structure

    /*
    // Début de la génération FPDF (ou autre)
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(40,10,'FACTURATION STARTECH');
    $pdf->Ln(20);

    // Infos Client
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,6, 'Facture N°: ' . $facture_id, 0, 1);
    $pdf->Cell(0,6, 'Date: ' . date('d/m/Y', strtotime($facture['date_facture'])), 0, 1);
    $pdf->Cell(0,6, 'Client: ' . $facture['client_nom'], 0, 1);
    $pdf->Ln(10);
    
    // Tableau des détails (Boucle sur $details)
    // ...
    
    // Totaux
    // ...
    
    $pdf->Output('I', 'Facture_StarTech_' . $facture_id . '.pdf');
    // Fin de la génération FPDF (ou autre)
    */

    // --- Affichage d'un message HTML simple si vous n'avez pas de bibliothèque ---
    echo "<!DOCTYPE html><html><head><title>Facture #{$facture_id}</title></head><body>";
    echo "<h1>Facture N° " . htmlspecialchars($facture_id) . "</h1>";
    echo "<p>Client: <strong>" . htmlspecialchars($facture['client_nom']) . "</strong></p>";
    echo "<p>Date de Facture: " . date('d/m/Y', strtotime($facture['date_facture'])) . "</p>";
    echo "<p>Statut Paiement: <strong>" . htmlspecialchars($facture['statut_paiement']) . "</strong></p>";
    
    echo "<table border='1' cellpadding='5' cellspacing='0' style='width: 80%; margin-top: 20px;'>";
    echo "<tr><th>Produit</th><th>Qté</th><th>Prix U. HT</th><th>Total HT</th></tr>";
    foreach ($details as $item) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($item['produit_nom']) . "</td>";
        echo "<td align='right'>" . htmlspecialchars($item['quantite']) . "</td>";
        echo "<td align='right'>" . number_format($item['prix_unitaire_ht'], 2, ',', ' ') . " €</td>";
        echo "<td align='right'>" . number_format($item['total_ligne_ht'], 2, ',', ' ') . " €</td>";
        echo "</tr>";
    }
    echo "<tr><td colspan='3' align='right'>Total HT</td><td align='right'><strong>" . number_format($facture['total_ht'], 2, ',', ' ') . " €</strong></td></tr>";
    echo "<tr><td colspan='3' align='right'>Total TTC</td><td align='right'><strong>" . number_format($facture['total_ttc'], 2, ',', ' ') . " €</strong></td></tr>";
    echo "</table>";
    
    echo "<p style='margin-top: 20px; color: red;'>**AVERTISSEMENT: Ceci est un aperçu HTML, pas le PDF réel. Pour le PDF, installez FPDF ou TCPDF et décommentez la logique de génération.**</p>";
    echo "</body></html>";
    // Fin de l'aperçu HTML

} catch (PDOException $e) {
    die("Erreur base de données lors de la récupération des données de la facture: " . $e->getMessage());
}
?>