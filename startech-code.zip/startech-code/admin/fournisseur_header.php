<?php
// FICHIER : admin/fournisseur_header.php
session_start();
// Les chemins vers les includes sont corrects (remontent d'un niveau)
require_once '../includes/db_config.php';
require_once '../includes/auth_functions.php'; 

// 🚨 SÉCURITÉ CRITIQUE : VÉRIFICATION DU RÔLE 🚨
// Si l'utilisateur n'est PAS connecté OU n'a PAS le rôle 'fournisseur', on le renvoie au login.
if (!is_logged_in() || $_SESSION['user_role'] !== 'fournisseur') {
    $_SESSION['flash_message'] = "<div class='alert-danger'>Accès refusé. Vous devez être connecté en tant que Fournisseur.</div>";
    header('Location: ../public/login.php');
    exit;
}

// Récupérer le nom de l'utilisateur pour l'affichage
$fournisseur_name = htmlspecialchars($_SESSION['user_name']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>StarTech | PORTAIL FOURNISSEUR</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin_style.css">
    <style>
        /* Styles spécifiques pour l'interface fournisseur */
        .card { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn-secondary { background-color: #f3f4f6; color: #333; border: 1px solid #ccc; padding: 8px 15px; border-radius: 5px; text-decoration: none; }
        .btn-secondary:hover { background-color: #e0e2e5; }
        /* Assurez-vous d'avoir les styles pour .data-table et .alert-row-danger dans admin_style.css */
    </style>
</head>
<body>
    <header style="background-color: #333;">
        <div class="container logo-container" style="display: flex; justify-content: space-between; align-items: center;">
            <div class="logo" style="color: white;">
                <h2>STARTECH | PORTAIL FOURNISSEUR</h2> 
            </div>
            <nav>
                <a href="fournisseur_dashboard.php" style="color: white; margin-right: 20px;">État des Stocks</a>
                <a href="../public/logout.php" class="btn-secondary">Déconnexion</a>
            </nav>
        </div>
    </header>
    
    <div class="container main-content" style="padding-top: 20px;">
        <div class="user-info" style="margin-bottom: 20px; text-align: right;">
            <span class="user-name">Connecté : <?= $fournisseur_name ?> (Fournisseur)</span> 
        </div>